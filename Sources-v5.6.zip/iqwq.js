// ============================================================================
// 音乐聚合（music.iqwq.cn）—— 移植版 JS 源
//
// 来源：几个音乐py.zip 里的「音乐聚合.py」（TVBox / 影视仓 Python 源）
// 原 Python 源是纯表单 POST 的聚合 API（QQ音乐 + 一听），无加密、无 App 签名，
// 因此干净地改写为 v5.6 的 registerSource 契约，可直接放进 manifest.json。
//
// 依赖：宿主注入的 registerSource / parseJson，以及
//       host.getString（支持 method:'POST' + body + contentType）
//
// 接口（唯一）：POST https://music.iqwq.cn/   表单
//   input=关键词 & filter=name & type=qq|1ting & page=页码
//   必须带 X-Requested-With: XMLHttpRequest + Accept: application/json + Referer/Origin，
//   否则会返回整页 HTML 或 403/404。
//   返回 {"data":[{"type","link","songid","title","author","lrc","url","pic"}]}
//   url 为真实音频直链（qq 的 .m4a / 1ting 的 .mp3 302 跳转），已在沙箱实测可下载。
//
// 设计：每首歌 = 一本书（单集）。歌曲信息（含播放直链、封面、歌手）用
//       encodeURIComponent(JSON) 自包含地编码进 bookUrl / 播放地址，
//       这样从「收藏 / 历史」直接进入详情也能播，不依赖内存缓存。
// ============================================================================
(function () {
  var SITE = 'https://music.iqwq.cn/';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';

  // 各平台实测有效的热门关键词（QQ 用具体歌名结果多，一听用风格词结果多）
  var QQ_WORDS = ['孤勇者', '如愿', '稻香', '告白气球', '成都', '起风了', '漠河舞厅', '大鱼',
    '十年', '光年之外', '青花瓷', '演员', '童话', '遇见', '晴天'];
  var TING_WORDS = ['流行', '经典', '华语', '民谣', '治愈', '励志', '摇滚', '抖音', '怀旧',
    '轻音乐', '伤感', '纯音乐', '古风', '电子', '爵士'];
  var MAX_PAGE = 5;   // 每个关键词最多翻 5 页，避免无限翻页

  function enc(v) {
    return encodeURIComponent(String(v === undefined || v === null ? '' : v));
  }

  // 一听封面常带畸形前缀 https:////img... -> https://img...
  function fixPic(p) {
    return String(p || '').replace(/^(https?:)\/\/+/, '$1//');
  }

  // 只保留能播的直链
  function okUrl(u) {
    u = String(u || '');
    if (!/^https?:\/\//i.test(u)) return false;
    if (/\.(mp3|m4a|aac|ogg|wav|flac)(\?|$)/i.test(u)) return true;
    if (/1ting\.com\/file/i.test(u)) return true;   // 一听的代理跳转形式
    return false;
  }

  // POST 表单，返回歌曲数组；任何异常/空结果都降级为 []
  function postSongs(host, word, type, page) {
    var body = 'input=' + enc(word) + '&filter=name&type=' + enc(type) + '&page=' + page;
    var text;
    try {
      text = host.getString(SITE, {
        desktop: false,
        method: 'POST',
        contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
        body: body,
        headers: {
          'User-Agent': UA,
          'Referer': SITE,
          'Origin': 'https://music.iqwq.cn',
          'X-Requested-With': 'XMLHttpRequest',
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'zh-CN,zh;q=0.9'
        }
      });
    } catch (e) { if (e.cancelled) throw e; return []; }
    if (!text) return [];
    var json;
    try { json = parseJson(text); } catch (e2) { return []; }
    var data = json && json.data;
    // 无结果时接口返回 data:"" / code:404，必须判定为数组
    if (!data || Object.prototype.toString.call(data) !== '[object Array]') return [];
    return data;
  }

  // 把歌曲对象压成自包含的编码串
  function pack(o) {
    return enc(JSON.stringify({
      u: o.url, t: o.title, a: o.author, p: fixPic(o.pic), y: o.type
    }));
  }

  // 兼容宿主是否已对 url 做过一次 decodeURIComponent
  function unpack(raw) {
    var s = String(raw || ''), o = null;
    try { o = parseJson(s); } catch (e) { }
    if (!o || typeof o !== 'object' || !o.u) {
      try { o = parseJson(decodeURIComponent(s)); } catch (e2) { }
    }
    return (o && o.u) ? o : null;
  }

  // 歌曲数组 -> books（按「歌名|歌手」去重）
  function toBooks(songs) {
    var seen = {}, out = [];
    (songs || []).forEach(function (s) {
      if (!s || !okUrl(s.url)) return;
      var title = String(s.title || '未知歌曲').trim();
      var author = String(s.author || '').trim();
      var sig = title + '|' + author;
      if (seen[sig]) return;
      seen[sig] = 1;
      var type = String(s.type || '');
      out.push({
        bookUrl: 'iqwq:song:' + pack({ url: s.url, title: title, author: author, pic: s.pic, type: type }),
        title: title,
        artist: author,
        coverUrl: fixPic(s.pic),
        intro: (author ? '歌手：' + author + '  ·  ' : '') + (type === '1ting' ? '一听音乐' : 'QQ音乐'),
        status: ''
      });
    });
    return out;
  }

  function wordsOf(type) { return type === '1ting' ? TING_WORDS : QQ_WORDS; }

  registerSource({
    id: 'b2c3d4e5f60718293a4b5c6d7e8f9012',
    name: '音乐聚合',
    url: SITE,
    group: '音乐',
    description: '推荐指数:4星 ⭐⭐⭐⭐\nQQ音乐 + 一听 双平台聚合，纯表单接口无加密。分类按热词/风格浏览、可翻页，点进单曲即播。\n建议用「歌名」搜索（歌手名常无结果）。\n站点：music.iqwq.cn',
    multipleEpisodePages: false,

    categoryMenus: function () {
      function tabs(type) {
        var t = [{ title: '热门推荐', url: 'iqwq:hot:' + type + '#1' }];
        wordsOf(type).forEach(function (w, i) {
          t.push({ title: w, url: 'iqwq:cat:' + type + ':' + i + '#1' });
        });
        return t;
      }
      return [
        { title: '音乐聚合·QQ音乐', tabs: tabs('qq') },
        { title: '音乐聚合·一听', tabs: tabs('1ting') }
      ];
    },

    categoryPage: function (url) {
      var host = this.host, key = String(url);
      var m = /^iqwq:(cat|hot):([^:#]*)(?::(\d+))?(?:#(\d+))?$/.exec(key);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var mode = m[1], type = m[2];
      var wi = parseInt(m[3] || '0', 10) || 0;
      var page = parseInt(m[4] || '1', 10) || 1;
      var words = wordsOf(type), songs = [];

      if (mode === 'hot') {
        // 热门推荐：每页取 3 个关键词各第 1 页，合并去重
        var start = (page - 1) * 3;
        var picked = words.slice(start, start + 3);
        if (!picked.length) picked = words.slice(0, 3);
        picked.forEach(function (w) {
          songs = songs.concat(postSongs(host, w, type, 1));
        });
      } else {
        songs = postSongs(host, words[wi] || words[0], type, page);
      }

      var books = toBooks(songs);
      var more = (page < MAX_PAGE) && songs.length > 0;
      return {
        books: books, currentPage: page, totalPage: more ? page + 1 : page,
        nextUrl: more ? ('iqwq:' + mode + ':' + type + (mode === 'cat' ? ':' + wi : '') + '#' + (page + 1)) : null
      };
    },

    search: function (keywords, page) {
      var word = String(keywords || '').trim();
      if (!word) return { books: [], totalPage: 1 };
      var pg = parseInt(page, 10) || 1;
      var songs = postSongs(this.host, word, 'qq', pg).concat(postSongs(this.host, word, '1ting', pg));
      return { books: toBooks(songs), totalPage: 1 };
    },

    bookDetail: function (bookUrl) {
      var p = String(bookUrl).replace(/^iqwq:song:/, '');
      var s = unpack(p);
      if (!s) throw new Error('歌曲信息已失效，请返回列表重新进入');
      var title = String(s.t || '未知歌曲'), artist = String(s.a || '');
      return {
        title: title,
        artist: artist,
        coverUrl: String(s.p || ''),
        intro: (artist ? '歌手：' + artist + '  ·  ' : '') + (s.y === '1ting' ? '一听音乐' : 'QQ音乐'),
        status: '',
        episodes: [{
          title: title + (artist ? ' - ' + artist : ''),
          url: 'iqwq:play:' + p     // 直接透传同一编码串，避免重新打包丢字段
        }]
      };
    },

    // 播放：直链已在列表阶段拿到，直接返回；302 由播放器自动跟随
    audio: function (episodeUrl) {
      var p = String(episodeUrl).replace(/^iqwq:play:/, '');
      var s = unpack(p);
      if (!s) throw new Error('没有获取到播放地址，请返回列表重新进入');
      return {
        url: String(s.u),
        headers: { 'User-Agent': UA, 'Referer': SITE }
      };
    },

    audioHeaders: function () { return { 'User-Agent': UA, 'Referer': SITE }; },
    coverHeaders: function () { return { 'User-Agent': UA, 'Referer': 'https://www.1ting.com/' }; }
  });
})();
