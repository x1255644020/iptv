// ============================================================================
// 凤梨音乐（flmp3.pro）—— 移植版 JS 源
//
// 来源：几个音乐py.zip 里的「凤梨音乐.py」（TVBox / 影视仓 Python 源，作者：繁星四月）
// 原 Python 源只是 HTML 爬虫，无加密、无签名，站点直出 mp3 播放直链，
// 因此干净地改写为 v5.6 的 registerSource 契约，可直接放进 manifest.json。
//
// 依赖：宿主注入的 registerSource / str / int / 以及
//       host.getHtml / getString / parseHtml / log
//
// 站点结构：
//   列表页   https://www.flmp3.pro/song.html?page=N        （全部歌曲，分页）
//   首页     https://www.flmp3.pro/                          （list 区含「最新/热门」两个面板）
//   搜索页   https://www.flmp3.pro/search.html?keyword=词
//   详情页   https://www.flmp3.pro/song/{id}.html           （歌名 h1 / 歌手 / 封面）
//   播放     https://www.flmp3.pro/api/playurl.php?id={id}   （直接返回真实 mp3 直链，已实测为酷我 CDN）
//
// 卡片结构（列表/首页面板通用）：
//   <a href="/song/{id}.html">
//     <div class="pic"><dl class="imgBoxCover"><img src="封面" alt="..."></dl></div>
//     <div class="con"><div class="t"><h3>歌名</h3><p>歌手</p></div><div class="date">..</div></div>
//   </a>
// ============================================================================
(function () {
  var SITE = 'https://www.flmp3.pro';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

  // 对齐 URLEncoder：空格转 %20
  function enc(v) {
    return encodeURIComponent(String(v === undefined || v === null ? '' : v))
      .replace(/[!'()*]/g, function (c) { return '%' + c.charCodeAt(0).toString(16).toUpperCase(); });
  }
  function opts(ref) {
    return { desktop: false, headers: { 'User-Agent': UA, Referer: ref || (SITE + '/') } };
  }
  function doc(host, url, ref) { return host.getHtml(url, opts(ref)); }
  function textOf(el, sel) { var e = el.first(sel); return e.exists() ? e.text().trim() : ''; }
  function imgOf(el) { var i = el.first('img'); return i.exists() ? (i.attr('src') || i.attr('data-src') || '') : ''; }

  // 从一段 DOM（列表页 / 首页面板）里解析歌曲卡片，每首歌当成一本书
  function parseSongs(root) {
    var books = [], seen = {}, out = [];
    root.select('a').forEach(function (a) {
      var href = a.attr('href') || '';
      var m = /song\/(\d+)\.html/.exec(href);
      if (!m) return;
      var id = m[1];
      if (seen[id]) return;
      var title = textOf(a, 'h3');
      if (!title) return;
      var artist = textOf(a, 'p');
      var cover = imgOf(a.first('.pic')) || imgOf(a);
      seen[id] = 1;
      out.push({
        bookUrl: 'flmp3:song:' + id,
        title: title,
        artist: artist,
        coverUrl: cover,
        intro: artist,
        status: ''
      });
    });
    return out;
  }

  // 全部歌曲：/song.html?page=N
  function songsPage(host, page) {
    try {
      return parseSongs(doc(host, SITE + '/song.html?page=' + page));
    } catch (e) { if (e.cancelled) throw e; return []; }
  }

  // 首页 list 区的「最新 / 热门」面板
  function homePanel(host, which) {
    try {
      var d = doc(host, SITE + '/');
      var items = d.select('.list .item');
      if (!items || !items.length) return [];
      var panel = which === 'new' ? items[0] : (items.length > 1 ? items[1] : items[0]);
      return panel ? parseSongs(panel) : [];
    } catch (e) { if (e.cancelled) throw e; return []; }
  }

  registerSource({
    id: 'a1b2c3d4e5f60718293a4b5c6d7e8f90',
    name: '凤梨音乐',
    url: SITE,
    group: '音乐',
    description: '推荐指数:4星 ⭐⭐⭐⭐\n纯网页音乐源（无加密、无签名），全部歌曲 / 最新 / 热门 + 搜索。点进单曲即播，播放直链来自酷我 CDN。\n站点：flmp3.pro',
    multipleEpisodePages: true,

    categoryMenus: function () {
      return [{
        title: '凤梨音乐',
        tabs: [
          { title: '全部歌曲', url: 'flmp3:list:1' },
          { title: '最新音乐', url: 'flmp3:new' },
          { title: '热门音乐', url: 'flmp3:hot' }
        ]
      }];
    },

    categoryPage: function (url) {
      var host = this.host, key = String(url);
      if (key === 'flmp3:new') {
        return { books: homePanel(host, 'new'), currentPage: 1, totalPage: 1, nextUrl: null };
      }
      if (key === 'flmp3:hot') {
        return { books: homePanel(host, 'hot'), currentPage: 1, totalPage: 1, nextUrl: null };
      }
      var m = /^flmp3:list:(\d+)$/.exec(key);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var page = parseInt(m[1], 10) || 1;
      var books = songsPage(host, page);
      var more = books.length > 0;
      return {
        books: books, currentPage: page, totalPage: more ? page + 1 : page,
        nextUrl: more ? 'flmp3:list:' + (page + 1) : null
      };
    },

    search: function (keywords, page) {
      var word = String(keywords || '').trim();
      if (!word) return { books: [], totalPage: 1 };
      var books = [];
      try {
        books = parseSongs(doc(this.host, SITE + '/search.html?keyword=' + enc(word)));
      } catch (e) { if (e.cancelled) throw e; books = []; }
      return { books: books, totalPage: books.length ? 1 : 1 };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var host = this.host, url = String(bookUrl);
      var m = /^flmp3:song:(\d+)$/.exec(url);
      if (!m) throw new Error('不认识的书籍地址：' + url);
      var id = m[1];
      // 详情页补充歌名 / 歌手 / 封面（用原始 HTML 正则，比 DOM 选择器更稳）
      var title = '', artist = '', cover = '';
      try {
        var raw = host.getString(SITE + '/song/' + id + '.html', opts());
        raw = raw || '';
        var h1 = /<h1[^>]*>(.*?)<\/h1>/i.exec(raw);
        if (h1) title = h1[1].replace(/<[^>]+>/g, '').trim();
        var sm = /歌手：\s*<a[^>]*>(.*?)<\/a>/i.exec(raw);
        if (sm) artist = sm[1].replace(/<[^>]+>/g, '').trim();
        // 取第一个非 logo / 非模板图的封面（详情页首个 img 往往是站点 logo）
        var allImg = raw.match(/<img[^>]+src="([^"]+)"/gi) || [];
        for (var i = 0; i < allImg.length; i++) {
          var sim = /src="([^"]+)"/i.exec(allImg[i]);
          if (!sim) continue;
          var src = sim[1];
          if (src.indexOf('/template') < 0 && src.indexOf('logo') < 0) { cover = src; break; }
        }
      } catch (e) { if (e.cancelled) throw e; }
      if (!title) title = '歌曲' + id;
      return {
        title: title,
        artist: artist,
        coverUrl: cover,
        intro: artist ? ('歌手：' + artist) : '凤梨音乐',
        status: '',
        episodes: [{ title: title + (artist ? ' - ' + artist : ''), url: 'flmp3:play:' + id }]
      };
    },

    // 播放：/api/playurl.php?id={id} 直接返回真实 mp3 直链（已实测为酷我 CDN）
    audio: function (episodeUrl) {
      var key = String(episodeUrl).replace(/^flmp3:play:/, '');
      if (!/^\d+$/.test(key)) throw new Error('不认识的播放地址，请刷新列表');
      var ref = SITE + '/song/' + key + '.html';
      var txt;
      try { txt = this.host.getString(SITE + '/api/playurl.php?id=' + key, opts(ref)); }
      catch (e) { if (e.cancelled) throw e; throw new Error('请求播放地址失败'); }
      txt = (txt || '').trim();
      if (!/^https?:\/\//.test(txt)) throw new Error('没有获取到这一首的播放地址（站点可能已改版）');
      return { url: txt, headers: { Referer: ref, 'User-Agent': UA } };
    },

    audioHeaders: function () { return { Referer: SITE + '/' }; },
    coverHeaders: function () { return { Referer: 'https://www.kuwo.cn/' }; }
  });
})();
