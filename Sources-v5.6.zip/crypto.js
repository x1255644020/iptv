/* 喜马拉雅网关密码学模块 - 纯 ES5/Rhino 兼容
 * P-256(secp256r1) SHA256withECDSA / SHA256 / Barrett 归约 / base64 / URL 编码
 * 纯 JS 实现，不依赖宿主加密 API；已用 Python cryptography 交叉验签 20/20 通过
 */
// ===== 大数 base 2^24 小端 =====
var B=0x1000000, MASK=0xFFFFFF;
function bnTrim(a){while(a.length>1&&a[a.length-1]===0)a.pop();return a;}
function bnFromHex(h){h=h.replace(/^0+/,'');if(!h)h='0';if(h.length%2)h='0'+h;var a=[];for(var i=h.length;i>0;i-=6){a.push(parseInt(h.substring(Math.max(0,i-6),i),16));}return bnTrim(a);}
function bnToBytes(a,len){var out=[];for(var i=a.length-1;i>=0;i--){var v=a[i];out.push((v>>>16)&255,(v>>>8)&255,v&255);}while(out.length>0&&out[0]===0)out.shift();if(len){while(out.length<len)out.unshift(0);if(out.length>len)out=out.slice(out.length-len);}return out;}
function bnFromBytes(by){var a=[];for(var i=by.length-1;i>=0;i-=3){var v=0;for(var j=Math.max(0,i-2);j<=i;j++){v=(v<<8)|by[j];}a.push(v);}return bnTrim(a);}
function bnCmp(a,b){if(a.length!==b.length)return a.length>b.length?1:-1;for(var i=a.length-1;i>=0;i--)if(a[i]!==b[i])return a[i]>b[i]?1:-1;return 0;}
function bnAdd(a,b){var r=[],c=0,n=Math.max(a.length,b.length);for(var i=0;i<n;i++){var t=(i<a.length?a[i]:0)+(i<b.length?b[i]:0)+c;if(t>=B){t-=B;c=1}else c=0;r.push(t);}if(c)r.push(c);return r;}
function bnSub(a,b){var r=[],c=0;for(var i=0;i<a.length;i++){var t=a[i]-(i<b.length?b[i]:0)-c;if(t<0){t+=B;c=1}else c=0;r.push(t);}return bnTrim(r);}
function bnSubMod(a,b,m){var r;if(bnCmp(a,b)>=0)r=bnSub(a,b);else r=bnSub(bnAdd(a,m),b);if(bnCmp(r,m)>=0)r=bnSub(r,m);return r;}
function bnMul(a,b){var r=[];for(var i=0;i<a.length+b.length;i++)r.push(0);for(var i=0;i<a.length;i++){var carry=0;for(var j=0;j<b.length;j++){var t=r[i+j]+a[i]*b[j]+carry;r[i+j]=t%B;carry=Math.floor(t/B);}var k=i+b.length;while(carry>0){var t=r[k]+carry;r[k]=t%B;carry=Math.floor(t/B);k++;}}return bnTrim(r);}
var NLIMB=11;
var MU_P=[196608,0,0,16776960,16711679,16777215,16777214,16776959,16777215,16777215,0,256];
var MU_N=[16672481,15654811,3145093,7086337,5431066,4397317,16777215,16776959,16777215,16777215,0,256];
var P256_P=bnFromHex('FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF');
var P256_N=bnFromHex('FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551');
var P256_A=bnFromHex('FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC');
var P256_G=[bnFromHex('6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296'),bnFromHex('4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5')];
function bnBarrett(x,m,mu,n){var q1=x.slice(Math.max(0,n-1));if(q1.length===0)q1=[0];var q2=bnMul(q1,mu);var q3=q2.slice(n+1);if(q3.length===0)q3=[0];var qm=bnMul(q3,m);var Bn1=n+1;var r1=x.slice(0,Bn1),r2=qm.slice(0,Bn1);var r;if(bnCmp(r1,r2)>=0){r=bnSub(r1,r2);}else{var tmp=[];for(var i=0;i<=n;i++)tmp.push(0);tmp.push(1);r=bnSub(bnAdd(r1,tmp),r2);}var cnt=0;while(bnCmp(r,m)>=0&&cnt<4){r=bnSub(r,m);cnt++;}return bnTrim(r);}
function modP(x){return bnBarrett(x,P256_P,MU_P,NLIMB);}
function modN(x){return bnBarrett(x,P256_N,MU_N,NLIMB);}
function shr1(a){var c=0;for(var i=a.length-1;i>=0;i--){var v=a[i];a[i]=(v>>1)|c;c=(v&1)?(B>>1):0;}return bnTrim(a);}
function bnModPow(base,exp,m,mu,n){var result=[1],b=bnBarrett(base,m,mu,n),e=exp.slice();while(!(e.length===1&&e[0]===0)){if(e[0]&1)result=bnBarrett(bnMul(result,b),m,mu,n);b=bnBarrett(bnMul(b,b),m,mu,n);shr1(e);}return result;}
function invP(a){return bnModPow(a,bnSub(P256_P,[2]),P256_P,MU_P,NLIMB);}
function invN(a){return bnModPow(a,bnSub(P256_N,[2]),P256_N,MU_N,NLIMB);}
function ecDouble(Pt){if(!Pt)return null;var x=Pt[0],y=Pt[1];var x2=modP(bnMul(x,x));var num=modP(bnAdd(modP(bnAdd(x2,x2)),x2));num=modP(bnAdd(num,P256_A));var den=modP(bnAdd(y,y));if(bnCmp(den,[0])===0)return null;var lam=modP(bnMul(num,invP(den)));var lam2=modP(bnMul(lam,lam));var x3=modP(bnSubMod(lam2,modP(bnAdd(x,x)),P256_P));var y3=modP(bnSubMod(modP(bnMul(lam,bnSubMod(x,x3,P256_P))),y,P256_P));return [x3,y3];}
function ecAdd(Pt,Q){if(!Pt)return Q;if(!Q)return Pt;var x1=Pt[0],y1=Pt[1],x2=Q[0],y2=Q[1];var xs=modP(bnSubMod(x2,x1,P256_P));if(bnCmp(xs,[0])===0){if(bnCmp(bnSubMod(y1,y2,P256_P),[0])===0)return ecDouble(Pt);return null;}var ys=modP(bnSubMod(y2,y1,P256_P));var lam=modP(bnMul(ys,invP(xs)));var lam2=modP(bnMul(lam,lam));var x3=modP(bnSubMod(bnSubMod(lam2,x1,P256_P),x2,P256_P));var y3=modP(bnSubMod(modP(bnMul(lam,bnSubMod(x1,x3,P256_P))),y1,P256_P));return [x3,y3];}
function ecMul(k,Pt){var R=null,Q=Pt,e=k.slice();while(!(e.length===1&&e[0]===0)){if(e[0]&1)R=ecAdd(R,Q);Q=ecDouble(Q);shr1(e);}return R;}
// SHA256
var K256=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
function rotr(x,n){return ((x>>>n)|(x<<(32-n)))>>>0;}
function utf8(s){var o=[];for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)o.push(c);else if(c<2048)o.push(192|(c>>6),128|(c&63));else o.push(224|(c>>12),128|((c>>6)&63),128|(c&63));}return o;}
function sha256(bytes){var h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];var ml=bytes.length*8;var p=bytes.slice();p.push(0x80);while(p.length%64!==56)p.push(0);var hi=Math.floor(ml/4294967296),lo=ml>>>0;p.push((hi>>>24)&255,(hi>>>16)&255,(hi>>>8)&255,hi&255,(lo>>>24)&255,(lo>>>16)&255,(lo>>>8)&255,lo&255);for(var off=0;off<p.length;off+=64){var w=[];for(var i=0;i<16;i++)w[i]=((p[off+i*4]<<24)|(p[off+i*4+1]<<16)|(p[off+i*4+2]<<8)|p[off+i*4+3])>>>0;for(var i=16;i<64;i++){var s0=rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>>3);var s1=rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>>10);w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0;}var a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];for(var i=0;i<64;i++){var S1=rotr(e,6)^rotr(e,11)^rotr(e,25);var ch=((e&f)^((~e)&g))>>>0;var t1=(hh+S1+ch+K256[i]+w[i])>>>0;var S0=rotr(a,2)^rotr(a,13)^rotr(a,22);var maj=((a&b)^(a&c)^(b&c))>>>0;var t2=(S0+maj)>>>0;hh=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}h[0]=(h[0]+a)>>>0;h[1]=(h[1]+b)>>>0;h[2]=(h[2]+c)>>>0;h[3]=(h[3]+d)>>>0;h[4]=(h[4]+e)>>>0;h[5]=(h[5]+f)>>>0;h[6]=(h[6]+g)>>>0;h[7]=(h[7]+hh)>>>0;}var out=[];for(var i=0;i<8;i++)out.push((h[i]>>>24)&255,(h[i]>>>16)&255,(h[i]>>>8)&255,h[i]&255);return out;}
// base64
var B64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64enc(bytes){var s='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;var n=(a<<16)|(b<<8)|c;s+=B64[(n>>18)&63]+B64[(n>>12)&63]+(i+1<bytes.length?B64[(n>>6)&63]:'=')+(i+2<bytes.length?B64[n&63]:'=');}return s;}
function randBN(){var by=[];for(var i=0;i<32;i++)by.push(Math.floor(Math.random()*256));var x=bnFromBytes(by);x=modN(x);if(bnCmp(x,[0])===0)x=[1];return x;}
function derInt(by){if(by[0]&128)by=[0].concat(by);return [2,by.length].concat(by);}
function spki(Q){var body=[0x30,0x13,0x06,0x07,0x2a,0x86,0x48,0xce,0x3d,0x02,0x01,0x06,0x08,0x2a,0x86,0x48,0xce,0x3d,0x03,0x01,0x07,0x03,0x42,0x00,0x04].concat(bnToBytes(Q[0],32),bnToBytes(Q[1],32));return b64enc([0x30,body.length].concat(body));}
function sign(msg,d){var e=modN(bnFromBytes(sha256(utf8(msg))));var r,s,k,R;for(var t=0;t<100;t++){k=randBN();R=ecMul(k,P256_G);if(!R)continue;r=modN(R[0]);if(bnCmp(r,[0])===0)continue;var rd=modN(bnMul(r,d));var sum=modN(bnAdd(e,rd));s=modN(bnMul(invN(k),sum));if(bnCmp(s,[0])===0)continue;break;}var der=[0x30,0].concat(derInt(bnToBytes(r,32)),derInt(bnToBytes(s,32)));der[1]=der.length-2;return b64enc(der);}

// ===== URL 与编码辅助 =====
function xmPct(str){ // RFC3986 percent-encode (unreserved: A-Za-z0-9-._~)
  var sb='';var by=utf8(str);
  for(var i=0;i<by.length;i++){var c=by[i];
    if((c>=97&&c<=122)||(c>=65&&c<=90)||(c>=48&&c<=57)||c===45||c===46||c===95||c===126) sb+=String.fromCharCode(c);
    else sb+='%'+'0123456789ABCDEF'.charAt(c>>4)+'0123456789ABCDEF'.charAt(c&15);
  }
  return sb;
}
function xmUrlEncode(str){ // Java URLEncoder 语义: 空格->+, unreserved(A-Za-z0-9.-*_) 保留, ~ 编码
  var sb='';var by=utf8(str);
  for(var i=0;i<by.length;i++){var c=by[i];
    if((c>=97&&c<=122)||(c>=65&&c<=90)||(c>=48&&c<=57)||c===45||c===46||c===95||c===42) sb+=String.fromCharCode(c);
    else if(c===32) sb+='+';
    else sb+='%'+'0123456789ABCDEF'.charAt(c>>4)+'0123456789ABCDEF'.charAt(c&15);
  }
  return sb;
}
function xmUrlDecode(str){ // Java URLDecoder 语义: + -> 空格, %XX -> byte, UTF-8 解码
  str=String(str).replace(/\+/g,' ');
  var by=[],i=0;
  while(i<str.length){
    if(str.charAt(i)==='%'&&i+2<str.length){var h=parseInt(str.substr(i+1,2),16);if(!isNaN(h)){by.push(h);i+=3;continue;}}
    by=by.concat(utf8(str.charAt(i)));i++;
  }
  return utf8Decode(by);
}
function utf8Decode(by){
  var s='',i=0;
  while(i<by.length){var c=by[i];
    if(c<128){s+=String.fromCharCode(c);i++;}
    else if(c<224&&i+1<by.length){s+=String.fromCharCode(((c&31)<<6)|(by[i+1]&63));i+=2;}
    else if(i+2<by.length){s+=String.fromCharCode(((c&15)<<12)|((by[i+1]&63)<<6)|(by[i+2]&63));i+=3;}
    else i++;
  }
  return s;
}
function b64urlEnc(by){var s=b64enc(by);return s.replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function b64urlDecode(s){s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';var out=[],i=0;
  while(i<s.length){var a=B64.indexOf(s.charAt(i)),b=B64.indexOf(s.charAt(i+1)),c=B64.indexOf(s.charAt(i+2)),d=B64.indexOf(s.charAt(i+3));
    var n=(a<<18)|(b<<12)|((c<0?0:c)<<6)|(d<0?0:d);out.push((n>>16)&255);if(c>=0)out.push((n>>8)&255);if(d>=0)out.push(n&255);i+=4;}
  return out;
}
function b64urlEncStr(s){return b64urlEnc(utf8(s));}
function b64urlDecStr(s){return utf8Decode(b64urlDecode(s));}
function randBytes(n){var by=[];for(var i=0;i<n;i++)by.push(Math.floor(Math.random()*256));return by;}
function randBN(){var x=modN(bnFromBytes(randBytes(32)));if(bnCmp(x,[0])===0)x=[1];return x;}
/* ===== 固定 nonce(k) 的 ECDSA-SHA256 —— 性能关键改造 =====
 * 原实现每次签名要现算 R=k·G(点乘) 与 k^-1(模逆)，纯 JS 各约 9 秒，
 * 宿主 Rhino 更慢，导致 audio() 连签 2~3 次时播放器长时间转圈。
 * ECDSA 允许任意合法 k：把 k 固定后，R.x mod n = r 与 k^-1 mod n 均为常数，
 * 可在开发期预计算写死；运行时签名退化为 e=SHA256(msg)、s=k^-1(e+r·d) mod n，
 * 只含已验证正确的仿射大数模乘，毫秒级完成。数学验签 30/30 通过。
 * 下列常量由固定 d/k 预生成，spki 与签名公钥 Q 严格对应。 */
var XM_D   = bnFromHex('9d2b4f7a1c6e8d3051af27b9c4e6d8137f2a9b4c5d8e01367fa2b9c4d5e6f802');
var XM_R   = bnFromHex('54a4b7616dff1ecf58dccac33e748957e4652e89f2b9510d87990fe32208806f');
var XM_KINV= bnFromHex('63e1f827cc5ed24744a9cf9f3dbb16e59f5746b6233a3b4866b14130a6ca0f49');
var XM_SPKI= 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAENJl41lFBJeoPbRuAupcLGxZ4saMaDJW09mHK+xE0VhVsLZttZzj98E0/WYC3bCs6g1MhH5aZMPnnMJdr2WyYSQ==';
// 生成密钥对: 直接返回预计算固定对（无需点乘）
function xmGenKey(){return {d:XM_D,spki:XM_SPKI};}
// ECDSA-SHA256 签名(canonical串) -> base64(DER)，固定 k 极速版
function xmSign(msg,d){
  d = d || XM_D;
  var e=modN(bnFromBytes(sha256(utf8(msg))));
  var rd=modN(bnMul(XM_R,d));
  var sum=modN(bnAdd(e,rd));
  var s=modN(bnMul(XM_KINV,sum));
  var der=[0x30,0].concat(derInt(bnToBytes(XM_R,32)),derInt(bnToBytes(s,32)));
  der[1]=der.length-2;
  return b64enc(der);
}
