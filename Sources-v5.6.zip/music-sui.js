// 随心音乐源 v0.2.9（六源：网易云/酷狗/酷我/咪咕/QQ/汽水）移植入 ShunSources 5.6，IIFE 封装避免顶层符号撞车
(function () {
// 随心音乐源 · 随身听书 ZIP 脚本版
// 协议对齐 sources_by_music.jar 的扩展行为：
//   * Episode 标题 =「歌名 － 歌手」（全角 － ，歌手为空只写歌名）
//   * 虚拟链接自包含 id 与 t/a/c 参数（标题/歌手/封面），audio/lrc/cover 按参数解析
//   * 歌词返回 SRT（jar 端同款 LRC→SRT 转换），封面优先链接内 c= 参数
// ES5 语法（Rhino 1.7.15 不支持 async/默认参数）。
//
// v0.1.0：网易云音乐打样。

var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
var SEP = ' － '; // 全角空格 + 全角连字符 + 全角空格

/** 标题拼接：与 jar 端 SourceEntry.joinTitle 语义一致 */
function joinTitle(name, artist) {
  if (!name) return '';
  if (!artist) return name;
  return name + SEP + artist;
}

function enc(s) {
  try { return encodeURIComponent(String(s === null || s === undefined ? '' : s)); }
  catch (e) { return String(s); }
}

function dec(s) {
  try { return decodeURIComponent(String(s)); }
  catch (e) { return String(s); }
}

/** 视为活着的 HTTP 状态（对齐 jar AudioLinkResolver.alive） */
function aliveStatus(code) {
  return code === 200 || code === 206 || code === 301 || code === 302 ||
    code === 303 || code === 307 || code === 308;
}

/** 解析虚拟链接：scheme://host/id?query → {scheme,id,params{t,a,c}}（对齐 jar LrcResolver.parse） */
function parseVirtual(url) {
  var out = { scheme: '', id: '', title: '', artist: '', cover: '' };
  var s = String(url || '');
  var i = s.indexOf('://');
  if (i < 0) return out;
  out.scheme = s.substring(0, i);
  var rest = s.substring(i + 3);
  var q = rest.indexOf('?');
  var path = q >= 0 ? rest.substring(0, q) : rest;
  var query = q >= 0 ? rest.substring(q + 1) : '';
  var segs = path.split('/');
  if (segs.length >= 2) out.id = dec(segs[1]);
  var pairs = query.split('&');
  for (var k = 0; k < pairs.length; k++) {
    var p = pairs[k];
    var eq = p.indexOf('=');
    if (eq <= 0) continue;
    var key = dec(p.substring(0, eq));
    var val = dec(p.substring(eq + 1));
    if (key === 't') out.title = val;
    else if (key === 'a') out.artist = val;
    else if (key === 'c') out.cover = val;
  }
  return out;
}

/* ============================ LRC → SRT（对齐 jar LrcResolver.lrcToSrt） ============================ */

function srtFmt(ms) {
  var h = Math.floor(ms / 3600000);
  var m = Math.floor((ms % 3600000) / 60000);
  var s = Math.floor((ms % 60000) / 1000);
  var x = ms % 1000;
  function p2(v) { return (v < 10 ? '0' : '') + v; }
  function p3(v) { return (v < 10 ? '00' : v < 100 ? '0' : '') + v; }
  return p2(h) + ':' + p2(m) + ':' + p2(s) + ',' + p3(x);
}

function lrcToSrt(lrcText) {
  if (!lrcText) return '';
  var lines = String(lrcText).split(/\r?\n/);
  var entries = [];
  var re = /\[(\d+):(\d+)[.:](\d+)\]/g;
  for (var li = 0; li < lines.length; li++) {
    var line = lines[li].trim();
    if (!line) continue;
    var marks = [];
    var m;
    re.lastIndex = 0;
    while ((m = re.exec(line)) !== null) {
      var min = parseInt(m[1], 10) || 0;
      var sec = parseInt(m[2], 10) || 0;
      var csTxt = (m[3] + '00').substring(0, 2);
      var cs = parseInt(csTxt, 10) || 0;
      marks.push(min * 60000 + sec * 1000 + cs * 10);
    }
    if (marks.length === 0) continue;
    // 取最后一个时间标记之后的文本
    var idx = 0;
    var r2 = /\[(\d+):(\d+)[.:](\d+)\]/g;
    var mm;
    while ((mm = r2.exec(line)) !== null) idx = mm.index + mm[0].length;
    var text = line.substring(idx).trim().replace(/&nbsp;/g, ' ');
    if (!text) continue;
    for (var j = 0; j < marks.length; j++) entries.push({ ms: marks[j], text: text });
  }
  if (entries.length === 0) return '';
  entries.sort(function (a, b) { return a.ms - b.ms; });
  var out = [];
  for (var i2 = 0; i2 < entries.length; i2++) {
    var cur = entries[i2];
    var end = i2 + 1 < entries.length ? entries[i2 + 1].ms : cur.ms + 4000;
    if (end <= cur.ms) end = cur.ms + 1;
    out.push(String(i2 + 1));
    out.push(srtFmt(cur.ms) + ' --> ' + srtFmt(end));
    out.push(cur.text);
    out.push('');
  }
  return out.join('\n');
}

function hasLrcText(s) {
  return !!s && s.indexOf('[') >= 0 && s.indexOf(':') >= 0;
}

/* ============================ 网易云音乐 ============================ */

var METING = 'https://api.qijieya.cn/meting/';
var SITE = 'https://music.163.com';
var STYLES = ['华语', '流行', '摇滚', '民谣', '电子', '说唱', '轻音乐', '古风', '怀旧',
  '影视原声', 'ACG', '粤语', '欧美', '日语', '韩语', '古典', '爵士', '儿童'];

var RANKS = [
  ['飙升榜', '19723756'], ['新歌榜', '3779629'], ['原创榜', '2884035'], ['热歌榜', '3778678'],
  ['网易云古典榜', '71384707'], ['网易云电音榜', '1978921795'], ['网易云中文说唱榜', '991319590'],
  ['网易云ACG榜', '71385702'],
];

function neteaseHttp(url, referer) {
  var headers = { 'User-Agent': UA };
  if (referer) headers['Referer'] = referer;
  return String(this.host.getString(url, { headers: headers }) || '');
}

function neteaseSongBook(pic, id, name, artist) {
  return {
    coverUrl: pic || '',
    bookUrl: 'netease://song/' + id + '?t=' + enc(name) + '&a=' + enc(artist),
    title: name || '',
    author: artist || '',
    artist: '',
    // v0.2.2：歌卡不填 intro——发现页封面行会把 intro 渲染成第三行，
    // 原来每首歌下面都挂一条「网易云音乐歌曲」，与其他源（intro 空）不一致
    intro: '',
    status: '',
  };
}

function neteaseAddPlaylistBook(list, o) {
  var id = String(o.id || '');
  var name = String(o.name || '');
  var cover = String(o.coverImgUrl || '');
  var creator = o.creator || null;
  var nickname = creator ? String(creator.nickname || '') : '';
  var trackCount = o.trackCount || 0;
  if (!id || !name) return;
  list.push({
    coverUrl: cover,
    bookUrl: 'netease://playlist/' + id,
    title: name,
    author: nickname,
    artist: '',
    intro: '',
    status: trackCount > 0 ? trackCount + '首' : '歌单',
  });
}

/** meting 搜索一页（对齐 jar searchSongsOnce，失败回退官方搜索） */
function neteaseSearchSongsOnce(keywords, page) {
  var list = [];
  try {
    var url = METING + '?type=search&id=' + enc(keywords) + '&source=netease';
    var body = neteaseHttp.call(this, url, '');
    var arr = JSON.parse(body);
    if (arr && arr.length) {
      for (var i = 0; i < arr.length; i++) {
        var it = arr[i];
        if (!it) continue;
        var name = String(it.name || '');
        var artist = String(it.artist || '');
        var pic = String(it.pic || '');
        var songUrl = String(it.url || '');
        var m = /id=(\d+)/.exec(songUrl);
        if (!m) continue;
        list.push(neteaseSongBook(pic, m[1], name, artist));
      }
      return { list: list, totalPage: page };
    }
  } catch (e) { /* meting 失败走官方 */ }
  // 官方搜索兜底
  try {
    var u2 = SITE + '/api/search/get/web?s=' + enc(keywords) + '&type=1&limit=30';
    var b2 = neteaseHttp.call(this, u2, SITE + '/');
    if (!b2) return { list: list, totalPage: page };
    var j2 = JSON.parse(b2);
    var result = j2 && j2.result ? j2.result : null;
    var songs = result && result.songs ? result.songs : null;
    if (songs) {
      for (var k = 0; k < songs.length; k++) {
        var sg = songs[k];
        if (!sg) continue;
        var id = String(sg.id || '').trim();
        var nm = String(sg.name || '').trim();
        var arts = sg.artists || [];
        var joined = [];
        for (var a = 0; a < arts.length; a++) {
          if (arts[a] && arts[a].name) joined.push(String(arts[a].name).trim());
        }
        var artName = joined.join('/');
        if (!id || !nm) continue;
        list.push(neteaseSongBook('', id, nm, artName));
      }
    }
  } catch (e2) { /* 忽略 */ }
  return { list: list, totalPage: page };
}

/** 搜索重试链（对齐 jar searchSongs）：once ×2 → 官方 → once → 官方 */
function neteaseSearchSongs(keywords, page) {
  var r = neteaseSearchSongsOnce.call(this, keywords, page);
  if (!r.list.length) { this.host.sleep(1000); r = neteaseSearchSongsOnce.call(this, keywords, page); }
  if (!r.list.length) { this.host.sleep(2500); r = neteaseSearchSongsOnce.call(this, keywords, page); }
  if (!r.list.length) r = neteaseSearchSongsOfficial.call(this, keywords, page);
  if (!r.list.length) { this.host.sleep(2000); r = neteaseSearchSongsOnce.call(this, keywords, page); }
  if (!r.list.length) r = neteaseSearchSongsOfficial.call(this, keywords, page);
  return r;
}

/** 官方分页搜索（对齐 jar searchSongsOfficial） */
function neteaseSearchSongsOfficial(keywords, page) {
  var list = [];
  try {
    var offset = (page - 1) * 30;
    var url = SITE + '/api/search/get/web?s=' + enc(keywords) + '&type=1&limit=30&offset=' + offset;
    var body = neteaseHttp.call(this, url, SITE + '/');
    var j = JSON.parse(body);
    var result = j && j.result ? j.result : null;
    var songs = result && result.songs ? result.songs : null;
    if (!songs) return { list: list, totalPage: list.length ? page : 1 };
    for (var i = 0; i < songs.length; i++) {
      var sg = songs[i];
      if (!sg) continue;
      var name = String(sg.name || '');
      var arts = sg.artists || [];
      var joined = [];
      for (var a = 0; a < arts.length; a++) {
        if (arts[a] && arts[a].name) joined.push(String(arts[a].name));
      }
      var artName = joined.join(', ');
      var id = sg.id || 0;
      if (id <= 0) continue;
      list.push(neteaseSongBook('', String(id), name, artName));
    }
    var songCount = result.songCount || 0;
    var totalPage;
    if (songCount > 0) totalPage = Math.ceil(songCount / 30);
    else totalPage = list.length ? page : 1;
    return { list: list, totalPage: totalPage };
  } catch (e) {
    return { list: list, totalPage: list.length ? page : 1 };
  }
}

/** 详情：搜索聚合（对齐 jar searchbook 分支） */
function neteaseSearchbookDetail(kw) {
  var episodes = [];
  var seen = {};
  var shellCover = '';
  for (var page = 1; page <= 10; page++) {
    var r = neteaseSearchSongs.call(this, kw, page);
    var before = episodes.length;
    for (var i = 0; i < r.list.length; i++) {
      var b = r.list[i];
      if (!b.bookUrl || seen[b.bookUrl]) continue;
      seen[b.bookUrl] = true;
      // v0.2.3：第一首歌的封面作合集书封面（歌曲没封面时播放页回落用它）
      if (!shellCover && b.coverUrl) shellCover = b.coverUrl;
      var v = parseVirtual(b.bookUrl);
      episodes.push({ title: joinTitle(b.title, b.author), url: 'netease://url/' + v.id + '?t=' + enc(b.title) + '&a=' + enc(b.author) });
    }
    if (episodes.length === before || r.totalPage <= page) break;
  }
  if (episodes.length === 0) {
    episodes.push({ title: '搜索加载失败，请返回后重试', url: '' });
  }
  return {
    episodes: episodes,
    intro: '【搜索结果】\n共 ' + episodes.length + ' 首，结果合集连播（自动顺播下一首）。\n\n来源：网易云音乐。［v2 · 2026-11］',
    artist: '',
    author: '',
    coverUrl: shellCover,
    title: '搜索：' + kw,
    status: '',
  };
}

/** 详情：歌单（对齐 jar playlist 分支） */
function neteasePlaylistDetail(id) {
  var episodes = [];
  // v0.2.3：歌单封面——官方歌单详情接口取 coverImgUrl；失败回落第一首歌的封面。
  // 歌曲没封面时播放页回落到它（封面规则②：歌曲封面 → 歌单封面）
  var shellCover = '';
  try {
    var pb = neteaseHttp.call(this, SITE + '/api/v6/playlist/detail?id=' + id + '&n=0', SITE + '/');
    var pj = JSON.parse(pb);
    var pc = pj && pj.result && pj.result.playlist ? pj.result.playlist.coverImgUrl : '';
    if (pc && /^https?:\/\//.test(String(pc))) shellCover = String(pc);
  } catch (e) { /* 回落第一首 pic */ }
  try {
    var url = METING + '?server=netease&type=playlist&id=' + id;
    var body = neteaseHttp.call(this, url, '');
    var arr = JSON.parse(body);
    for (var i = 0; i < arr.length; i++) {
      var it = arr[i];
      if (!it) continue;
      var name = String(it.name || '');
      var artist = String(it.artist || '');
      var pic = String(it.pic || '');
      if (!shellCover && pic && /^https?:\/\//.test(pic)) shellCover = pic;
      var m = /id=(\d+)/.exec(String(it.url || ''));
      if (!m) continue;
      episodes.push({
        title: joinTitle(name, artist),
        url: 'netease://url/' + m[1] + '?t=' + enc(name) + '&a=' + enc(artist) + '&c=' + enc(pic),
      });
    }
  } catch (e) { /* 返回空列表 */ }
  return {
    episodes: episodes,
    intro: '网易云歌单',
    artist: '',
    author: '',
    coverUrl: shellCover,
    title: '网易云歌单',
    status: '',
  };
}

/** 详情：单曲（标题/歌手来自链接参数） */
function neteaseSongDetail(v) {
  var title = joinTitle(v.title || '播放', v.artist);
  return {
    episodes: [{ title: title, url: 'netease://url/' + v.id + '?t=' + enc(v.title) + '&a=' + enc(v.artist) }],
    intro: '网易云音乐歌曲',
    artist: '',
    author: '',
    coverUrl: '',
    title: '网易云音乐歌曲',
    status: '',
  };
}

/** 分类页：推荐歌单 / 排行榜列表 / 风格歌单（对齐 jar getCategoryList） */
function neteaseCategoryPage(rawUrl) {
  var url = String(rawUrl || '');
  var page = 1;
  var hash = url.indexOf('#');
  if (hash >= 0) {
    var n = parseInt(url.substring(hash + 1), 10);
    if (!isNaN(n) && n > 0) page = n;
    url = url.substring(0, hash);
  }
  var books = [];
  var nextUrl = '';
  try {
    if (url.indexOf('netease://ranklist/') === 0) {
      var id = url.substring('netease://ranklist/'.length);
      var q = id.indexOf('?');
      if (q >= 0) id = id.substring(0, q);
      var body = neteaseHttp.call(this, METING + '?server=netease&type=playlist&id=' + id, '');
      var arr = JSON.parse(body);
      for (var i = 0; i < arr.length; i++) {
        var it = arr[i];
        if (!it) continue;
        var m = /id=(\d+)/.exec(String(it.url || ''));
        if (!m) continue;
        books.push(neteaseSongBook(String(it.pic || ''), m[1], String(it.name || ''), String(it.artist || '')));
      }
    } else if (url === 'netease:recommend') {
      var b1 = neteaseHttp.call(this, SITE + '/api/personalized/playlist?limit=30', SITE + '/');
      var j1 = JSON.parse(b1);
      var r1 = j1 && j1.result ? j1.result : [];
      for (var k1 = 0; k1 < r1.length; k1++) neteaseAddPlaylistBook(books, r1[k1]);
    } else if (url === 'netease:top') {
      var b2 = neteaseHttp.call(this, SITE + '/api/toplist', SITE + '/');
      var j2 = JSON.parse(b2);
      var r2 = j2 && j2.list ? j2.list : [];
      for (var k2 = 0; k2 < r2.length; k2++) neteaseAddPlaylistBook(books, r2[k2]);
    } else if (url.indexOf('netease:cat:') === 0) {
      var cat = url.substring('netease:cat:'.length);
      var b3 = neteaseHttp.call(this, SITE + '/api/playlist/list?cat=' + enc(cat) + '&order=hot&limit=30&offset=' + ((page - 1) * 30), SITE + '/');
      var j3 = JSON.parse(b3);
      var pl = j3 && j3.playlists ? j3.playlists : [];
      for (var k3 = 0; k3 < pl.length; k3++) neteaseAddPlaylistBook(books, pl[k3]);
      if (j3 && j3.more && pl.length > 0) nextUrl = url + '#' + (page + 1);
    }
  } catch (e) { /* 返回空 */ }
  return { books: books, currentPage: page, totalPage: nextUrl ? page + 1 : page, nextUrl: nextUrl };
}

/** 播放地址：id → meting 直链优先，官方外链兜底 */
function neteaseAudio(episodeUrl) {
  var s = String(episodeUrl || '');
  var id = '';
  if (s.indexOf('netease://song/') === 0) {
    id = s.substring('netease://song/'.length);
    var q = id.indexOf('?');
    if (q >= 0) id = id.substring(0, q);
  } else if (s.indexOf('netease://url/') === 0) {
    id = parseVirtual(s).id;
  }
  if (!id) return s;
  var meting = METING + '?server=netease&type=url&id=' + id;
  var outer = SITE + '/song/media/outer/url?id=' + id + '.mp3';
  try {
    var st = this.host.status(meting, { headers: { 'User-Agent': UA } });
    var code = parseInt(String(st), 10);
    if (aliveStatus(code)) return { url: meting };
  } catch (e) { /* 探活失败试外链 */ }
  try {
    var st2 = this.host.status(outer, { headers: { 'User-Agent': UA } });
    var code2 = parseInt(String(st2), 10);
    if (aliveStatus(code2)) return { url: outer };
  } catch (e2) { /* 都失败返回 meting 让播放器裁决 */ }
  return { url: meting };
}

/** 歌词：id 直取，失败按标题搜索；返回 SRT（对齐 jar LrcResolver） */
function neteaseLrc(episodeUrl) {
  var v = parseVirtual(episodeUrl);
  var lrc = '';
  if (v.id) {
    lrc = neteaseLrcById.call(this, v.id);
  }
  if (!hasLrcText(lrc) && v.title) {
    var kw = v.title + (v.artist ? ' ' + v.artist : '');
    var id2 = neteaseSearchFirstId.call(this, kw);
    if (id2) lrc = neteaseLrcById.call(this, id2);
  }
  if (!hasLrcText(lrc) && v.title) {
    var id3 = neteaseSearchFirstId.call(this, v.title);
    if (id3) lrc = neteaseLrcById.call(this, id3);
  }
  if (!hasLrcText(lrc)) return '';
  return lrcToSrt(lrc);
}

function neteaseLrcById(id) {
  try {
    var body = neteaseHttp.call(this, SITE + '/api/song/lyric?os=pc&id=' + id + '&lv=1&kv=1&tv=-1', SITE + '/');
    if (!body) return '';
    var j = JSON.parse(body);
    return j && j.lrc && j.lrc.lyric ? String(j.lrc.lyric) : '';
  } catch (e) { return ''; }
}

function neteaseSearchFirstId(kw) {
  try {
    var body = neteaseHttp.call(this, SITE + '/api/search/get/web?s=' + enc(kw) + '&type=1&offset=0&limit=1', SITE + '/');
    if (!body) return '';
    var j = JSON.parse(body);
    var songs = j && j.result && j.result.songs ? j.result.songs : null;
    if (songs && songs.length && songs[0] && songs[0].id) return String(songs[0].id);
  } catch (e) { /* 忽略 */ }
  return '';
}

/** 封面：c= 参数优先 → 按 id → 按标题搜索 */
function neteaseCover(episodeUrl) {
  var v = parseVirtual(episodeUrl);
  if (v.cover && /^https?:\/\//.test(v.cover)) return v.cover;
  if (v.id) {
    try {
      var body = neteaseHttp.call(this, SITE + '/api/song/detail?ids=[' + v.id + ']', SITE + '/');
      if (body) {
        var j = JSON.parse(body);
        var songs = j && j.songs ? j.songs : null;
        if (songs && songs.length && songs[0] && songs[0].album && songs[0].album.picUrl) {
          return String(songs[0].album.picUrl);
        }
      }
    } catch (e) { /* 走搜索兜底 */ }
  }
  if (v.title) {
    try {
      var kw = v.title + (v.artist ? ' ' + v.artist : '');
      var body2 = neteaseHttp.call(this, SITE + '/api/search/get/web?s=' + enc(kw) + '&type=1&offset=0&limit=1', SITE + '/');
      if (body2) {
        var j2 = JSON.parse(body2);
        var songs2 = j2 && j2.result && j2.result.songs ? j2.result.songs : null;
        if (songs2 && songs2.length && songs2[0]) {
          var al = songs2[0].album || null;
          if (al && al.picUrl) return String(al.picUrl);
        }
      }
    } catch (e2) { /* 忽略 */ }
  }
  return '';
}

registerSource({
  id: 'zip_netease',
  name: '网易云音乐',
  url: SITE,
  description: '网易云音乐（ZIP 脚本版）：搜索/歌单/排行榜/分类浏览，播放地址、歌词、封面解析。',
  group: '音乐类',
  searchable: true,
  discoverable: true,
  multipleEpisodePages: false,
  enabledByDefault: true,
  search: function (keywords, page) {
    var kw = String(keywords === null || keywords === undefined ? '' : keywords).trim();
    if (!kw) return { books: [], totalPage: 1 };
    var books = [{
      coverUrl: '',
      bookUrl: 'netease://searchbook?kw=' + enc(kw) + '&t=' + enc('搜索：' + kw),
      title: '搜索：' + kw,
      author: '',
      artist: '',
      intro: '',
      status: '',
    }];
    try {
      var r = neteaseSearchSongs.call(this, kw, 1);
      if (r && r.list) books = books.concat(r.list);
    } catch (e) { /* 搜索失败仍返回卡片 */ }
    return { books: books, totalPage: 1 };
  },
  bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
    var s = String(bookUrl || '');
    if (s.indexOf('netease://searchbook') === 0) {
      var kw = '';
      var q = s.indexOf('?');
      if (q >= 0) {
        var pairs = s.substring(q + 1).split('&');
        for (var i = 0; i < pairs.length; i++) {
          var p = pairs[i];
          var eq = p.indexOf('=');
          if (eq <= 0) continue;
          if (p.substring(0, eq) === 'kw') kw = dec(p.substring(eq + 1));
        }
      }
      if (loadEpisodes) return neteaseSearchbookDetail.call(this, kw);
      return { episodes: [], intro: '', artist: '', author: '', coverUrl: '', title: '', status: '' };
    }
    if (s.indexOf('netease://song/') === 0) {
      return neteaseSongDetail.call(this, parseVirtual(s));
    }
    if (s.indexOf('netease://playlist/') === 0) {
      var id = s.substring('netease://playlist/'.length);
      var h = id.indexOf('#');
      if (h >= 0) id = id.substring(0, h);
      return neteasePlaylistDetail.call(this, id);
    }
    return { episodes: [], intro: '网易云音乐歌曲', artist: '', author: '', coverUrl: '', title: '网易云音乐歌曲', status: '' };
  },
  categoryMenus: function () {
    var recommend = [{ title: '推荐歌单', url: 'netease:recommend' }, { title: '排行榜', url: 'netease:top' }];
    for (var i = 0; i < RANKS.length; i++) {
      recommend.push({ title: RANKS[i][0], url: 'netease://ranklist/' + RANKS[i][1] + '?t=' + enc(RANKS[i][0]) });
    }
    var playlists = [{ title: '全部', url: 'netease:cat:全部' }];
    for (var j = 0; j < STYLES.length; j++) {
      playlists.push({ title: STYLES[j], url: 'netease:cat:' + STYLES[j] });
    }
    return [
      { title: '推荐', tabs: recommend },
      { title: '歌单', tabs: playlists },
    ];
  },
  categoryPage: function (url) {
    return neteaseCategoryPage.call(this, url);
  },
  audio: function (episodeUrl) {
    return neteaseAudio.call(this, episodeUrl);
  },
  lrc: function (episodeUrl) {
    return neteaseLrc.call(this, episodeUrl);
  },
  cover: function (episodeUrl) {
    return neteaseCover.call(this, episodeUrl);
  },
});

/* ================================================================================================
 * part2：酷狗 / 酷我 / 咪咕 / QQ / 汽水（对齐 sources_by_music.jar 扩展行为）
 *   * 换源播放链：本源直链（酷我/咪咕）→ 酷我兜底（KuwoFallback）→ 网易云兜底（NetEaseFallback）
 *   * 匹配评分：标题相似度 0.6 + 歌手 0.4 + 时长加分，硬版本词（cover/伴奏/纯音乐/钢琴）拒配
 *   * 歌词/封面：scheme 直取 → 网易搜索 → 酷我搜索 → 酷我 id（对齐 jar LrcResolver/CoverResolver）
 * ============================================================================================== */

/* ============================ 共享 HTTP / 解析工具 ============================ */

var UA_OKHTTP = 'okhttp/3.10.0';
var UA_ANDROID_MG = 'Mozilla/5.0 (Linux; U; Android 11.0.0; zh-cn; MI 11 Build/OPR1.170623.032) AppleWebKit/534.30 Version/4.0 Mobile Safari/534.30';
var UA_IPHONE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1';
var UA_PC_106 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36';

function httpX(url, headers) {
  var opts = { headers: headers || {} };
  return String(this.host.getString(url, opts) || '');
}

function postJsonX(url, body, headers) {
  var opts = { headers: headers || {}, method: 'POST', body: body, contentType: 'application/json' };
  return String(this.host.getString(url, opts) || '');
}

function statusX(url, headers) {
  return parseInt(String(this.host.status(url, { headers: headers || {} })), 10);
}

/** 宽松 JSON：单引号替换后重试（对齐 jar parseLoose） */
function parseLoose(s) {
  try { return JSON.parse(s); } catch (e) {
    try { return JSON.parse(String(s).replace(/'/g, '"')); } catch (e2) { return null; }
  }
}

function stripEm(s) { return String(s || '').replace(/<\/?em>/g, ''); }

function firstNE(a, b) {
  if (a && String(a).trim()) return a;
  return b === null || b === undefined ? '' : b;
}

/** 宽松取字段：在响应全文中匹配 "key":"value"（对齐 jar jsonString） */
/** JSON 字符串值反转义：正则从 JSON 原文截取的值带 \"\/\\u 等转义序列，必须还原
 * （v0.2.5 修复：酷狗榜单封面/网易封面带字面 \/ 导致首帧封面加载失败） */
function jsonUnescape(s) {
  return String(s || '')
    .replace(/\\u([0-9a-fA-F]{4})/g, function (_, h) { return String.fromCharCode(parseInt(h, 16)); })
    .replace(/\\(["\\/bfnrt])/g, function (_, c) {
      if (c === '/') return '/';
      if (c === 'b') return '\b';
      if (c === 'f') return '\f';
      if (c === 'n') return '\n';
      if (c === 'r') return '\r';
      if (c === 't') return '\t';
      return c;
    });
}

function looseField(body, key) {
  var m = new RegExp('"' + key + '"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"').exec(String(body || ''));
  return m ? jsonUnescape(m[1]) : '';
}

/** 解析虚拟链接（part2 版）：额外支持 al/d 参数与多段路径 */
function parseV2(url) {
  var v = { scheme: '', kind: '', id: '', p: 0, kw: '', title: '', artist: '', album: '', cover: '', d: 0 };
  var s = String(url || '');
  var i = s.indexOf('://');
  if (i < 0) return v;
  v.scheme = s.substring(0, i);
  var rest = s.substring(i + 3);
  var q = rest.indexOf('?');
  var path = q >= 0 ? rest.substring(0, q) : rest;
  var query = q >= 0 ? rest.substring(q + 1) : '';
  var segs = path.split('/');
  v.kind = segs[0] || '';
  if (segs.length >= 2) v.id = dec(segs[1]);
  var pairs = query.split('&');
  for (var k = 0; k < pairs.length; k++) {
    var p = pairs[k];
    var eq = p.indexOf('=');
    if (eq <= 0) continue;
    var key = dec(p.substring(0, eq));
    var val = dec(p.substring(eq + 1));
    if (key === 't') v.title = val;
    else if (key === 'a') v.artist = val;
    else if (key === 'al') v.album = val;
    else if (key === 'c') v.cover = val;
    else if (key === 'd') v.d = parseInt(val, 10) || 0;
    else if (key === 'p') v.p = parseInt(val, 10) || 0;
    else if (key === 'kw') v.kw = val;
  }
  if (v.p <= 0) v.p = 1;
  return v;
}

/** 拼 scheme://song 虚拟链接 */
function songUrl2(scheme, segs, t, a, al, d, c) {
  var u = scheme + '://song/' + segs + '?t=' + enc(t || '') + '&a=' + enc(a || '');
  if (al !== null && al !== undefined) u += '&al=' + enc(al);
  if (d) u += '&d=' + d;
  if (c) u += '&c=' + enc(c);
  return u;
}

function mkBook2(cover, url, title, artist, sourceName) {
  return { coverUrl: cover || '', bookUrl: url, title: title || '', author: artist || '', artist: '', intro: '', status: '' };
  // sourceName 参数留作对齐 jar mkBook 语义
}

function searchbookUrl(scheme, kw) {
  return scheme + '://searchbook?kw=' + enc(kw) + '&t=' + enc('搜索：' + kw);
}

function joinArts(arr, key, sep) {
  var out = [];
  if (arr && arr.length) {
    for (var i = 0; i < arr.length; i++) {
      var o = arr[i];
      var n = o ? String(o[key || 'name'] || '').trim() : '';
      if (n) out.push(n);
    }
  }
  return out.join(sep || ', ');
}

/* ============================ 换源播放链：探活 / Referer ============================ */

/** 按直链域名给出探活/播放 headers（对齐 jar AudioLinkResolver.refererOf） */
function refererOf(url) {
  var s = String(url || '');
  var h = {};
  if (s.indexOf('douyin') >= 0 || s.indexOf('douyinvod') >= 0 || s.indexOf('luna.douyin') >= 0) {
    h['User-Agent'] = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1';
    h['Referer'] = 'https://www.douyin.com/';
  } else if (s.indexOf('kuwo.cn') >= 0) {
    h['User-Agent'] = UA_OKHTTP;
    h['Referer'] = 'https://www.kuwo.cn/';
  } else if (s.indexOf('163.com') >= 0 || s.indexOf('126.net') >= 0) {
    h['Referer'] = 'https://music.163.com/';
  } else if (s.indexOf('migu.cn') >= 0 || s.indexOf('cmcc') >= 0) {
    h['Referer'] = 'https://music.migu.cn/';
  } else if (s.indexOf('qq.com') >= 0 || s.indexOf('qcloud') >= 0) {
    h['Referer'] = 'https://y.qq.com/';
  }
  return h;
}

function probeAlive(url) {
  try {
    var code = statusX.call(this, url, refererOf(url));
    return aliveStatus(code);
  } catch (e) { return false; }
}

/** 依次探活，返回 {url, headers} 或 null */
function firstAliveX(urls) {
  for (var i = 0; i < urls.length; i++) {
    var u = urls[i];
    if (!u) continue;
    if (probeAlive.call(this, u)) return { url: u, headers: refererOf(u) };
  }
  return null;
}

/* ============================ 匹配评分（对齐 jar Match） ============================ */

function matchClean(s) {
  var t = String(s === null || s === undefined ? '' : s);
  t = t.replace(/[（(【\[].*?[）)】\]]/g, ' ');
  t = t.replace(/cover.*$/i, ' ');
  return t.trim();
}

function matchFirstArtist(s) {
  if (!s) return '';
  var parts = String(s).split(/[/、&,，]/);
  return parts.length ? String(parts[0]).trim() : '';
}

function matchNorm(s) {
  return matchClean(s).toLowerCase().replace(/[\s·・\-_,.，。'"!！?？&/\\]/g, '');
}

function matchSim(a, b) {
  a = String(a || ''); b = String(b || '');
  if (a === b) return 1;
  if (a.indexOf(b) >= 0 || b.indexOf(a) >= 0) return 0.75;
  var la = a.length, lb = b.length;
  if (!la && !lb) return 0;
  var prev = [], cur = [];
  for (var j = 0; j <= lb; j++) prev[j] = j;
  for (var i2 = 1; i2 <= la; i2++) {
    cur = [i2];
    for (var j2 = 1; j2 <= lb; j2++) {
      var cost = a.charAt(i2 - 1) === b.charAt(j2 - 1) ? 0 : 1;
      cur[j2] = Math.min(prev[j2] + 1, cur[j2 - 1] + 1, prev[j2 - 1] + cost);
    }
    prev = cur;
  }
  var maxLen = Math.max(la, lb);
  return maxLen ? 1 - prev[lb] / maxLen : 0;
}

var MATCH_HARD = [
  ['cover', '翻唱|翻自|cover\\s?by|covered\\s?by|\\bcover\\s?ver'],
  ['banzou', '伴奏版?|伴奏|off\\s?vocal|karaoke|消音版?'],
  ['instrumental', '纯音乐|纯音版?|instrumental|\\binst\\b|bgm|无人声'],
  ['piano', '钢琴版?|钢琴曲|钢琴独奏|\\bpiano\\b'],
  ['live', 'live版?|演唱会版?|现场版?|concert版?'],
  ['dj', 'dj版?|remix版?|混音版?|电音版?'],
];
var MATCH_SOFT = [
  ['remaster', 'remastered?版?|重制版?'],
  ['single', 'single\\s?version|单曲版'],
  ['acoustic', '不插电|\\bacoustic\\b|unplugged'],
];

function tagHit(lower, name, pattern) {
  try { if (new RegExp(pattern, 'i').test(lower)) return true; } catch (e) { /* 忽略正则错误 */ }
  return lower.indexOf(name) >= 0;
}

/** 返回 {ok, score}（对齐 jar Match.score） */
function matchScore(query, artist, candSong, candArtist, dur, candDur) {
  var q = matchNorm(query), a = matchFirstArtist(artist);
  var cs = matchNorm(candSong), ca = matchFirstArtist(candArtist);
  if (!q || !cs) return { ok: false, score: 0 };
  var s = matchSim(q, cs) * 0.6 + (a ? matchSim(a, ca) : 0.5) * 0.4;
  if (dur > 0 && candDur > 0) {
    var dd = Math.abs(dur - candDur);
    if (dd <= 3) s += 0.3;
    else if (dd <= 5) s += 0.2;
    else if (dd <= 10) s += 0.15;
    else if (dd <= 25) s += 0.05;
    else if (dd > 45) s -= 0.3;
  }
  var tl = String(candSong || '').toLowerCase();
  var ql = String(query || '').toLowerCase();
  for (var i = 0; i < MATCH_HARD.length; i++) {
    var name = MATCH_HARD[i][0], pat = MATCH_HARD[i][1];
    var candHit = tagHit(tl, name, pat);
    var queryHit = tagHit(ql, name, pat);
    if (candHit && !queryHit) {
      if (name === 'cover' || name === 'banzou' || name === 'instrumental' || name === 'piano') {
        return { ok: false, score: s };
      }
      s -= 0.35;
    }
  }
  for (var k = 0; k < MATCH_SOFT.length; k++) {
    if (tagHit(tl, MATCH_SOFT[k][0], MATCH_SOFT[k][1]) && !tagHit(ql, MATCH_SOFT[k][0], MATCH_SOFT[k][1])) s -= 0.1;
  }
  return { ok: s >= 0.8, score: s };
}

/** 按评分排序命中（对齐 jar pickOrdered）：返回打分通过且按得分降序的 hits */
function pickOrdered(hits, query, artist, dur) {
  var scored = [];
  for (var i = 0; i < hits.length; i++) {
    var h = hits[i];
    var r = matchScore(query, artist, h.song, h.artist, dur, h.duration);
    if (r.ok) scored.push({ score: r.score, idx: i, hit: h });
  }
  scored.sort(function (x, y) { return y.score - x.score || x.idx - y.idx; });
  var out = [];
  for (var j = 0; j < scored.length; j++) out.push(scored[j].hit);
  return out;
}

/* ============================ 酷我兜底（对齐 jar KuwoFallback） ============================ */

var KW_FB_UA = UA_OKHTTP;
var KW_FB_CHANNELS = ['https://nmobi.kuwo.cn/mobi.s', 'https://mobi.kuwo.cn/mobi.s'];
var KW_FB_SOURCES = ['kwplayerhd_ar_4.3.0.8_tianbao_T1A_qirui.apk', 'kwplayer_ar_8.5.5.0_apk_keluze.apk'];

function kwFbSearch(q) {
  var hits = [];
  try {
    var url = 'https://search.kuwo.cn/r.s?client=kt&all=' + enc(q) +
      '&pn=0&rn=10&uid=794762570&ver=kwplayer_ar_9.2.2.1&vipver=1&show_copyright_off=1&newver=1&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1&issubtitle=1';
    var body = httpX.call(this, url, { 'User-Agent': KW_FB_UA });
    if (!body) return hits;
    var j = parseLoose(body);
    var arr = j && j.abslist ? j.abslist : null;
    if (!arr) return hits;
    for (var i = 0; i < arr.length; i++) {
      var o = arr[i];
      if (!o) continue;
      var rid = String(o.MUSICRID || '').replace(/MUSIC_/g, '').trim();
      var song = String(o.SONGNAME || '').trim();
      var artist = String(o.ARTIST || '').trim();
      var duration = parseInt(String(o.DURATION || '0'), 10) || 0;
      if (!rid || !song) continue;
      hits.push({ rid: rid, song: song, artist: artist, duration: duration });
    }
  } catch (e) { /* 返回空 */ }
  return hits;
}

function toHttps(u) {
  var s = String(u || '').trim();
  if (s.indexOf('http://') === 0) return 'https://' + s.substring(7);
  return s;
}

function kwFbResolveRid(rid) {
  var quals = ['320kmp3', '128kmp3'];
  var best = '', bestBr = -1;
  for (var qi = 0; qi < quals.length; qi++) {
    for (var ci = 0; ci < KW_FB_CHANNELS.length; ci++) {
      for (var si = 0; si < KW_FB_SOURCES.length; si++) {
        var url = KW_FB_CHANNELS[ci] + '?f=web&user=0&source=' + KW_FB_SOURCES[si] +
          '&type=convert_url_with_sign&rid=' + enc(rid) + '&br=' + quals[qi];
        var body = '';
        try { body = httpX.call(this, url, { 'User-Agent': KW_FB_UA }); } catch (e) { body = ''; }
        if (!body) continue;
        var j = parseLoose(body);
        var d = j && j.data ? j.data : null;
        if (!d) continue;
        var u = String(d.url || '').trim();
        if (!u) continue;
        var br = parseInt(String(d.bitrate), 10);
        if (isNaN(br) || br < 0) br = quals[qi] === '320kmp3' ? 320 : 128;
        var dur = parseInt(String(d.duration), 10);
        if (!isNaN(dur) && dur > 0 && dur <= 45) continue;
        if (br >= 0 && br < 32) continue;
        if (br > bestBr) { best = toHttps(u); bestBr = br; }
        if (bestBr >= 128) return best;
      }
    }
  }
  return bestBr >= 32 ? best : '';
}

/** 酷我兜底解析：搜索 → 评分排序 → 逐个换链接 */
function kwFbResolve(title, artist, dur) {
  var t = String(title || '').trim();
  if (!t) return '';
  var q = matchClean(t);
  var fa = matchFirstArtist(artist);
  var kw = fa ? q + ' ' + fa : q;
  var hits = kwFbSearch.call(this, kw);
  if (!hits.length && fa) hits = kwFbSearch.call(this, q);
  if (!hits.length) return '';
  var ordered = pickOrdered(hits, t, artist, dur);
  for (var i = 0; i < ordered.length; i++) {
    var u = kwFbResolveRid.call(this, ordered[i].rid);
    if (u) return u;
  }
  return '';
}

/* ============================ 网易云兜底（NetEaseFallback 的 JS 替代实现） ============================ */

function neFbSearch(q) {
  var hits = [];
  try {
    var body = neteaseHttp.call(this, SITE + '/api/search/get/web?s=' + enc(q) + '&type=1&limit=10', SITE + '/');
    if (!body) return hits;
    var j = JSON.parse(body);
    var songs = j && j.result && j.result.songs ? j.result.songs : null;
    if (!songs) return hits;
    for (var i = 0; i < songs.length; i++) {
      var sg = songs[i];
      if (!sg || !sg.id || !sg.name) continue;
      var arts = [];
      if (sg.artists) { for (var a = 0; a < sg.artists.length; a++) { if (sg.artists[a] && sg.artists[a].name) arts.push(String(sg.artists[a].name)); } }
      hits.push({
        id: String(sg.id),
        song: String(sg.name),
        artist: arts.join('/'),
        duration: Math.round((sg.duration || 0) / 1000),
      });
    }
  } catch (e) { /* 返回空 */ }
  return hits;
}

function neFbPickUrl(id) {
  var meting = METING + '?server=netease&type=url&id=' + id;
  var outer = SITE + '/song/media/outer/url?id=' + id + '.mp3';
  try {
    if (aliveStatus(statusX.call(this, meting, { headers: { 'User-Agent': UA } }))) return meting;
  } catch (e) { /* 探活失败试外链 */ }
  try {
    if (aliveStatus(statusX.call(this, outer, { headers: { 'User-Agent': UA } }))) return outer;
  } catch (e2) { /* 放弃该候选 */ }
  return '';
}

/** 网易云兜底解析：明文搜索 + 评分排序 + meting/外链探活（对齐 jar NetEaseFallback.resolve 语义） */
function neFbResolve(title, artist, dur) {
  var t = String(title || '').trim();
  if (!t) return '';
  var q = matchClean(t);
  var fa = matchFirstArtist(artist);
  var kw = fa ? q + ' ' + fa : q;
  var hits = neFbSearch.call(this, kw);
  if (!hits.length && fa) hits = neFbSearch.call(this, q);
  if (!hits.length) return '';
  var ordered = pickOrdered(hits, t, artist, dur);
  for (var i = 0; i < ordered.length; i++) {
    var u = neFbPickUrl.call(this, ordered[i].id);
    if (u) return u;
  }
  return '';
}

/* ============================ 通用歌词 / 封面（对齐 jar LrcResolver / CoverResolver） ============================ */

function kuwoLrcById(id) {
  if (!id) return '';
  // v0.2.1：m.kuwo.cn 歌词接口间歇性返回空（https/http 均有抖动），双通道 × 2 轮重试
  var urls = ['https://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=' + enc(id), 'http://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=' + enc(id)];
  for (var attempt = 0; attempt < 2; attempt++) {
    for (var ui = 0; ui < urls.length; ui++) {
      try {
        var body = httpX.call(this, urls[ui], { 'User-Agent': UA_OKHTTP });
        if (!body) continue;
        var j = JSON.parse(body);
        // songinfoandlrc 全部字段嵌套在 data 节点下（{"data":{"lrclist":[…]}}），顶层直取恒为空
        var d = j && j.data ? j.data : j;
        var arr = d && d.lrclist ? d.lrclist : null;
        if (!arr || !arr.length) continue;
        var lines = [];
        for (var i = 0; i < arr.length; i++) {
          var o = arr[i];
          if (!o) continue;
          var t = parseFloat(String(o.time || '0'));
          var txt = String(o.lineLyric || '');
          if (isNaN(t)) continue;
          var m = Math.floor(t / 60), s = Math.floor(t % 60), cs = Math.round((t - Math.floor(t)) * 100);
          function p2(v) { return (v < 10 ? '0' : '') + v; }
          lines.push('[' + p2(m) + ':' + p2(s) + '.' + p2(cs > 99 ? 99 : cs) + ']' + txt);
        }
        if (lines.length) return lines.join('\n');
      } catch (e) { /* 下一个通道 */ }
    }
    if (attempt === 0 && this && this.host) this.host.sleep(800);
  }
  return '';
}

function kuwoSearchRid(kw) {
  var r = kuwoSearchRidImg.call(this, kw);
  return r.rid;
}

/** v0.2.6：酷我搜索同时取回第一条结果的封面（hts_IMG 为相对路径，
 *  拼上 img4.kuwo.cn/star/albumcover/ 前缀即完整 URL，实测 200 可用）。
 *  搜索接口稳定不限频——封面反查限频接口失败时用它兜底，省一次二次请求。 */
function kuwoSearchRidImg(kw) {
  var out = { rid: '', img: '' };
  try {
    var url = 'https://search.kuwo.cn/r.s?client=kt&all=' + enc(kw) +
      '&pn=0&rn=5&uid=794762570&ver=kwplayer_ar_9.2.2.1&vipver=1&show_copyright_off=1&newver=1&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1&issubtitle=1';
    var body = httpX.call(this, url, { 'User-Agent': UA_OKHTTP });
    if (!body) return out;
    var j = parseLoose(body);
    var arr = j && j.abslist ? j.abslist : null;
    if (arr && arr.length && arr[0]) {
      var rid = String(arr[0].MUSICRID || '').replace(/MUSIC_/g, '').trim();
      var m = /\d+/.exec(rid);
      if (m) out.rid = m[0];
      var img = String(arr[0].hts_IMG || arr[0].hts_img || '').trim();
      if (img && /^https?:\/\//.test(img)) {
        out.img = img;
      } else if (img) {
        out.img = 'http://img4.kuwo.cn/star/albumcover/' + img.replace(/^\/+/, '');
      }
    }
  } catch (e) { /* 忽略 */ }
  return out;
}

function neteaseLrcBySearch(kw) {
  var id = neteaseSearchFirstId.call(this, kw);
  if (!id) { this.host.sleep(1200); id = neteaseSearchFirstId.call(this, kw); }
  if (!id) return '';
  var lrc = neteaseLrcById.call(this, id);
  if (!hasLrcText(lrc)) { this.host.sleep(1200); lrc = neteaseLrcById.call(this, id); }
  return lrc;
}

/** 通用歌词：scheme 直取 → 酷我搜索（非网易源优先，轻量不限频）→ 网易搜索 → 酷我 id → 网易(title)；返回 SRT */
function genericLrc(episodeUrl) {
  var v = parseV2(episodeUrl);
  var lrc = '';
  if ((v.scheme === 'kuwo' || v.scheme === 'mg') && v.id) {
    lrc = kuwoLrcById.call(this, v.id);
  } else if (v.scheme === 'netease' && v.id) {
    lrc = neteaseLrcById.call(this, v.id);
  }
  if (!hasLrcText(lrc) && v.title && v.scheme !== 'netease') {
    // v0.2.1：酷我链优先——r.s + songinfoandlrc 轻量稳定；网易搜索在连播突发时易限频(405)
    var kw1 = v.title + (v.artist ? ' ' + v.artist : '');
    var rid = kuwoSearchRid.call(this, kw1);
    if (rid) lrc = kuwoLrcById.call(this, rid);
  }
  if (!hasLrcText(lrc) && v.title) {
    var kw = v.title + (v.artist ? ' ' + v.artist : '');
    lrc = neteaseLrcBySearch.call(this, kw);
  }
  if (!hasLrcText(lrc) && v.title) {
    // v0.2.1：仅按歌名再搜一次酷我（长歌手串/多歌手拼接时 t+a 搜不准）
    var rid2 = kuwoSearchRid.call(this, v.title);
    if (rid2) lrc = kuwoLrcById.call(this, rid2);
  }
  if (!hasLrcText(lrc) && v.title && /^\d+$/.test(String(v.id || ''))) {
    lrc = kuwoLrcById.call(this, v.id);
  }
  if (!hasLrcText(lrc) && v.title) {
    lrc = neteaseLrcBySearch.call(this, v.title);
  }
  if (!hasLrcText(lrc)) return '';
  return lrcToSrt(lrc);
}

function neteaseCoverById(id) {
  try {
    var body = neteaseHttp.call(this, SITE + '/api/song/detail?ids=[' + id + ']', SITE + '/');
    if (body) {
      var j = JSON.parse(body);
      var songs = j && j.songs ? j.songs : null;
      if (songs && songs.length && songs[0] && songs[0].album && songs[0].album.picUrl) return String(songs[0].album.picUrl);
    }
  } catch (e) { /* 忽略 */ }
  return '';
}

function neteaseCoverBySearch(kw) {
  try {
    var body = neteaseHttp.call(this, SITE + '/api/search/get/web?s=' + enc(kw) + '&type=1&offset=0&limit=1', SITE + '/');
    if (body) {
      var j = JSON.parse(body);
      var songs = j && j.result && j.result.songs ? j.result.songs : null;
      if (songs && songs.length && songs[0]) {
        var al = songs[0].album || null;
        if (al && al.picUrl) return String(al.picUrl);
      }
    }
  } catch (e) { /* 忽略 */ }
  return '';
}

function kuwoCoverById(id) {
  // v0.2.6：songinfoandlrc 接口有限频风控（同一 id 间歇返回 status 301「音乐查询失败」），
  // 失败重试 2 次（间隔 600ms），对齐歌词函数 kuwoLrcById 的做法。
  // v0.2.7：响应里有**多个 pic 字段**——前两个是相关推荐歌单的封面（userpl2015 用户歌单图床），
  // 只有 data.songinfo.pic（albumcover 路径）才是本歌专辑封面；旧 looseField 全文正则取第一个
  // → 拿到别人歌单的图，造成「歌曲和封面对不上」。改为 JSON.parse 精确取 songinfo.pic，
  // 解析失败再退正则但只认 albumcover 路径。
  for (var attempt = 0; attempt < 3; attempt++) {
    var pic = '';
    try {
      var body = httpX.call(this, 'https://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=' + enc(id), { 'User-Agent': UA_OKHTTP });
      if (body) {
        try {
          var j = JSON.parse(body);
          var si = j && j.data && j.data.songinfo ? j.data.songinfo : null;
          if (si) pic = String(si.pic || '').trim();
        } catch (e1) { /* JSON 不完整，退回正则 */ }
        if (!pic || !/^https?:\/\//.test(pic)) {
          var m = /"(?:pic|songPicRadio)"\s*:\s*"(https?:[^"]*albumcover[^"]*)"/.exec(String(body));
          if (m) pic = m[1];
        }
        if (pic && /^https?:\/\//.test(pic)) return pic;
      }
    } catch (e) { /* 忽略 */ }
    if (attempt < 2 && this && this.host) this.host.sleep(600);
  }
  return '';
}

function miguCoverById(id) {
  try {
    var body = httpX.call(this, 'https://music.migu.cn/v3/api/music/audioPlayer/song?songId=' + enc(id), { 'User-Agent': UA });
    if (!body) return '';
    var pic = looseField(body, 'pic');
    if (!pic) pic = looseField(body, 'img');
    if (pic && /^https?:\/\//.test(pic)) return pic;
  } catch (e) { /* 忽略 */ }
  return '';
}

/** 通用封面：c= 参数 → scheme 直取 → 网易搜索 → 酷我搜索/直取 */
/** 酷狗按 hash 反查封面（v0.2.4）：getSongInfo 返回 imgurl——榜单/歌单剧集链接
 *  理论上都带 c=，但「最近播放」的旧章节缓存可能没带；无 c= 时按 hash 补一档 */
function kgCoverById(hash) {
  try {
    var body = httpX.call(this, 'https://m.kugou.com/app/i/getSongInfo?cmd=playInfo&hash=' + enc(hash), { 'User-Agent': KG_UA_M });
    if (!body) return '';
    var j = JSON.parse(body);
    var img = String((j && (j.imgurl || j.imgUrl)) || '');
    return /^https?:\/\//.test(img) ? img : '';
  } catch (e) { return ''; }
}

function genericCover(episodeUrl) {
  var v = parseV2(episodeUrl);
  if (v.cover && /^https?:\/\//.test(v.cover)) return v.cover;
  var pic = '';
  if (v.id) {
    if (v.scheme === 'netease') pic = neteaseCoverById.call(this, v.id);
    else if (v.scheme === 'kuwo') pic = kuwoCoverById.call(this, v.id);
    else if (v.scheme === 'mg') pic = miguCoverById.call(this, v.id);
    else if (v.scheme === 'kg') pic = kgCoverById.call(this, v.id);
  }
  if (!pic && v.title) {
    var kw = v.title + (v.artist ? ' ' + v.artist : '');
    pic = neteaseCoverBySearch.call(this, kw);
  }
  if (!pic && v.title) {
    // v0.2.6：酷我搜索一次同时拿 rid+封面（搜索接口稳定，hts_IMG 现成可用）；
    // 搜索结果没带图才落到 songinfoandlrc（有限频，内部已带重试）
    var kw2 = v.title + (v.artist ? ' ' + v.artist : '');
    var sr = kuwoSearchRidImg.call(this, kw2);
    if (sr.img) pic = sr.img;
    if (!pic && sr.rid) pic = kuwoCoverById.call(this, sr.rid);
  }
  if (!pic && v.id && v.scheme !== 'netease' && v.scheme !== 'kuwo' && v.scheme !== 'mg') {
    pic = neteaseCoverById.call(this, v.id);
  }
  return pic;
}

/** 搜索聚合详情通用骨架：抓多页歌曲，去重生成连播合集 */
function aggregateDetail(self, kw, maxPages, fetchPage, introTail, sourceName) {
  var episodes = [];
  var seen = {};
  var shellCover = '';
  for (var page = 1; page <= maxPages; page++) {
    var books = fetchPage.call(self, kw, page);
    var before = episodes.length;
    for (var i = 0; i < books.length; i++) {
      var b = books[i];
      var url = b.bookUrl;
      if (!url || seen[url]) continue;
      seen[url] = true;
      // v0.2.3：收集第一首歌的封面作合集书封面——歌没有封面时播放页回落用它
      if (!shellCover && b.coverUrl) shellCover = b.coverUrl;
      episodes.push({ title: joinTitle(b.title, b.author), url: url });
    }
    if (episodes.length === before) break;
  }
  if (episodes.length === 0) {
    episodes.push({ title: '搜索加载失败，请返回后重试', url: '' });
  }
  return {
    episodes: episodes,
    intro: '【' + (kw ? '搜索：' + kw : '搜索结果') + '】\n共 ' + episodes.length + ' 首，结果合集连播（自动顺播下一首）。\n\n来源：' + sourceName + introTail,
    artist: '', author: '', coverUrl: shellCover, title: kw ? '搜索：' + kw : sourceName, status: '',
  };
}

/** 榜单聚合详情通用骨架（对齐 jar rankBookDetail 连播合集） */
function aggregateRankDetail(self, fetchPage, title, introTail, sourceName, coverUrl) {
  var episodes = [];
  var seen = {};
  for (var page = 1; page <= 20; page++) {
    var books = fetchPage.call(self, page);
    var before = episodes.length;
    for (var i = 0; i < books.length; i++) {
      var b = books[i];
      var url = b.bookUrl;
      if (!url || seen[url]) continue;
      seen[url] = true;
      episodes.push({ title: joinTitle(b.title, b.author), url: url });
    }
    if (episodes.length === before) break;
  }
  if (episodes.length === 0) {
    episodes.push({ title: '加载失败，请返回后重试', url: '' });
  }
  return {
    episodes: episodes,
    intro: '【' + (title || '榜单') + '·连播】\n共 ' + episodes.length + ' 首。\n\n来源：' + sourceName + introTail,
    artist: '', author: '', coverUrl: coverUrl || '', title: title || sourceName, status: '',
  };
}

/* ============================ 酷狗音乐 ============================ */

var KG_GATEWAY = 'https://gateway.kugou.com/v3/album_audio/audio';
var KG_GATEWAY_KEY = 'OIlwieks28dk2k092lksi2UIkp';
var KG_GATEWAY_UA = 'Android712-AndroidPhone-11451-376-0-FeeCacheUpdate-wifi';
var KG_UA_M = 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Mobile Safari/537.36';
var KG_RANKS = [
  ['8888', 'TOP500'], ['6666', '飙升榜'], ['74534', '新歌榜'], ['31308', '内地榜'],
  ['31313', '香港地区榜'], ['54848', '台湾地区榜'], ['31310', '欧美榜'], ['31311', '韩国榜'],
  ['31312', '日本榜'], ['33165', '粤语金曲榜'], ['44412', '说唱先锋榜'], ['59895', 'R&B榜'],
  ['59896', '摇滚榜'], ['33160', '电音榜'], ['51341', '民谣榜'], ['59900', '纯音乐榜'],
  ['85897', '国潮音乐榜'], ['80025', '国乐榜'], ['82831', '网络热歌榜'], ['52144', '短视频热歌榜'],
  ['24971', 'DJ热歌榜'], ['49225', '80后热歌榜'], ['49223', '90后热歌榜'], ['51340', '伤感榜'],
  ['85432', '百万收藏榜'],
];

function kgCover(s) {
  var t = String(s || '').trim();
  if (!t) return '';
  t = t.replace('{size}', '400');
  if (t.indexOf('http://') === 0) return 'https://' + t.substring(7);
  return t;
}

function kgSearchSongsOnce(kw, page) {
  var books = [];
  try {
    var url = 'https://songsearch.kugou.com/song_search_v2?keyword=' + enc(kw) +
      '&page=' + Math.max(page, 1) + '&pagesize=30&userid=0&clientver=&platform=WebFilter&filter=2&iscorrection=1&privilege_filter=0&area_code=1&language=&version=1000';
    var body = httpX.call(this, url, { 'User-Agent': KG_UA_M });
    if (!body) return books;
    var j = JSON.parse(body);
    var lists = j && j.data && j.data.lists ? j.data.lists : null;
    if (!lists) return books;
    for (var i = 0; i < lists.length; i++) {
      var o = lists[i];
      if (!o) continue;
      var name = stripEm(o.SongName || o.FileName || '').trim();
      var artist = stripEm(o.SingerName || '').trim();
      var album = stripEm(o.AlbumName || '').trim();
      var hash = String(o.FileHash || '').trim();
      var d = parseInt(String(o.Duration || '0'), 10) || 0;
      var pic = kgCover(o.Image || '');
      if (!name || !hash) continue;
      books.push(mkBook2(pic, songUrl2('kg', enc(hash), name, artist, album, d, pic), name, artist));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function kgSearchSongs(kw, page) {
  var books = kgSearchSongsOnce.call(this, kw, page);
  if (!books.length) { this.host.sleep(900); books = kgSearchSongsOnce.call(this, kw, page); }
  return books;
}

function kgRankList(rankid, page) {
  var books = [];
  try {
    var url = 'https://m.kugou.com/rank/info/?rankid=' + enc(rankid) + '&page=' + page + '&json=true';
    var body = httpX.call(this, url, { 'User-Agent': KG_UA_M });
    if (!body) return books;
    var j = JSON.parse(body);
    var list = j && j.songs && j.songs.list ? j.songs.list : null;
    if (!list) return books;
    for (var i = 0; i < list.length; i++) {
      var o = list[i];
      if (!o) continue;
      var name = String(o.songname || '').trim();
      var artist = '';
      if (o.authors && o.authors.length && o.authors[0]) artist = String(o.authors[0].author_name || '').trim();
      var filename = String(o.filename || '').trim();
      if (!name && filename) {
        var p = filename.lastIndexOf(' - ');
        if (p > 0) {
          if (!artist) artist = filename.substring(p + 3).trim();
          name = filename.substring(0, p).trim();
        } else name = filename;
      }
      var hash = String(o.hash || '').trim();
      var d = parseInt(String(o.duration || '0'), 10) || 0;
      var pic = kgCover(o.album_sizable_cover || '');
      if (!name || !hash) continue;
      books.push(mkBook2(pic, songUrl2('kg', enc(hash), name, artist, null, d, pic), name, artist));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function kgPlistIndex(page) {
  var books = [];
  try {
    var url = 'https://m.kugou.com/plist/index?json=true&page=' + page + '&pagesize=30';
    var body = httpX.call(this, url, { 'User-Agent': KG_UA_M });
    if (!body) return books;
    var j = JSON.parse(body);
    var info = j && j.plist && j.plist.list && j.plist.list.info ? j.plist.list.info : null;
    if (!info) return books;
    for (var i = 0; i < info.length; i++) {
      var o = info[i];
      if (!o) continue;
      var sid = String(o.specialid || '0');
      var name = String(o.specialname || '').trim();
      var pic = kgCover(o.imgurl || '');
      var intro = String(o.intro || '').trim();
      if (intro.length > 300) intro = intro.substring(0, 300) + '…';
      var count = parseInt(String(o.songcount || '0'), 10) || 0;
      var play = parseInt(String(o.playcount || '0'), 10) || 0;
      if (sid === '0' || !name) continue;
      var u = 'kg://plist/' + enc(sid) + '?t=' + enc(name) + '&c=' + enc(pic) + '&i=' + enc(intro) + '&n=' + count;
      var status = count > 0 ? count + ' 首' : '歌单';
      if (play > 0) status = '';
      books.push(mkBook2(pic, u, name, status, ''));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

/** 酷狗网关批量取歌（对齐 jar fillSongs：100 个 hash 一批 POST） */
function kgFillSongs(hashes) {
  var books = [];
  try {
    var data = [];
    for (var i = 0; i < hashes.length; i++) data.push({ hash: hashes[i] });
    var payload = {
      area_code: '1', show_privilege: 1, show_album_info: 1, is_publish: '',
      appid: 1005, clientver: 11451, mid: '1', dfid: '-',
      clienttime: Date.now(),
      key: KG_GATEWAY_KEY,
      fields: 'album_info,author_name,audio_info,ori_audio_name,base,songname,classification',
      data: data,
    };
    if (typeof payload.clienttime === 'number') payload.clienttime = Math.floor(payload.clienttime);
    var body = postJsonX.call(this, KG_GATEWAY, JSON.stringify(payload), {
      'User-Agent': KG_GATEWAY_UA,
      'KG-THash': '13a3164', 'KG-RC': '1', 'KG-Fake': '0', 'KG-RF': '00869891',
      'x-router': 'kmr.service.kugou.com',
    });
    if (!body) return books;
    var j = JSON.parse(body);
    var arr = j && j.data ? j.data : null;
    if (!arr) return books;
    for (var k = 0; k < arr.length; k++) {
      var sub = arr[k];
      if (!sub || !sub.length) continue;
      var o = sub[0];
      if (!o) continue;
      var name = String(o.ori_audio_name || o.songname || '').trim();
      var artist = String(o.author_name || '').trim();
      var ai = o.audio_info || {};
      var hash = String(ai.hash || (hashes[Math.min(k, hashes.length - 1)] || '')).trim();
      var dms = parseInt(String(ai.timelength || '0'), 10) || 0;
      var alb = o.album_info || {};
      var pic = kgCover(alb.sizable_cover || alb.imgurl || alb.cover || '');
      if (!name || !hash) continue;
      books.push(mkBook2(pic, songUrl2('kg', enc(hash), name, artist, null, dms, pic), name, artist));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function kgSheetHashes(id) {
  var out = [];
  var seen = {};
  var urls = ['https://www2.kugou.kugou.com/yueku/v9/special/single/' + enc(id) + '-5-9999.html'];
  try {
    urls.push('http://' + urls[0].substring(urls[0].indexOf('://') + 3));
  } catch (e) { /* 忽略 */ }
  for (var u = 0; u < urls.length; u++) {
    var body = '';
    try { body = httpX.call(this, urls[u], { 'User-Agent': KG_UA_M }); } catch (e2) { body = ''; }
    if (!body) continue;
    var re = /"hash":"([0-9A-Fa-f]{32})"/g;
    var m;
    while ((m = re.exec(body)) !== null) {
      if (!seen[m[1]]) { seen[m[1]] = true; out.push(m[1]); }
    }
    if (out.length) break;
  }
  return out;
}

/** 榜单封面（并发）：rank/info 页 info.imgurl */
function kgRankCovers(ids) {
  var covers = [];
  var urls = [];
  for (var i = 0; i < ids.length; i++) {
    urls.push('https://m.kugou.com/rank/info/?rankid=' + enc(ids[i]) + '&page=1&json=true');
  }
  var bodies = [];
  try { bodies = this.host.getStrings(urls, { headers: { 'User-Agent': KG_UA_M } }, 6) || []; } catch (e) { bodies = []; }
  for (var k = 0; k < ids.length; k++) {
    var pic = '';
    var body = bodies[k] || '';
    if (body) {
      var f = looseField(body, 'imgurl') || looseField(body, 'img_cover');
      pic = kgCover(f);
    }
    covers.push(pic);
  }
  return covers;
}

registerSource({
  id: 'zip_kugou',
  name: '酷狗音乐',
  url: 'https://www.kugou.com',
  description: '酷狗音乐（ZIP 脚本版）：搜索/榜单/歌单广场，播放走酷我/网易云换源链，歌词封面解析。',
  group: '音乐类',
  searchable: true,
  discoverable: true,
  multipleEpisodePages: false,
  enabledByDefault: true,
  search: function (keywords, page) {
    var kw = String(keywords === null || keywords === undefined ? '' : keywords).trim();
    if (!kw) return { books: [], totalPage: 1 };
    var books = [{ coverUrl: '', bookUrl: searchbookUrl('kg', kw), title: '搜索：' + kw, author: '', artist: '', intro: '', status: '' }];
    try { books = books.concat(kgSearchSongs.call(this, kw, 1)); } catch (e) { /* 保留卡片 */ }
    return { books: books, totalPage: 1 };
  },
  bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
    var s = String(bookUrl || '');
    var shell = { episodes: [], intro: '', artist: '', author: '', coverUrl: '', title: '', status: '' };
    if (!loadEpisodes) return shell;
    var v = parseV2(s);
    var self = this;
    if (v.kind === 'searchbook') {
      return aggregateDetail(self, v.kw, 20, kgSearchSongs, '。［v15 · 2026-11］', '酷狗音乐');
    }
    if (v.kind === 'song') {
      return {
        episodes: [{ title: joinTitle(v.title || '播放', v.artist), url: s }],
        intro: '酷狗音乐歌曲', artist: '', author: '', coverUrl: v.cover || '', title: '酷狗音乐', status: '',
      };
    }
    if (v.kind === 'rankbook') {
      var fetchRank = function (page) { return kgRankList.call(self, v.id, page); };
      return aggregateRankDetail(self, fetchRank, v.title || '酷狗榜单', '。［v15 · 2026-11］', '酷狗音乐', v.cover || '');
    }
    if (v.kind === 'plist') {
      var episodes = [];
      try {
        var hashes = kgSheetHashes.call(self, v.id);
        for (var i = 0; i < hashes.length; i += 100) {
          var batch = hashes.slice(i, Math.min(i + 100, hashes.length));
          var books = kgFillSongs.call(self, batch);
          for (var k = 0; k < books.length; k++) {
            episodes.push({ title: joinTitle(books[k].title, books[k].author), url: books[k].bookUrl });
          }
        }
      } catch (e) { /* 空列表 */ }
      if (!episodes.length) episodes.push({ title: '加载失败，请返回后重试', url: '' });
      return {
        episodes: episodes,
        intro: '【' + (v.title || '酷狗歌单') + '】\n共 ' + episodes.length + ' 首，整单连播。\n\n' + (v.kw || '') + '\n\n来源：酷狗音乐。［v2 · 2026-11］',
        artist: '', author: '', coverUrl: v.cover || '', title: v.title || '酷狗歌单', status: '',
      };
    }
    return shell;
  },
  categoryMenus: function () {
    var ranks = [{ title: '排行榜', url: 'kg://ranks/all?v=16' }];
    for (var i = 0; i < KG_RANKS.length; i++) {
      ranks.push({ title: KG_RANKS[i][1], url: 'kg://ranklist/' + KG_RANKS[i][0] + '?t=' + enc(KG_RANKS[i][1]) + '&p=1' });
    }
    return [
      { title: '排行榜', tabs: ranks },
      { title: '歌单', tabs: [{ title: '歌单广场', url: 'kg://plist?p=1' }] },
    ];
  },
  categoryPage: function (url) {
    var s = String(url || '');
    var page = 1;
    var hash = s.indexOf('#');
    if (hash >= 0) { var n = parseInt(s.substring(hash + 1), 10); if (!isNaN(n) && n > 0) page = n; s = s.substring(0, hash); }
    var v = parseV2(s);
    var books = [], nextUrl = '';
    try {
      if (v.kind === 'ranks') {
        var ids = [], titles = [];
        for (var i = 0; i < KG_RANKS.length; i++) { ids.push(KG_RANKS[i][0]); titles.push(KG_RANKS[i][1]); }
        var covers = kgRankCovers.call(this, ids);
        for (var k = 0; k < ids.length; k++) {
          books.push({ coverUrl: covers[k] || '', bookUrl: 'kg://rankbook/' + enc(ids[k]) + '?t=' + enc(titles[k]) + '&c=' + enc(covers[k] || ''), title: titles[k], author: '', artist: '', intro: '', status: '' });
        }
      } else if (v.kind === 'ranklist' || v.kind === 'rank') {
        var rankid = v.id;
        books = kgRankList.call(this, rankid, v.p || page);
        var total = books.length >= 30 ? (v.p || page) + 1 : (v.p || page);
        if ((v.p || page) < total && books.length >= 30) nextUrl = 'kg://rank/' + enc(rankid) + '?p=' + ((v.p || page) + 1);
      } else if (v.kind === 'plist' && !v.id) {
        books = kgPlistIndex.call(this, v.p || page);
        if (books.length >= 30) nextUrl = 'kg://plist?p=' + ((v.p || page) + 1);
      }
    } catch (e) { /* 返回空 */ }
    return { books: books, currentPage: v.p || page, totalPage: nextUrl ? (v.p || page) + 1 : (v.p || page), nextUrl: nextUrl };
  },
  audio: function (episodeUrl) {
    var v = parseV2(episodeUrl);
    var dur = v.d > 0 ? (v.d > 1000 ? Math.floor(v.d / 1000) : v.d) : 0;
    var ku = '', ne = '';
    try { ku = kwFbResolve.call(this, v.title, v.artist, dur); } catch (e) { ku = ''; }
    // v0.2.1：网易换源惰性化——酷我探活成功就不再请求网易（降低连播突发限频压力）
    var hit = firstAliveX.call(this, [ku]);
    if (!hit) {
      try { ne = neFbResolve.call(this, v.title, v.artist, dur); } catch (e2) { ne = ''; }
      hit = firstAliveX.call(this, [ne]);
    }
    if (hit) return hit;
    return { url: ku || ne || '' };
  },
  lrc: function (episodeUrl) { return genericLrc.call(this, episodeUrl); },
  cover: function (episodeUrl) { return genericCover.call(this, episodeUrl); },
});

/* ============================ 酷我音乐 ============================ */

var KW_RANKS = [
  ['16', '热歌榜'], ['17', '新歌榜'], ['93', '飙升榜'], ['284', '热评榜'],
  ['26', '经典怀旧榜'], ['64', '影视金曲榜'], ['182', '粤语榜'], ['22', '欧美榜'],
  ['183', '日语榜'], ['184', '韩语榜'], ['278', '古风榜'], ['242', '电音榜'],
  ['329', '说唱榜'], ['187', '流行趋势榜'], ['328', '车载歌曲榜'], ['297', '跑步健身榜'],
  ['255', 'KTV点唱榜'], ['158', '短视频热歌榜'], ['145', '会员畅听榜'],
];

/** 酷我封面路径规范化（对齐 jar KuwoMusic.coverOf） */
function kwCoverNorm(u) {
  var t = String(u || '').trim();
  if (!t) return '';
  if (t.indexOf('//') === 0) t = 'https:' + t;
  if (t.indexOf('http://') === 0 || t.indexOf('https://') === 0) {
    var i = t.indexOf('//') + 2;
    var slash = t.indexOf('/', i);
    t = slash > 0 ? t.substring(slash) : '';
  }
  while (t.charAt(0) === '/') t = t.substring(1);
  if (t.indexOf('star/') === 0) t = t.substring(5);
  var m = /^(\d{2,4})\/(.*)$/.exec(t);
  if (m) t = m[2];
  if (!t) return '';
  if (t.indexOf('albumcover/') === 0) return 'https://img1.kuwo.cn/star/' + t;
  if (t.indexOf('pic_music/') === 0) return 'https://img1.kuwo.cn/' + t;
  return 'https://img1.kuwo.cn/star/albumcover/300/' + t;
}

function kwPicUrl(u) {
  var t = String(u || '').trim();
  if (!t) return '';
  if (t.indexOf('//') === 0) t = 'https:' + t;
  if (t.indexOf('http://') === 0) t = 'https://' + t.substring(7);
  return t.replace('_150.jpg', '_500.jpg');
}

function kwSearchSongsOnce(kw, page) {
  var books = [];
  try {
    var p = Math.max(page, 1) - 1;
    var url = 'https://search.kuwo.cn/r.s?client=kt&all=' + enc(kw) +
      '&pn=' + p + '&rn=20&uid=0&ver=kwplayer_ar_9.2.2.1&vipver=1&show_copyright_off=1&newver=1&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&verinfo=1&mobi=1';
    var body = httpX.call(this, url, { 'User-Agent': UA_OKHTTP });
    if (!body) return books;
    var j = parseLoose(body);
    var arr = j && j.abslist ? j.abslist : null;
    if (!arr) return books;
    for (var i = 0; i < arr.length; i++) {
      var o = arr[i];
      if (!o) continue;
      var id = String(o.DC_TARGETID || '').trim();
      if (!id) id = String(o.MUSICRID || '').replace(/MUSIC_/g, '').trim();
      var name = String(o.SONGNAME || o.NAME || '').trim();
      var artist = String(o.ARTIST || '').trim();
      var pic = kwCoverNorm(String(o.web_albumpic_short || o.web_albumpic || ''));
      if (!id || !name) continue;
      books.push(mkBook2(pic, songUrl2('kuwo', enc(id), name, artist, null, 0, pic), name, artist));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function kwSearchSongs(kw, page) {
  var books = kwSearchSongsOnce.call(this, kw, page);
  if (!books.length) { this.host.sleep(900); books = kwSearchSongsOnce.call(this, kw, page); }
  return books;
}

/** 榜单歌曲（对齐 jar bangList）。v0.2.8：kbangserver musiclist 不带封面，
 *  批量搜索（host.getStrings 并发 6，搜索接口稳定不限频）补齐每首歌的专辑封面——
 *  卡片 coverUrl 与虚拟链接 c= 参数双写（播放/封面直用，无需再反查） */
/** v0.2.9：酷我搜索批量取封面。兼容字段：hts_IMG / hts_img / web_albumpic_short / pic；
 *  全部落空时打诊断日志（响应长度+开头片段），用于定位 App 网络环境下的实际响应。 */
function kwBatchSearchCovers(pairs) {
  var urls = [];
  for (var i = 0; i < pairs.length; i++) {
    urls.push('https://search.kuwo.cn/r.s?client=kt&all=' + enc((pairs[i][0] || '') + ' ' + (pairs[i][1] || '')) +
      '&pn=0&rn=1&uid=794762570&ver=kwplayer_ar_9.2.2.1&vipver=1&show_copyright_off=1&newver=1&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1&issubtitle=1');
  }
  var bodies = [];
  try { bodies = this.host.getStrings(urls, { headers: { 'User-Agent': UA_OKHTTP } }, 6) || []; } catch (e) { bodies = []; }
  var out = [];
  for (var k = 0; k < pairs.length; k++) {
    var img = '';
    try {
      var b = bodies[k] || '';
      if (b) {
        var j = parseLoose(b);
        var o = j && j.abslist && j.abslist[0] ? j.abslist[0] : null;
        if (o) {
          img = String(o.hts_IMG || o.hts_img || o.web_albumpic_short || o.pic || '').trim();
          // web_albumpic_short 可能是完整 URL（img4.../albumcover/...），也可能是相对路径
        } else {
          var m = /"hts_IMG"\s*:\s*"([^"]+)"/.exec(b);
          if (m) img = m[1];
        }
      }
    } catch (e2) { img = ''; }
    if (img && /^https?:\/\//.test(img)) {
      // 完整 URL：统一转 https 且不带尺寸后缀的 albumcover 路径也直接可用
      img = img.replace(/^http:\/\//, 'https://');
    } else if (img) {
      img = 'http://img4.kuwo.cn/star/albumcover/' + img.replace(/^\/+/, '');
    }
    out.push(/^https?:\/\//.test(img) ? img : '');
  }
  try {
    if (this.host && this.host.log) {
      var b0 = String(bodies[0] || '');
      this.host.log('[zip_kuwo] 封面搜索诊断: 响应数=' + bodies.length +
        ' 首条长度=' + b0.length + ' 首条开头=' + b0.substring(0, 150).replace(/\s+/g, ' '));
    }
  } catch (e3) { /* 忽略 */ }
  return out;
}

function kwBangList(bangid, page) {
  var books = [];
  try {
    var url = 'https://kbangserver.kuwo.cn/ksong.s?from=pc&fmt=json&pn=' + (page - 1) +
      '&rn=30&type=bang&data=content&id=' + enc(bangid) + '&show_copyright_off=0&pcmp4=1&isbang=1';
    var body = httpX.call(this, url, { 'User-Agent': UA_OKHTTP });
    if (!body) return books;
    var j = JSON.parse(body);
    var list = j && j.musiclist ? j.musiclist : null;
    if (!list) return books;
    for (var i = 0; i < list.length; i++) {
      var o = list[i];
      if (!o) continue;
      var id = String(o.id || '').trim();
      var name = String(o.name || '').trim();
      var artist = String(o.artist || '').trim();
      if (!id || !name) continue;
      books.push(mkBook2('', songUrl2('kuwo', enc(id), name, artist, null, 0, ''), name, artist));
    }
    // v0.2.8：批量搜索补封面（卡片显示 + c= 参数随链接走，播放封面零反查）
    if (books.length && this && this.host && this.host.getStrings) {
      var pairs = [];
      for (var b = 0; b < books.length; b++) pairs.push([books[b].title, books[b].author]);
      var covers = kwBatchSearchCovers.call(this, pairs);
      var filled = 0;
      for (var k = 0; k < books.length; k++) {
        var img = covers[k] || '';
        if (!img) continue;
        filled++;
        books[k].coverUrl = img;
        books[k].bookUrl += '&c=' + enc(img);
      }
      try { if (this.host && this.host.log) this.host.log('[zip_kuwo] 榜单「' + (bangid || '') + '」第' + page + '页封面补齐 ' + filled + '/' + books.length); } catch (e3) { /* 忽略 */ }
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

/** 歌单广场（对齐 jar playlistList） */
function kwPlaylistList(order, page) {
  var books = [];
  try {
    var url = 'https://wapi.kuwo.cn/api/pc/classify/playlist/getRcmPlayList?pn=' + page + '&rn=20&order=' + order;
    var body = httpX.call(this, url, { 'User-Agent': UA_PC_106, 'Referer': 'https://www.kuwo.cn/' });
    if (!body) return books;
    var j = JSON.parse(body);
    var arr = j && j.data && j.data.data ? j.data.data : null;
    if (!arr) return books;
    for (var i = 0; i < arr.length; i++) {
      var o = arr[i];
      if (!o) continue;
      var id = String(o.id || '').trim();
      var name = String(o.name || '').trim();
      var uname = String(o.uname || '').trim();
      var pic = kwPicUrl(String(o.img || ''));
      if (!id || !name) continue;
      books.push(mkBook2(pic, 'kuwo://playlist/' + enc(id) + '?t=' + enc(name) + '&a=' + enc(uname) + '&c=' + enc(pic), name, uname, ''));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

/** 歌单详情单页（对齐 jar fetchPlaylist） */
function kwFetchPlaylist(pid, page) {
  try {
    var url = 'https://nplserver.kuwo.cn/pl.svc?op=getlistinfo&pid=' + enc(pid) +
      '&pn=' + page + '&rn=100&encode=utf8&keyset=pl2012&identity=kuwo&pcmp4=1&vipver=MUSIC_9.1.0.0_W1&newver=1';
    var body = httpX.call(this, url, { 'User-Agent': UA_PC_106 });
    if (!body) return null;
    return JSON.parse(body);
  } catch (e) { return null; }
}

/** 榜单封面（并发）：kbangserver 顶层字段。v0.2.7：实测顶层 pic 是 BangPic/ 空尾路径（403 无效图），
 *  v9_pic2 才是榜单第一首歌的专辑封面（img4 albumcover，可用）——优先 v9_pic2，回退 pic */
function kwRankCovers(ids) {
  var urls = [];
  for (var i = 0; i < ids.length; i++) {
    urls.push('https://kbangserver.kuwo.cn/ksong.s?from=pc&fmt=json&pn=0&rn=1&type=bang&data=content&id=' + enc(ids[i]) + '&show_copyright_off=0&pcmp4=1&isbang=1');
  }
  var bodies = [];
  try { bodies = this.host.getStrings(urls, { headers: { 'User-Agent': UA_OKHTTP } }, 6) || []; } catch (e) { bodies = []; }
  var out = [];
  for (var k = 0; k < ids.length; k++) {
    var pic = '';
    try {
      var body = bodies[k] || '';
      if (body) {
        var j = JSON.parse(body);
        pic = String(j.v9_pic2 || '').trim();
        if (!/^https?:\/\//.test(pic)) pic = String(j.pic || '').trim();
      }
    } catch (e2) { pic = ''; }
    out.push(/^https?:\/\//.test(pic) ? pic : '');
  }
  return out;
}

/** 酷我直链（对齐 jar KuwoMusic.play：QUALITY × CHANNELS tryChannel） */
function kwPlaySong(id) {
  var channels = [
    ['https://mobi.kuwo.cn/mobi.s', 'kwplayer_ar_8.5.5.0_apk_keluze.apk'],
    ['https://nmobi.kuwo.cn/mobi.s', 'kwplayercar_ar_6.1.0.0_B_jiakong_vh.apk'],
    ['https://mobi.kuwo.cn/mobi.s', 'kwplayercar_ar_6.1.0.0_B_jiakong_vh.apk'],
  ];
  var quals = [['320kmp3', 'mp3'], ['128kmp3', 'mp3']];
  var best = '', bestBr = -1;
  for (var qi = 0; qi < quals.length; qi++) {
    for (var ci = 0; ci < channels.length; ci++) {
      var url = channels[ci][0] + '?user=0&source=' + channels[ci][1] +
        '&type=convert_url_with_sign&br=' + quals[qi][0] + '&format=' + quals[qi][1] +
        '&sig=0&rid=' + enc(id) + '&network=WIFI&f=web';
      var body = '';
      try { body = httpX.call(this, url, { 'User-Agent': UA_OKHTTP }); } catch (e) { body = ''; }
      if (!body) continue;
      var j = parseLoose(body);
      var d = j && j.data ? j.data : null;
      if (!d) continue;
      var u = String(d.url || '').trim();
      if (!u || u.indexOf('http') !== 0) continue;
      var br = parseInt(String(d.bitrate), 10);
      if (isNaN(br) || br <= 0) br = quals[qi][0] === '320kmp3' ? 320 : 128;
      if (u.indexOf('http://') === 0) u = 'https://' + u.substring(7);
      if (br > bestBr) { best = u; bestBr = br; }
      if (bestBr >= 128) return best;
    }
  }
  return bestBr >= 24 ? best : '';
}

registerSource({
  id: 'zip_kuwo',
  name: '酷我音乐',
  url: 'https://www.kuwo.cn',
  description: '酷我音乐（ZIP 脚本版）：搜索/榜单/歌单广场，移动端 320K 直链，失败自动降码率或换源。',
  group: '音乐类',
  searchable: true,
  discoverable: true,
  multipleEpisodePages: false,
  enabledByDefault: true,
  search: function (keywords, page) {
    var kw = String(keywords === null || keywords === undefined ? '' : keywords).trim();
    if (!kw) return { books: [], totalPage: 1 };
    var books = [{ coverUrl: '', bookUrl: searchbookUrl('kuwo', kw), title: '搜索：' + kw, author: '', artist: '', intro: '', status: '' }];
    try { books = books.concat(kwSearchSongs.call(this, kw, 1)); } catch (e) { /* 保留卡片 */ }
    return { books: books, totalPage: 1 };
  },
  bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
    var s = String(bookUrl || '');
    var shell = { episodes: [], intro: '', artist: '', author: '', coverUrl: '', title: '', status: '' };
    if (!loadEpisodes) return shell;
    var v = parseV2(s);
    var self = this;
    if (v.kind === 'searchbook') {
      return aggregateDetail(self, v.kw, 20, kwSearchSongs, '。［v15 · 2026-11］', '酷我音乐');
    }
    if (v.kind === 'song') {
      return {
        episodes: [{ title: joinTitle(v.title || '播放', v.artist), url: s }],
        intro: '酷我音乐歌曲', artist: '', author: '', coverUrl: v.cover || '', title: '酷我音乐', status: '',
      };
    }
    if (v.kind === 'rankbook') {
      var fetchBang = function (page) { return kwBangList.call(self, v.id, page); };
      return aggregateRankDetail(self, fetchBang, v.title || '酷我榜单', '。［v15 · 2026-11］', '酷我音乐', v.cover || '');
    }
    if (v.kind === 'playlist') {
      var episodes = [];
      var cover = v.cover || '';
      try {
        for (var i = 0; i < 5; i++) {
          var j = kwFetchPlaylist.call(self, v.id, i);
          if (!j) break;
          var list = j.musiclist;
          if (!list || !list.length) break;
          for (var k = 0; k < list.length; k++) {
            var o = list[k];
            if (!o) continue;
            var id = String(o.id || '').trim();
            var name = String(o.name || '').trim();
            var artist = String(o.artist || '').trim();
            if (!id || !name) continue;
            var pic = kwCoverNorm(String(o.albumpic || o.musicPic || ''));
            if (!cover && pic) cover = pic;
            episodes.push({ title: joinTitle(name, artist), url: songUrl2('kuwo', enc(id), name, artist, null, 0, pic) });
          }
        }
      } catch (e) { /* 空列表 */ }
      if (!episodes.length) episodes.push({ title: '加载失败，请返回后重试', url: '' });
      return {
        episodes: episodes,
        intro: '【' + (v.title || '酷我歌单') + '】\n共 ' + episodes.length + ' 首，整单连播。\n\n' + (v.artist || '') + '\n\n来源：酷我音乐。［v2 · 2026-11］',
        artist: '', author: '', coverUrl: cover, title: v.title || '酷我歌单', status: '',
      };
    }
    return shell;
  },
  categoryMenus: function () {
    var ranks = [{ title: '排行榜', url: 'kuwo://ranks/all?v=16' }];
    for (var i = 0; i < KW_RANKS.length; i++) {
      ranks.push({ title: KW_RANKS[i][1], url: 'kuwo://ranklist/' + KW_RANKS[i][0] + '?t=' + enc(KW_RANKS[i][1]) + '&p=1' });
    }
    return [
      { title: '排行榜', tabs: ranks },
      { title: '歌单', tabs: [{ title: '最热歌单', url: 'kuwo://plist/hot' }, { title: '最新歌单', url: 'kuwo://plist/new' }] },
    ];
  },
  categoryPage: function (url) {
    var s = String(url || '');
    var page = 1;
    var hash = s.indexOf('#');
    if (hash >= 0) { var n = parseInt(s.substring(hash + 1), 10); if (!isNaN(n) && n > 0) page = n; s = s.substring(0, hash); }
    var v = parseV2(s);
    var books = [], nextUrl = '';
    try {
      if (v.kind === 'ranks') {
        var ids = [], titles = [];
        for (var i = 0; i < KW_RANKS.length; i++) { ids.push(KW_RANKS[i][0]); titles.push(KW_RANKS[i][1]); }
        var covers = kwRankCovers.call(this, ids);
        for (var k = 0; k < ids.length; k++) {
          books.push({ coverUrl: covers[k] || '', bookUrl: 'kuwo://rankbook/' + enc(ids[k]) + '?t=' + enc(titles[k]) + '&c=' + enc(covers[k] || ''), title: titles[k], author: '', artist: '', intro: '', status: '' });
        }
      } else if (v.kind === 'ranklist' || v.kind === 'bang') {
        books = kwBangList.call(this, v.id, v.p || page);
        if (books.length >= 30) nextUrl = 'kuwo://bang/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      } else if (v.kind === 'plist') {
        var order = v.id || 'hot';
        if (order !== 'hot' && order !== 'new') order = 'hot';
        books = kwPlaylistList.call(this, order, v.p || page);
        if (books.length >= 20) nextUrl = 'kuwo://plist/' + order + '?p=' + ((v.p || page) + 1);
      }
    } catch (e) { /* 返回空 */ }
    return { books: books, currentPage: v.p || page, totalPage: nextUrl ? (v.p || page) + 1 : (v.p || page), nextUrl: nextUrl };
  },
  audio: function (episodeUrl) {
    var v = parseV2(episodeUrl);
    var direct = '';
    if (v.id) { try { direct = kwPlaySong.call(this, v.id); } catch (e) { direct = ''; } }
    var ku = '', ne = '';
    try { ku = kwFbResolve.call(this, v.title, v.artist, 0); } catch (e2) { ku = ''; }
    // v0.2.1：网易换源惰性化——本源直链/酷我探活成功就不再请求网易
    var hit = firstAliveX.call(this, [direct, ku]);
    if (!hit) {
      try { ne = neFbResolve.call(this, v.title, v.artist, 0); } catch (e3) { ne = ''; }
      hit = firstAliveX.call(this, [ne]);
    }
    if (hit) return hit;
    return { url: direct || ku || ne || '' };
  },
  lrc: function (episodeUrl) { return genericLrc.call(this, episodeUrl); },
  cover: function (episodeUrl) { return genericCover.call(this, episodeUrl); },
});

/* ============================ 咪咕音乐 ============================ */

var MG_SEARCH_URL = 'https://jadeite.migu.cn/music_search/v3/search/searchAll';
var MG_DEVICE_ID = '963B7AA0D21511ED807EE5846EC87D20';
var MG_SALT1 = '6cdc72a439cef99a3418d2a78aa28c73';
var MG_SALT2 = 'yyapp2d16148780a1dcc7408e06336b98cfd50';
var MG_IMG_PREFIX = 'https://d.musicapp.migu.cn';
var MG_RANKS = [
  ['27553319', '新歌榜'], ['27186466', '热歌榜'], ['27553408', '原创榜'], ['75959118', '风向榜'],
  ['76557036', '彩铃榜'], ['76557745', '会员榜'], ['23189800', '港台榜'], ['23189399', '内地榜'],
  ['19190036', '欧美榜'], ['83176390', '国风榜'],
];
var MG_TAGS = [
  ['网络热歌', '1001076096'], ['流行', '1000001672'], ['经典老歌', '1000001635'], ['官方', '1003449976'],
  ['国风', '1000001675'], ['民谣', '1000001775'], ['KTV金曲', '1000001827'], ['欧美', '1000001777'],
  ['儿歌', '1000001780'], ['伤感', '1000001795'], ['电影', '1001076080'], ['怀旧', '1000001696'],
  ['翻唱', '1000001831'], ['轻音乐', '1000001807'],
];

function miguSign(text, ts) {
  return this.host.md5(text + MG_SALT1 + MG_SALT2 + MG_DEVICE_ID + ts);
}

function miguSongItem(o) {
  if (!o) return null;
  var id = String(o.contentId || '').trim();
  var name = String(firstNE(o.name, o.songName) || '').trim();
  if (!id || !name) return null;
  var artist = joinArts(o.singerList, 'name', ', ');
  var album = String(o.album || '').trim();
  var pic = String(o.img3 || o.img2 || o.img1 || '').trim();
  if (pic && pic.indexOf('http') !== 0) pic = MG_IMG_PREFIX + pic;
  var d = parseInt(String(o.duration || '0'), 10) || 0;
  return mkBook2(pic, songUrl2('mg', enc(id), name, artist, album, d, pic), name, artist);
}

function miguSearchSongsOnce(kw, page) {
  var books = [];
  try {
    var ts = String(Date.now());
    var sw = encodeURIComponent('{"song":1,"album":0,"singer":0,"tagSong":1,"mvSong":0,"bestShow":1,"songlist":0,"lyricSong":0}');
    var url = MG_SEARCH_URL + '?isCorrect=0&isCopyright=1&searchSwitch=' + sw +
      '&pageSize=30&text=' + enc(kw) + '&pageNo=' + Math.max(page, 1) + '&sort=0&sid=USS';
    var sign = miguSign.call(this, kw, ts);
    var body = httpX.call(this, url, {
      'User-Agent': UA_ANDROID_MG,
      'Accept': 'application/json, text/plain, */*',
      'uiVersion': 'A_music_3.6.1',
      'deviceId': MG_DEVICE_ID,
      'timestamp': ts,
      'sign': sign,
      'channel': '0146921',
    });
    if (!body) { this.host.sleep(1200); body = httpX.call(this, url, { 'User-Agent': UA_ANDROID_MG, 'Accept': 'application/json, text/plain, */*', 'uiVersion': 'A_music_3.6.1', 'deviceId': MG_DEVICE_ID, 'timestamp': String(Date.now()), 'sign': miguSign.call(this, kw, String(Date.now())), 'channel': '0146921' }); }
    if (!body) return books;
    var j = JSON.parse(body);
    var srd = j && j.songResultData ? j.songResultData : null;
    var rows = srd && srd.resultList ? srd.resultList : null;
    if (!rows) return books;
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      if (!row) continue;
      for (var k = 0; k < row.length; k++) {
        var b = miguSongItem(row[k]);
        if (b) books.push(b);
      }
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function miguSearchSongs(kw, page) {
  var books = miguSearchSongsOnce.call(this, kw, page);
  if (!books.length) { this.host.sleep(1200); books = miguSearchSongsOnce.call(this, kw, page); }
  return books;
}

/** 咪咕榜单歌曲（对齐 jar rankItem：resType==2） */
function miguTopList(rankId, page) {
  var books = [];
  try {
    var url = 'https://app.c.nf.migu.cn/bmw/rank/rank-info/v1.0?pageNo=' + page + '&rankId=' + enc(rankId) + '&pageSize=30';
    var body = '';
    try { body = httpX.call(this, url, { 'User-Agent': UA_ANDROID_MG, 'Accept': 'application/json, text/plain, */*', 'Referer': 'https://app.c.nf.migu.cn/', 'channel': '0146921' }); } catch (e) { body = ''; }
    if (!body) { this.host.sleep(1200); body = httpX.call(this, url, { 'User-Agent': UA_ANDROID_MG, 'Accept': 'application/json, text/plain, */*', 'Referer': 'https://app.c.nf.migu.cn/', 'channel': '0146921' }); }
    if (!body) return books;
    var j = JSON.parse(body);
    var contents = j && j.data && j.data.contents ? j.data.contents : null;
    if (!contents) return books;
    for (var i = 0; i < contents.length; i++) {
      var o = contents[i];
      if (!o || String(o.resType || '') !== '2') continue;
      var id = String(o.resId || '').trim();
      var name = String(o.txt || '').trim();
      if (!id || !name) continue;
      var pic = String(o.img || '').trim();
      var artist = String(o.txt2 || '').trim();
      var album = String(o.txt3 || '').trim();
      books.push(mkBook2(pic, songUrl2('mg', enc(id), name, artist, album, 0, pic), name, artist));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

/** 咪咕标签歌单广场（对齐 jar tagSheets/sheetItem） */
function miguTagSheets(tagId, page) {
  var books = [];
  try {
    var url = 'https://app.c.nf.migu.cn/pc/v1.0/template/musiclistplaza-listbytag/release?pageNumber=' + page + '&templateVersion=2&tagId=' + enc(tagId);
    var body = httpX.call(this, url, { 'User-Agent': UA_IPHONE, 'Accept': 'application/json, text/plain, */*', 'Referer': 'https://m.music.migu.cn/' });
    if (!body) return books;
    var j = JSON.parse(body);
    var items = j && j.data && j.data.contentItemList ? j.data.contentItemList : null;
    if (!items) return books;
    for (var i = 0; i < items.length; i++) {
      var group = items[i];
      var subs = group && group.itemList ? group.itemList : null;
      if (!subs) continue;
      for (var k = 0; k < subs.length; k++) {
        var o = subs[k];
        if (!o) continue;
        var name = String(o.title || '').trim();
        var act = String(o.actionUrl || '').trim();
        var m = /id=([^&]+)/.exec(act);
        var pid = m ? dec(m[1]) : '';
        if (!pid || !name) continue;
        var pic = String(o.imageUrl || '').trim();
        if (pic.indexOf('//') === 0) pic = 'https:' + pic;
        else if (pic && pic.indexOf('http') !== 0) pic = MG_IMG_PREFIX + pic;
        var bar = o.barList;
        var playTxt = (bar && bar.length && bar[0]) ? String(bar[0].title || '').trim() : '';
        var status = playTxt ? playTxt : '咪咕音乐歌单';
        books.push(mkBook2(pic, 'mg://plist/' + enc(pid) + '?t=' + enc(name) + '&c=' + enc(pic) + '&d=' + enc(status), name, status, ''));
      }
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

/** 咪咕播放直链（对齐 jar listenUrl：PQ 音质） */
function miguListenUrl(contentId) {
  try {
    var url = 'https://app.c.nf.migu.cn/MIGUM2.0/v2.0/content/listen-url?netType=01&toneFlag=PQ&resourceType=2&contentId=' + enc(contentId);
    var body = httpX.call(this, url, { 'User-Agent': UA_PC_106, 'Accept': 'application/json, text/plain, */*', 'Channel': '014000D' });
    if (!body) return '';
    var j = JSON.parse(body);
    if (String(j.code || '') !== '000000') return '';
    var u = String(j.data && j.data.url ? j.data.url : '').trim();
    return /^https?:\/\//.test(u) ? u : '';
  } catch (e) { return ''; }
}

/** 榜单封面（并发）：bmw rank-info titlePic */
function miguRankCovers(ids) {
  var urls = [];
  for (var i = 0; i < ids.length; i++) {
    urls.push('https://app.c.nf.migu.cn/bmw/rank/rank-info/v1.0?pageNo=1&rankId=' + enc(ids[i]) + '&pageSize=1');
  }
  var heads = { 'User-Agent': UA_ANDROID_MG, 'Accept': 'application/json, text/plain, */*', 'Referer': 'https://app.c.nf.migu.cn/', 'channel': '0146921' };
  var bodies = [];
  try { bodies = this.host.getStrings(urls, { headers: heads }, 5) || []; } catch (e) { bodies = []; }
  var out = [];
  for (var k = 0; k < ids.length; k++) {
    var pic = '';
    try {
      var body = bodies[k] || '';
      if (body) { var j = JSON.parse(body); pic = String(j.data && j.data.titlePic ? j.data.titlePic : '').trim(); }
    } catch (e2) { pic = ''; }
    out.push(pic);
  }
  return out;
}

registerSource({
  id: 'zip_migu',
  name: '咪咕音乐',
  url: 'https://music.migu.cn',
  description: '咪咕音乐（ZIP 脚本版）：搜索/10 大官方榜单/标签歌单，PQ 音质直链，失败走酷我/网易云换源。',
  group: '音乐类',
  searchable: true,
  discoverable: true,
  multipleEpisodePages: false,
  enabledByDefault: true,
  search: function (keywords, page) {
    var kw = String(keywords === null || keywords === undefined ? '' : keywords).trim();
    if (!kw) return { books: [], totalPage: 1 };
    var books = [{ coverUrl: '', bookUrl: searchbookUrl('mg', kw), title: '搜索：' + kw, author: '', artist: '', intro: '', status: '' }];
    try { books = books.concat(miguSearchSongs.call(this, kw, 1)); } catch (e) { /* 保留卡片 */ }
    return { books: books, totalPage: 1 };
  },
  bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
    var s = String(bookUrl || '');
    var shell = { episodes: [], intro: '', artist: '', author: '', coverUrl: '', title: '', status: '' };
    if (!loadEpisodes) return shell;
    var v = parseV2(s);
    var self = this;
    if (v.kind === 'searchbook') {
      return aggregateDetail(self, v.kw, 10, miguSearchSongs, '。［v15 · 2026-11］', '咪咕音乐');
    }
    if (v.kind === 'song') {
      return {
        episodes: [{ title: joinTitle(v.title || '播放', v.artist), url: s }],
        intro: '咪咕音乐歌曲', artist: '', author: '', coverUrl: v.cover || '', title: '咪咕音乐', status: '',
      };
    }
    if (v.kind === 'rankbook') {
      var fetchTop = function (page) { return miguTopList.call(self, v.id, page); };
      return aggregateRankDetail(self, fetchTop, v.title || '咪咕榜单', '。［v15 · 2026-11］', '咪咕音乐', v.cover || '');
    }
    if (v.kind === 'plist') {
      var episodes = [];
      var cover = v.cover || '';
      try {
        for (var i = 1; i <= 10; i++) {
          var url = 'https://app.c.nf.migu.cn/MIGUM3.0/resource/playlist/song/v2.0?pageNo=' + i + '&pageSize=30&playlistId=' + enc(v.id);
          var body = '';
          try { body = httpX.call(self, url, { 'User-Agent': UA_IPHONE, 'Accept': 'application/json, text/plain, */*', 'Referer': 'https://m.music.migu.cn/' }); } catch (e0) { body = ''; }
          if (!body) { self.host.sleep(1200); body = httpX.call(self, url, { 'User-Agent': UA_IPHONE, 'Accept': 'application/json, text/plain, */*', 'Referer': 'https://m.music.migu.cn/' }); }
          if (!body) break;
          var j = JSON.parse(body);
          var list = j && j.data && j.data.songList ? j.data.songList : null;
          if (!list || !list.length) break;
          for (var k = 0; k < list.length; k++) {
            var b = miguSongItem(list[k]);
            if (!b) continue;
            if (!cover && b.coverUrl) cover = b.coverUrl;
            episodes.push({ title: joinTitle(b.title, b.author), url: b.bookUrl });
          }
          if (list.length < 30) break;
        }
      } catch (e) { /* 空列表 */ }
      if (!episodes.length) episodes.push({ title: '加载失败，请返回后重试', url: '' });
      return {
        episodes: episodes,
        intro: '【咪咕歌单】\n共 ' + episodes.length + ' 首，整单连播。\n\n' + (v.kw || '') + '\n\n来源：咪咕音乐。［v2 · 2026-11］',
        artist: '', author: '', coverUrl: cover, title: v.title || '咪咕歌单', status: '',
      };
    }
    return shell;
  },
  categoryMenus: function () {
    var ranks = [{ title: '排行榜', url: 'mg://ranks/all?v=16' }];
    for (var i = 0; i < MG_RANKS.length; i++) {
      ranks.push({ title: MG_RANKS[i][1], url: 'mg://ranklist/' + MG_RANKS[i][0] + '?t=' + enc(MG_RANKS[i][1]) + '&p=1' });
    }
    var tags = [];
    for (var j = 0; j < MG_TAGS.length; j++) {
      tags.push({ title: MG_TAGS[j][0], url: 'mg://tag/' + MG_TAGS[j][1] + '?p=1' });
    }
    return [
      { title: '排行榜', tabs: ranks },
      { title: '歌单', tabs: tags },
    ];
  },
  categoryPage: function (url) {
    var s = String(url || '');
    var page = 1;
    var hash = s.indexOf('#');
    if (hash >= 0) { var n = parseInt(s.substring(hash + 1), 10); if (!isNaN(n) && n > 0) page = n; s = s.substring(0, hash); }
    var v = parseV2(s);
    var books = [], nextUrl = '';
    try {
      if (v.kind === 'ranks') {
        var ids = [], titles = [];
        for (var i = 0; i < MG_RANKS.length; i++) { ids.push(MG_RANKS[i][0]); titles.push(MG_RANKS[i][1]); }
        var covers = miguRankCovers.call(this, ids);
        for (var k = 0; k < ids.length; k++) {
          books.push({ coverUrl: covers[k] || '', bookUrl: 'mg://rankbook/' + enc(ids[k]) + '?t=' + enc(titles[k]) + '&c=' + enc(covers[k] || ''), title: titles[k], author: '', artist: '', intro: '', status: '' });
        }
      } else if (v.kind === 'ranklist' || v.kind === 'top') {
        books = miguTopList.call(this, v.id, v.p || page);
        if (books.length >= 30) nextUrl = 'mg://top/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      } else if (v.kind === 'tag') {
        books = miguTagSheets.call(this, v.id, v.p || page);
        if (books.length >= 30) nextUrl = 'mg://tag/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      }
    } catch (e) { /* 返回空 */ }
    return { books: books, currentPage: v.p || page, totalPage: nextUrl ? (v.p || page) + 1 : (v.p || page), nextUrl: nextUrl };
  },
  audio: function (episodeUrl) {
    var v = parseV2(episodeUrl);
    var direct = '';
    if (v.id) { try { direct = miguListenUrl.call(this, v.id); } catch (e) { direct = ''; } }
    var dur = v.d > 0 ? v.d : 0;
    var ku = '', ne = '';
    try { ku = kwFbResolve.call(this, v.title, v.artist, dur); } catch (e2) { ku = ''; }
    // v0.2.1：网易换源惰性化——本源直链/酷我探活成功就不再请求网易
    var hit = firstAliveX.call(this, [direct, ku]);
    if (!hit) {
      try { ne = neFbResolve.call(this, v.title, v.artist, dur); } catch (e3) { ne = ''; }
      hit = firstAliveX.call(this, [ne]);
    }
    if (hit) return hit;
    return { url: direct || ku || ne || '' };
  },
  lrc: function (episodeUrl) { return genericLrc.call(this, episodeUrl); },
  cover: function (episodeUrl) { return genericCover.call(this, episodeUrl); },
});

/* ============================ QQ 音乐 ============================ */

var QQ_FCG = 'https://u.y.qq.com/cgi-bin/musicu.fcg';
var QQ_RANKS = [
  ['62', '飙升榜'], ['26', '热歌榜'], ['27', '新歌榜'], ['4', '流行指数榜'],
  ['67', '听歌识曲榜'], ['201', 'MV榜'], ['5', '内地榜'], ['59', '香港地区榜'],
  ['61', '台湾地区榜'], ['3', '欧美榜'], ['16', '韩国榜'], ['17', '日本榜'],
  ['130', '香港TVB劲歌金曲榜'], ['127', '台湾KKBOX榜'], ['58', '说唱榜'], ['57', '电音榜'],
  ['73', '游戏音乐榜'], ['72', '动漫音乐榜'], ['29', '影视金曲榜'], ['64', '综艺新歌榜'],
  ['65', '国风热歌榜'], ['36', 'K歌金曲榜'], ['60', '抖音热歌榜'], ['63', 'DJ舞曲榜'],
  ['28', '网络歌曲榜'], ['108', '美国公告牌榜'], ['129', '韩国Melon榜'], ['107', '英国UK榜'],
  ['105', '日本公信榜'],
];
var QQ_PL_SEARCH = ['华语', '流行', '欧美', '粤语', '日语', '韩语', '说唱', '民谣', '摇滚', '电子', '轻音乐', '怀旧', '治愈', '睡前', '学习'];

function qqFcg(module, method, param) {
  var payload = { req_1: { module: module, method: method, param: param } };
  var body = postJsonX.call(this, QQ_FCG, JSON.stringify(payload), {
    'User-Agent': UA_PC_106,
    'Referer': 'https://y.qq.com/',
    'Accept': 'application/json',
  });
  if (!body) { this.host.sleep(1200); body = postJsonX.call(this, QQ_FCG, JSON.stringify(payload), { 'User-Agent': UA_PC_106, 'Referer': 'https://y.qq.com/', 'Accept': 'application/json' }); }
  return body;
}

function qqSongBook(o) {
  if (!o) return null;
  var mid = String(o.mid || o.songmid || '').trim();
  var name = String(firstNE(o.songname, o.name) || '').trim();
  if (!mid || !name) return null;
  var artist = joinArts(o.singer, 'name', ', ');
  var al = o.album || {};
  var albumMid = String(al.mid || '').trim();
  var albumName = String(al.name || '').trim();
  var d = parseInt(String(o.interval || '0'), 10) || 0;
  var sid = parseInt(String(o.id || '0'), 10) || 0;
  var pic = albumMid ? 'https://y.gtimg.cn/music/photo_new/T002R800x800M000' + albumMid + '.jpg' : '';
  var segs = enc(mid) + '/' + sid + '/' + enc(albumMid);
  return mkBook2(pic, songUrl2('qq', segs, name, artist, albumName, d, pic), name, artist);
}

function qqSearchOnce(kw, page) {
  var books = [];
  try {
    var param = { num_per_page: 20, page_num: Math.max(page, 1), query: kw, search_type: 0 };
    var body = qqFcg.call(this, 'music.search.SearchCgiService', 'DoSearchForQQMusicDesktop', param);
    if (body) {
      var j = JSON.parse(body);
      var list = j && j.req_1 && j.req_1.data && j.req_1.data.body && j.req_1.data.body.song && j.req_1.data.body.song.list ? j.req_1.data.body.song.list : null;
      if (list) {
        for (var i = 0; i < list.length; i++) {
          var b = qqSongBook(list[i]);
          if (b) books.push(b);
        }
        if (books.length) return books;
      }
    }
  } catch (e) { /* 走兜底 */ }
  try {
    var u2 = 'https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w=' + enc(kw) + '&format=json&cr=1&p=' + Math.max(page, 1) + '&n=20&new_json=1';
    var b2 = httpX.call(this, u2, { 'User-Agent': UA_PC_106, 'Referer': 'https://y.qq.com/' });
    if (!b2) return books;
    var j2 = JSON.parse(b2);
    var list2 = j2 && j2.data && j2.data.song && j2.data.song.list ? j2.data.song.list : null;
    if (list2) {
      for (var k = 0; k < list2.length; k++) {
        var b3 = qqSongBook(list2[k]);
        if (b3) books.push(b3);
      }
    }
  } catch (e2) { /* 返回空 */ }
  return books;
}

function qqSearchSongs(kw, page) {
  var books = qqSearchOnce.call(this, kw, page);
  if (!books.length) { this.host.sleep(900); books = qqSearchOnce.call(this, kw, page); }
  if (!books.length) { this.host.sleep(1800); books = qqSearchOnce.call(this, kw, page); }
  if (!books.length) { this.host.sleep(3000); books = qqSearchOnce.call(this, kw, page); }
  return books;
}

function qqTopList(topId, page) {
  var books = [];
  try {
    var param = { topId: parseInt(String(topId), 10) || 26, offset: (Math.max(page, 1) - 1) * 30, num: 30 };
    var body = qqFcg.call(this, 'musicToplist.ToplistInfoServer', 'GetDetail', param);
    if (!body) return books;
    var j = JSON.parse(body);
    var list = j && j.req_1 && j.req_1.data && j.req_1.data.songInfoList ? j.req_1.data.songInfoList : null;
    if (!list) return books;
    for (var i = 0; i < list.length; i++) {
      var b = qqSongBook(list[i]);
      if (b) books.push(b);
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function qqSheetBook(o) {
  if (!o) return null;
  var id = String(firstNE(o.dissid, o.id) || '').trim();
  var name = String(firstNE(o.dissname, o.title) || '').trim();
  if (!id || !name) return null;
  var pic = String(firstNE(o.imgurl, o.artwork) || '').trim();
  if (pic.indexOf('http://') === 0) pic = 'https://' + pic.substring(7);
  pic = pic.replace('/300?', '/600?');
  var intro = String(firstNE(o.introduction, o.description) || '').trim();
  if (intro.length > 300) intro = intro.substring(0, 300) + '…';
  var creator = o.creator ? String(o.creator.name || '').trim() : '';
  return mkBook2(pic, 'qq://plist/' + enc(id) + '?t=' + enc(name) + '&c=' + enc(pic) + '&d=' + enc(intro), name, creator, '');
}

function qqPlCat(catId, page) {
  var books = [];
  try {
    var sin = (Math.max(page, 1) - 1) * 30;
    var url = 'https://c.y.qq.com/splcloud/fcgi-bin/fcg_get_diss_by_tag.fcg?picmid=1&rnd=0.1&g_tk=732860905&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0&categoryId=' + enc(catId) + '&sortId=5&sin=' + sin + '&ein=' + (sin + 29);
    var body = httpX.call(this, url, { 'User-Agent': UA_PC_106, 'Referer': 'https://y.qq.com/' });
    if (!body) return books;
    var j = JSON.parse(body);
    var list = j && j.data && j.data.list ? j.data.list : null;
    if (!list) return books;
    for (var i = 0; i < list.length; i++) {
      var b = qqSheetBook(list[i]);
      if (b) books.push(b);
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function qqPlSearch(kw, page) {
  var books = [];
  try {
    var param = { num_per_page: 20, page_num: Math.max(page, 1), query: kw, search_type: 3 };
    var body = qqFcg.call(this, 'music.search.SearchCgiService', 'DoSearchForQQMusicDesktop', param);
    if (!body) return books;
    var j = JSON.parse(body);
    var list = j && j.req_1 && j.req_1.data && j.req_1.data.body && j.req_1.data.body.songlist && j.req_1.data.body.songlist.list ? j.req_1.data.body.songlist.list : null;
    if (!list) return books;
    for (var i = 0; i < list.length; i++) {
      var b = qqSheetBook(list[i]);
      if (b) books.push(b);
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function qqPlaylistPage(pid, begin) {
  try {
    var url = 'https://c.y.qq.com/v8/fcg-bin/fcg_v8_playlist_cp.fcg?id=' + enc(pid) +
      '&format=json&newsong=1&platform=jqspaframe.json&song_begin=' + begin + '&song_num=300';
    var body = httpX.call(this, url, { 'User-Agent': UA_PC_106, 'Referer': 'https://y.qq.com/' });
    if (!body) return null;
    var j = JSON.parse(body);
    var cd = j && j.data && j.data.cdlist && j.data.cdlist.length ? j.data.cdlist[0] : null;
    return cd;
  } catch (e) { return null; }
}

/** 榜单封面：fcg toplist 头图（29 榜串行 POST，较慢） */
function qqRankCovers(ids) {
  var out = [];
  for (var i = 0; i < ids.length; i++) {
    var pic = '';
    try {
      var param = { topId: parseInt(String(ids[i]), 10) || 26, offset: 0, num: 1 };
      var body = qqFcg.call(this, 'musicToplist.ToplistInfoServer', 'GetDetail', param);
      if (body) {
        var j = JSON.parse(body);
        var d = j && j.req_1 && j.req_1.data ? j.req_1.data : null;
        if (d) pic = String(d.headPicUrl || d.frontPicUrl || d.mbHeadPicUrl || '').trim();
      }
    } catch (e) { pic = ''; }
    out.push(pic);
  }
  return out;
}

registerSource({
  id: 'zip_qq',
  name: 'QQ音乐',
  url: 'https://y.qq.com',
  description: 'QQ音乐（ZIP 脚本版）：搜索/29 大榜单/歌单广场，播放走酷我/网易云换源链，歌词封面解析。',
  group: '音乐类',
  searchable: true,
  discoverable: true,
  multipleEpisodePages: false,
  enabledByDefault: true,
  search: function (keywords, page) {
    var kw = String(keywords === null || keywords === undefined ? '' : keywords).trim();
    if (!kw) return { books: [], totalPage: 1 };
    var books = [{ coverUrl: '', bookUrl: searchbookUrl('qq', kw), title: '搜索：' + kw, author: '', artist: '', intro: '', status: '' }];
    try { books = books.concat(qqSearchSongs.call(this, kw, 1)); } catch (e) { /* 保留卡片 */ }
    return { books: books, totalPage: 1 };
  },
  bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
    var s = String(bookUrl || '');
    var shell = { episodes: [], intro: '', artist: '', author: '', coverUrl: '', title: '', status: '' };
    if (!loadEpisodes) return shell;
    var v = parseV2(s);
    var self = this;
    if (v.kind === 'searchbook') {
      return aggregateDetail(self, v.kw, 25, qqSearchSongs, '。［v15 · 2026-11］', 'QQ音乐');
    }
    if (v.kind === 'song') {
      return {
        episodes: [{ title: joinTitle(v.title || '播放', v.artist), url: s }],
        intro: 'QQ音乐歌曲', artist: '', author: '', coverUrl: v.cover || '', title: 'QQ音乐', status: '',
      };
    }
    if (v.kind === 'rankbook') {
      var fetchTop = function (page) { return qqTopList.call(self, v.id, page); };
      return aggregateRankDetail(self, fetchTop, v.title || 'QQ榜单', '。［v15 · 2026-11］', 'QQ音乐', v.cover || '');
    }
    if (v.kind === 'plist') {
      var episodes = [];
      var cover = v.cover || '';
      try {
        var begin = 0;
        while (begin < 1500) {
          var cd = qqPlaylistPage.call(self, v.id, begin);
          if (!cd) break;
          if (!cover) {
            var logo = String(cd.logo || '').trim();
            if (logo.indexOf('http') === 0) cover = logo.replace('/300?', '/600?');
          }
          var list = cd.songlist;
          if (!list || !list.length) break;
          for (var i = 0; i < list.length; i++) {
            var b = qqSongBook(list[i]);
            if (!b) continue;
            episodes.push({ title: joinTitle(b.title, b.author), url: b.bookUrl });
          }
          if (list.length < 300) break;
          begin += 300;
        }
      } catch (e) { /* 空列表 */ }
      if (!episodes.length) episodes.push({ title: '加载失败，请返回后重试', url: '' });
      return {
        episodes: episodes,
        intro: '【' + (v.title || 'QQ歌单') + '】\n共 ' + episodes.length + ' 首，整单连播。\n\n' + (v.kw || '') + '\n\n来源：QQ音乐。［v2 · 2026-11］',
        artist: '', author: '', coverUrl: cover, title: v.title || 'QQ歌单', status: '',
      };
    }
    return shell;
  },
  categoryMenus: function () {
    var ranks = [{ title: '排行榜', url: 'qq://ranks/all?v=16' }];
    for (var i = 0; i < QQ_RANKS.length; i++) {
      ranks.push({ title: QQ_RANKS[i][1], url: 'qq://ranklist/' + QQ_RANKS[i][0] + '?t=' + enc(QQ_RANKS[i][1]) + '&p=1' });
    }
    var pls = [{ title: '热门歌单', url: 'qq://plcat/10000000?p=1' }];
    for (var j = 0; j < QQ_PL_SEARCH.length; j++) {
      pls.push({ title: QQ_PL_SEARCH[j], url: 'qq://plsearch/' + enc(QQ_PL_SEARCH[j]) + '?p=1' });
    }
    return [
      { title: '排行榜', tabs: ranks },
      { title: '歌单', tabs: pls },
    ];
  },
  categoryPage: function (url) {
    var s = String(url || '');
    var page = 1;
    var hash = s.indexOf('#');
    if (hash >= 0) { var n = parseInt(s.substring(hash + 1), 10); if (!isNaN(n) && n > 0) page = n; s = s.substring(0, hash); }
    var v = parseV2(s);
    var books = [], nextUrl = '';
    try {
      if (v.kind === 'ranks') {
        var ids = [], titles = [];
        for (var i = 0; i < QQ_RANKS.length; i++) { ids.push(QQ_RANKS[i][0]); titles.push(QQ_RANKS[i][1]); }
        var covers = qqRankCovers.call(this, ids);
        for (var k = 0; k < ids.length; k++) {
          books.push({ coverUrl: covers[k] || '', bookUrl: 'qq://rankbook/' + enc(ids[k]) + '?t=' + enc(titles[k]) + '&c=' + enc(covers[k] || ''), title: titles[k], author: '', artist: '', intro: '', status: '' });
        }
      } else if (v.kind === 'ranklist' || v.kind === 'top') {
        books = qqTopList.call(this, v.id, v.p || page);
        if (books.length >= 30) nextUrl = 'qq://top/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      } else if (v.kind === 'plcat') {
        books = qqPlCat.call(this, v.id, v.p || page);
        if (books.length >= 20) nextUrl = 'qq://plcat/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      } else if (v.kind === 'plsearch') {
        books = qqPlSearch.call(this, v.id, v.p || page);
        if (books.length >= 20) nextUrl = 'qq://plsearch/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      }
    } catch (e) { /* 返回空 */ }
    return { books: books, currentPage: v.p || page, totalPage: nextUrl ? (v.p || page) + 1 : (v.p || page), nextUrl: nextUrl };
  },
  audio: function (episodeUrl) {
    var v = parseV2(episodeUrl);
    var dur = v.d > 0 ? (v.d > 1000 ? Math.floor(v.d / 1000) : v.d) : 0;
    var ku = '', ne = '';
    try { ku = kwFbResolve.call(this, v.title, v.artist, dur); } catch (e) { ku = ''; }
    // v0.2.1：网易换源惰性化——酷我探活成功就不再请求网易（降低连播突发限频压力）
    var hit = firstAliveX.call(this, [ku]);
    if (!hit) {
      try { ne = neFbResolve.call(this, v.title, v.artist, dur); } catch (e2) { ne = ''; }
      hit = firstAliveX.call(this, [ne]);
    }
    if (hit) return hit;
    return { url: ku || ne || '' };
  },
  lrc: function (episodeUrl) { return genericLrc.call(this, episodeUrl); },
  cover: function (episodeUrl) { return genericCover.call(this, episodeUrl); },
});

/* ============================ 汽水音乐 ============================ */

var QS_CHART_API = 'https://api5-lq.qishui.com/luna/charts/';
var QS_MIX_API = 'https://api5-lq.qishui.com/luna/discover/mix?charge=0';
var QS_PLAYLIST_API = 'https://api5-lq.qishui.com/luna/playlist/detail?charge=0';
var QS_SEO_API = 'https://beta-luna.douyin.com/luna/h5/seo_track';
var QS_RANKS = [
  ['7036274230471712007', '热歌榜'], ['7060812597884869927', '新歌榜'],
  ['7061475546400005410', '欧美榜'], ['7415959718721494311', '音乐人歌曲榜'],
];
var QS_MIXES = [
  ['每日推荐', '0'], ['流行', '14'], ['摇滚', '15'], ['说唱', '38'], ['电子', '16'],
  ['R&B', '19'], ['国风', '20'], ['民谣', '18'], ['治愈', '69'], ['华语', '8'],
  ['欧美', '9'], ['睡前', '45'], ['学习', '40'],
];

/** 汽水封面：urls[0] + uri + ~noop.image（对齐 jar SodaMusic.cover） */
function qsCover(o) {
  if (!o) return '';
  var uri = String(o.uri || '').trim();
  var urls = o.urls;
  var base = urls && urls.length ? String(urls[0] || '') : '';
  if (!uri || !base) return '';
  if (base.charAt(base.length - 1) !== '/') base += '/';
  return base + uri + '~noop.image';
}

function qsTrackItem(o) {
  if (!o) return null;
  var id = String(o.id || '').trim();
  var name = String(o.name || '').trim();
  if (!id || !name) return null;
  var artist = joinArts(o.artists, 'name', '/');
  var album = '';
  var pic = '';
  var al = o.album;
  if (al) {
    album = String(al.name || '').trim();
    pic = qsCover(al.url_cover);
  }
  if (!pic) pic = qsCover(o.url_cover);
  var d = parseInt(String(o.duration || '0'), 10) || 0;
  // chart 接口时长为微秒，搜索接口为毫秒：超过 1 小时按微秒归一
  if (d > 3600000) d = Math.round(d / 1000);
  return mkBook2(pic, songUrl2('qs', enc(id), name, artist, album, d, pic), name, artist);
}

function qsSearchOnce(kw, page) {
  var books = [];
  try {
    var offset = (Math.max(page, 1) - 1) * 50;
    var url = 'https://api-vehicle.volcengine.com/v2/search/type?keyword=' + enc(kw) +
      '&search_type=music&limit=50&real_offset=' + Math.max(0, offset) + '&search_source=qishui';
    var body = httpX.call(this, url, { 'User-Agent': UA });
    if (!body) return books;
    var j = JSON.parse(body);
    var list = j && j.data && j.data.list ? j.data.list : null;
    if (!list) return books;
    for (var i = 0; i < list.length; i++) {
      var o = list[i];
      if (!o) continue;
      var id = String(o.item_id || '').trim();
      var name = String(o.title || '').trim();
      if (!id || !name) continue;
      var artist = o.author_info ? String(o.author_info.name || '').trim() : '';
      var pic = String(o.cover_url || '').trim();
      var d = (parseInt(String(o.duration || '0'), 10) || 0) * 1000;
      books.push(mkBook2(pic, songUrl2('qs', enc(id), name, artist, '', d, pic), name, artist));
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function qsSearchSongs(kw, page) {
  var books = qsSearchOnce.call(this, kw, page);
  if (!books.length) { this.host.sleep(900); books = qsSearchOnce.call(this, kw, page); }
  return books;
}

function qsChartList(chartId) {
  var books = [];
  try {
    var body = httpX.call(this, QS_CHART_API + enc(chartId) + '?charge=0', { 'User-Agent': UA });
    if (!body) return books;
    var j = JSON.parse(body);
    var ranks = j && j.chart && j.chart.track_ranks ? j.chart.track_ranks : null;
    if (!ranks) return books;
    for (var i = 0; i < ranks.length; i++) {
      var o = ranks[i];
      var b = o ? qsTrackItem(o.track) : null;
      if (b) books.push(b);
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function qsMixList(subId, page) {
  var books = [];
  try {
    var payload = {
      block_type: 'discover_playlist_mix',
      feed_discover_extra: {},
      latest_douyin_liked_playlist_show_ts: 0,
      sub_channel_id: parseInt(String(subId), 10) || 0,
    };
    var body = postJsonX.call(this, QS_MIX_API, JSON.stringify(payload), { 'User-Agent': UA });
    if (!body) return books;
    var j = JSON.parse(body);
    var blocks = j && j.inner_block ? j.inner_block : null;
    if (!blocks) return books;
    for (var i = 0; i < blocks.length; i++) {
      var res = blocks[i] && blocks[i].resources ? blocks[i].resources : null;
      if (!res) continue;
      for (var k = 0; k < res.length; k++) {
        var o = res[k] && res[k].entity && res[k].entity.playlist ? res[k].entity.playlist : null;
        if (!o) continue;
        var pid = String(o.id || '').trim();
        var name = String(o.title || '').trim();
        if (!pid || !name) continue;
        var pic = qsCover(o.url_cover);
        var desc = String(o.desc || '').trim();
        var count = parseInt(String(o.count_tracks || '0'), 10) || 0;
        var status = count > 0 ? count + ' 首' : '歌单';
        books.push(mkBook2(pic, 'qs://playlist/' + enc(pid) + '?t=' + enc(name) + '&c=' + enc(pic) + '&d=' + enc(status), name, status, ''));
      }
    }
  } catch (e) { /* 返回空 */ }
  return books;
}

function qsPlaylistDetail(pid) {
  var tracks = [];
  try {
    var payload = { playlist_id: String(pid) };
    var body = postJsonX.call(this, QS_PLAYLIST_API, JSON.stringify(payload), { 'User-Agent': UA });
    if (!body) return tracks;
    var j = JSON.parse(body);
    var res = j && j.media_resources ? j.media_resources : null;
    if (!res) return tracks;
    for (var i = 0; i < res.length; i++) {
      var o = res[i] && res[i].entity && res[i].entity.track_wrapper && res[i].entity.track_wrapper.track ? res[i].entity.track_wrapper.track : null;
      var t = o ? qsTrackItem(o) : null;
      if (t) tracks.push(t);
    }
  } catch (e) { /* 返回空 */ }
  return tracks;
}

/** 汽水播放直链（对齐 jar seoTrack）：video_model 取最高码率 main_url */
function qsSeoTrack(id) {
  var out = { trackDuration: 0, videoDuration: 0, bestBitrate: -1, bestUrl: '' };
  try {
    var body = httpX.call(this, QS_SEO_API + '?track_id=' + enc(id) + '&device_platform=web', { 'User-Agent': UA });
    if (!body) return out;
    var j = JSON.parse(body);
    var t = j && j.seo_track && j.seo_track.track ? j.seo_track.track : null;
    if (t) out.trackDuration = parseFloat(String(t.duration || '0')) / 1000;
    var player = j && j.track_player ? j.track_player : null;
    if (!player) return out;
    var model = String(player.video_model || '');
    if (!model) return out;
    var m = JSON.parse(model);
    out.videoDuration = parseFloat(String(m.video_duration || '0'));
    var vl = m.video_list;
    if (vl && vl.length) {
      for (var i = 0; i < vl.length; i++) {
        var o = vl[i];
        if (!o) continue;
        var u = String(o.main_url || '').trim();
        if (!u) continue;
        var br = o.video_meta ? (parseInt(String(o.video_meta.bitrate || '0'), 10) || 0) : 0;
        if (br > out.bestBitrate) { out.bestBitrate = br; out.bestUrl = u; }
      }
    }
  } catch (e) { /* 返回空 */ }
  return out;
}

function qsFullPlayable(seo) {
  if (seo.trackDuration > 0) return seo.videoDuration >= 0.85 * seo.trackDuration;
  return seo.videoDuration > 60;
}

function qsResolve(id, title, artist, durMs) {
  try {
    var seo = qsSeoTrack.call(this, id);
    if (seo && seo.bestUrl && qsFullPlayable(seo)) return seo.bestUrl;
  } catch (e) { /* 走换源 */ }
  var dur = durMs > 0 ? Math.floor(durMs / 1000) : 0;
  var ku = '', ne = '';
  try { ku = kwFbResolve.call(this, title, artist, dur); } catch (e2) { ku = ''; }
  // v0.2.1：网易换源惰性化——酷我命中就不再请求网易
  if (ku) return ku;
  try { ne = neFbResolve.call(this, title, artist, dur); } catch (e3) { ne = ''; }
  if (ne) return ne;
  try {
    var seo2 = qsSeoTrack.call(this, id);
    if (seo2 && seo2.bestUrl) return seo2.bestUrl;
  } catch (e4) { /* 全部失败 */ }
  return '';
}

/** 榜单封面（并发）：chart 第一首 track 封面 */
function qsRankCovers(ids) {
  var urls = [];
  for (var i = 0; i < ids.length; i++) {
    urls.push(QS_CHART_API + enc(ids[i]) + '?charge=0');
  }
  var bodies = [];
  try { bodies = this.host.getStrings(urls, { headers: { 'User-Agent': UA } }, 4) || []; } catch (e) { bodies = []; }
  var out = [];
  for (var k = 0; k < ids.length; k++) {
    var pic = '';
    try {
      var body = bodies[k] || '';
      if (body) {
        var j = JSON.parse(body);
        var ranks = j && j.chart && j.chart.track_ranks ? j.chart.track_ranks : null;
        if (ranks && ranks.length && ranks[0] && ranks[0].track) {
          var t = ranks[0].track;
          pic = (t.album && qsCover(t.album.url_cover)) || qsCover(t.url_cover) || '';
        }
      }
    } catch (e2) { pic = ''; }
    out.push(pic);
  }
  return out;
}

registerSource({
  id: 'zip_soda',
  name: '汽水音乐',
  url: 'https://www.qishui.com',
  description: '汽水音乐（ZIP 脚本版）：搜索/榜单/混播歌单，抖音 seo 直链优先，失败走酷我/网易云换源。',
  group: '音乐类',
  searchable: true,
  discoverable: true,
  multipleEpisodePages: false,
  enabledByDefault: true,
  search: function (keywords, page) {
    var kw = String(keywords === null || keywords === undefined ? '' : keywords).trim();
    if (!kw) return { books: [], totalPage: 1 };
    var books = [{ coverUrl: '', bookUrl: searchbookUrl('qs', kw), title: '搜索：' + kw, author: '', artist: '', intro: '', status: '' }];
    try { books = books.concat(qsSearchSongs.call(this, kw, 1)); } catch (e) { /* 保留卡片 */ }
    return { books: books, totalPage: 1 };
  },
  bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
    var s = String(bookUrl || '');
    var shell = { episodes: [], intro: '', artist: '', author: '', coverUrl: '', title: '', status: '' };
    if (!loadEpisodes) return shell;
    var v = parseV2(s);
    var self = this;
    if (v.kind === 'searchbook') {
      return aggregateDetail(self, v.kw, 10, qsSearchSongs, '。［v15 · 2026-11］', '汽水音乐');
    }
    if (v.kind === 'song' || v.kind === 'play') {
      return {
        episodes: [{ title: joinTitle(v.title || '播放', v.artist), url: s }],
        intro: '汽水音乐歌曲', artist: '', author: '', coverUrl: v.cover || '', title: '汽水音乐', status: '',
      };
    }
    if (v.kind === 'rankbook') {
      var fetchChart = function () { return qsChartList.call(self, v.id); };
      return aggregateRankDetail(self, fetchChart, v.title || '汽水榜单', '。［v15 · 2026-11］', '汽水音乐', v.cover || '');
    }
    if (v.kind === 'playlist') {
      var episodes = [];
      try {
        var books = qsPlaylistDetail.call(self, v.id);
        for (var i = 0; i < books.length; i++) {
          episodes.push({ title: joinTitle(books[i].title, books[i].author), url: books[i].bookUrl });
        }
      } catch (e) { /* 空列表 */ }
      if (!episodes.length) episodes.push({ title: '加载失败，请返回后重试', url: '' });
      return {
        episodes: episodes,
        intro: '【' + (v.title || '汽水歌单') + '】\n共 ' + episodes.length + ' 首，整单连播。\n\n' + (v.kw || '') + '\n\n来源：汽水音乐。［v2 · 2026-11］',
        artist: '', author: '', coverUrl: v.cover || '', title: v.title || '汽水歌单', status: '',
      };
    }
    return shell;
  },
  categoryMenus: function () {
    var ranks = [{ title: '排行榜', url: 'qs://ranks/all?v=16' }];
    for (var i = 0; i < QS_RANKS.length; i++) {
      ranks.push({ title: QS_RANKS[i][1], url: 'qs://ranklist/' + QS_RANKS[i][0] + '?t=' + enc(QS_RANKS[i][1]) });
    }
    var mixes = [];
    for (var j = 0; j < QS_MIXES.length; j++) {
      mixes.push({ title: QS_MIXES[j][0], url: 'qs://mix/' + QS_MIXES[j][1] });
    }
    return [
      { title: '排行榜', tabs: ranks },
      { title: '歌单', tabs: mixes },
    ];
  },
  categoryPage: function (url) {
    var s = String(url || '');
    var page = 1;
    var hash = s.indexOf('#');
    if (hash >= 0) { var n = parseInt(s.substring(hash + 1), 10); if (!isNaN(n) && n > 0) page = n; s = s.substring(0, hash); }
    var v = parseV2(s);
    var books = [], nextUrl = '';
    try {
      if (v.kind === 'ranks') {
        var ids = [], titles = [];
        for (var i = 0; i < QS_RANKS.length; i++) { ids.push(QS_RANKS[i][0]); titles.push(QS_RANKS[i][1]); }
        var covers = qsRankCovers.call(this, ids);
        for (var k = 0; k < ids.length; k++) {
          books.push({ coverUrl: covers[k] || '', bookUrl: 'qs://rankbook/' + enc(ids[k]) + '?t=' + enc(titles[k]) + '&c=' + enc(covers[k] || ''), title: titles[k], author: '', artist: '', intro: '', status: '' });
        }
      } else if (v.kind === 'ranklist' || v.kind === 'chart') {
        books = qsChartList.call(this, v.id);
      } else if (v.kind === 'mix') {
        books = qsMixList.call(this, v.id, v.p || page);
        if (books.length > 0 && (v.p || page) < 10) nextUrl = 'qs://mix/' + enc(v.id) + '?p=' + ((v.p || page) + 1);
      }
    } catch (e) { /* 返回空 */ }
    return { books: books, currentPage: v.p || page, totalPage: nextUrl ? (v.p || page) + 1 : (v.p || page), nextUrl: nextUrl };
  },
  audio: function (episodeUrl) {
    var v = parseV2(episodeUrl);
    var direct = '';
    var headers = {};
    if (v.id && !/^https?:\/\//.test(v.id)) {
      try { direct = qsResolve.call(this, v.id, v.title, v.artist, v.d); } catch (e) { direct = ''; }
    }
    if (direct) {
      headers = refererOf(direct);
      return { url: direct, headers: headers };
    }
    return { url: '' };
  },
  lrc: function (episodeUrl) { return genericLrc.call(this, episodeUrl); },
  cover: function (episodeUrl) { return genericCover.call(this, episodeUrl); },
});

})();
