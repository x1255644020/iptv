// ---------- 喜马拉雅（严格按 dex 源 XimalayaFm/XmHelper/XmAudio 拉齐） ----------
(function () {
  var WEB = 'https://www.ximalaya.com';
  var MOB = 'https://mobile.ximalaya.com';
  var WS = 'https://mobwsa.ximalaya.com';
  var KEY = 'aaad3e4fd540b0f79dca95606e72bf93';
  // dex XmAudio.follow 内置 token（原 jar 行为拉齐：付费集不登录也能出声）
  var BUILTIN = '1&_token=99058760&2F7A7D20140CB53A7F19DAD516B4B8231C5035D43072C03498FA7FE2D5B2AB2063869B704078133Mdb75c6888F778BF_';
  // 最高优先级 VIP 登录会话槽位：默认空=走宿主 live cookie（VIP权益作品可播）；
  // 填入一份 SVIP/全量权益账号的完整 Cookie 串（含 1&_token=...）后，全部 VIP/SVIP 集通（等价 dex 反射 CookieManager）。
  var VIP_COOKIE = '';

  function fixCover(u) { // dex XmHelper.fixCover
    u = u || '';
    if (u.indexOf('//') === 0) u = 'https:' + u;
    if (u.indexOf('http://') === 0) u = 'https://' + u.substring(7);
    return u;
  }
  function xmHeaders(host) { // 自己登录 Cookie 优先，无则内置 token（= dex follow() 行为）
    var c = '';
    if (VIP_COOKIE) c = VIP_COOKIE;
    else if (typeof host.cookies === 'function') { var cw = String(host.cookies('https://www.ximalaya.com') || ''); var cm = cw ? '' : String(host.cookies('https://mobile.ximalaya.com/') || ''); c = (cw || cm || ''); }
    if (!c) c = BUILTIN; // VIP_COOKIE>宿主live cookie>BUILTIN 三级优先级 // cookie 非空(你登录的会话)就用, 完全取不到才兜底内置 token
    return { desktop: false, headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', 'Accept': 'application/json, text/plain, */*', 'Referer': WEB + '/', 'Cookie': c } };
  }
  // 播放器专用：dex follow() 等价。VIP 中间地址(redirect/vip/play)需带 token cookie 跟 302 换签名直链；免费则 302 到 buy_key 直链。不带 Range 保证整条流。
  function xmPlayerHeaders(host) {
    var c = '';
    if (VIP_COOKIE) c = VIP_COOKIE;
    else if (typeof host.cookies === 'function') { var cw = String(host.cookies('https://www.ximalaya.com') || ''); var cm = cw ? '' : String(host.cookies('https://mobile.ximalaya.com/') || ''); c = (cw || cm || ''); }
    if (!c) c = BUILTIN; // VIP_COOKIE>宿主live cookie>BUILTIN 三级优先级 // cookie 非空(你登录的会话)就用, 完全取不到才兜底内置 token
    return { 'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', 'Referer': WEB + '/', 'Cookie': c };
  }
  function webGet(host, url) { // dex NetL.getJson 等价：UA+Accept json
    return host.getJson(url, { desktop: false, headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36', 'Accept': 'application/json', 'Referer': WEB + '/' } });
  }
// ===== 元气网关（纯JS P-256 ECDSA，crypto.js 提供 xmGenKey/xmSign）=====
  var GW_BASE = 'https://yqts.haitangw.cc/yuanqibook/gateway';
  var GW_EMPTY = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
  var G_deviceId = null, G_key = null, G_spki = null, G_token = null, G_expire = 0;
  var gwUuid = function () {
    var h = '0123456789abcdef';
    var r = function (n) { var s = ''; for (var i = 0; i < n; i++) s += h.charAt(Math.floor(Math.random() * 16)); return s; };
    return r(8) + '-' + r(4) + '-4' + r(3) + '-' + h.charAt(8 + Math.floor(Math.random() * 4)) + r(3) + '-' + r(12);
  };
  function gwFetch(host, method, url, body, headers) {
    var opt = { headers: headers || {} };
    if (!opt.headers['User-Agent']) opt.headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
    if (!opt.headers['Accept']) opt.headers['Accept'] = 'application/json, */*';
    if (method === 'POST') { opt.method = 'POST'; opt.body = (body == null ? '{}' : body); opt.contentType = 'application/json'; }
    try { return String(host.getString(url, opt) || ''); } catch (e) { if (e.cancelled) throw e; return ''; }
  }
  function gwCanonical(method, url, ts, nonce) {
    var path = url, qs = '';
    var qi = url.indexOf('?');
    if (qi >= 0) { path = url.substring(0, qi); qs = url.substring(qi + 1); }
    var pm = /^https?:\/\/[^/]+(\/?[^?]*)?/.exec(path);
    path = (pm && pm[1]) ? pm[1] : '/';
    var arr = [];
    if (qs) {
      var parts = qs.split('&');
      for (var i = 0; i < parts.length; i++) {
        var kv = parts[i], eq = kv.indexOf('=');
        var k = xmUrlDecode(eq >= 0 ? kv.substring(0, eq) : kv);
        var v = xmUrlDecode(eq >= 0 ? kv.substring(eq + 1) : '');
        arr.push([k, v]);
      }
    }
    arr.sort(function (a, b) { var ka = xmPct(a[0]), kb = xmPct(b[0]); if (ka !== kb) return ka < kb ? -1 : 1; var va = xmPct(a[1]), vb = xmPct(b[1]); return va === vb ? 0 : (va < vb ? -1 : 1); });
    var sb = [];
    for (var j = 0; j < arr.length; j++) sb.push(xmPct(arr[j][0]) + '=' + xmPct(arr[j][1]));
    return 'yuanqi-gateway-v1\n' + method.toUpperCase() + '\n' + path + '\n' + sb.join('&') + '\n' + GW_EMPTY + '\n' + ts + '\n' + nonce;
  }
  function gwSignedHeaders(method, url, withToken) {
    var ts = '' + Math.floor(Date.now() / 1000);
    var nonce = gwUuid().replace(/-/g, '');
    var sig = xmSign(gwCanonical(method, url, ts, nonce), G_key.d);
    var h = { 'X-Yuanqi-Device': G_deviceId, 'X-Yuanqi-Timestamp': ts, 'X-Yuanqi-Nonce': nonce, 'X-Yuanqi-Signature': sig, 'X-Yuanqi-App-Version': '0.1.0' };
    if (withToken && G_token) h['Authorization'] = 'Bearer ' + G_token;
    return h;
  }
  function gwRegister(host) {
    if (!G_key) { G_key = xmGenKey(); G_spki = G_key.spki; G_deviceId = gwUuid(); }
    var body = '{"deviceId":"' + G_deviceId + '","publicKeySpki":"' + G_spki + '","packageName":"com.yuanqi.audiobook","appVersion":"0.1.0"}';
    gwFetch(host, 'POST', GW_BASE + '/v1/device/register', body, {});
  }
  function gwRequestToken(host) {
    var url = GW_BASE + '/v1/auth/token';
    var r = gwFetch(host, 'POST', url, '{}', gwSignedHeaders('POST', url, false));
    if (!r) return;
    try {
      var j = JSON.parse(r);
      G_token = String(j.token || '');
      var exp = (typeof j.expiresIn === 'number') ? j.expiresIn : 18000;
      G_expire = Date.now() + (Math.max(60, exp - 300) * 1000);
    } catch (e) {}
  }
  function gwEnsureRegistered(host) {
    if (!G_key) { G_key = xmGenKey(); G_spki = G_key.spki; G_deviceId = gwUuid(); }
    if (!G_token || Date.now() >= G_expire) { gwRegister(host); gwRequestToken(host); }
  }
  function gwResolve(host, tid) {
    try { gwEnsureRegistered(host); } catch (e) { return ''; }
    if (!G_token) return '';
    var url = GW_BASE + '/v1/gateway/ximalaya/play?playId=' + tid;
    var r = gwFetch(host, 'GET', url, null, gwSignedHeaders('GET', url, true));
    if (!r) return '';
    try {
      var j = JSON.parse(r);
      if (j.code !== 200) return '';
      var u = String(j.url || '');
      return u.indexOf('https://') === 0 ? u : '';
    } catch (e) { return ''; }
  }
  // dex fixHtml：img 样式修正 + http→https + color 继承
  function fixHtml(s) {
    if (!s) return '';
    s = String(s)
      .replace(/<img data-/g, '<img style="max-width:100%;height:auto;" data-')
      .replace(/<img src="http\//g, '<img style="max-width:100%;height:auto;" src="https://')
      .replace(/src="http\//g, 'src="https://')
      .replace(/color:#333333/g, 'color:inherit');
    return s;
  }
  // dex rich(cover, html, text)：封面图 div + fixHtml 正文 div
  function rich(cover, html, text) {
    var body = fixHtml(html || '');
    if (!body && text) body = String(text);
    if (!cover && !body) return '';
    var s = '';
    if (cover) s += '<div style="text-align:center;margin:0 0 12px 0"><img src="' + fixCover(cover) + '" style="display:block;width:56%;max-width:232px;margin:0 auto;border-radius:12px;box-shadow:0 4px 14px rgba(0,0,0,.2)"/></div>';
    if (body) s += '<div style="font-size:15px;line-height:1.9;text-align:justify">' + body + '</div>';
    return s;
  }
  // dex Ximalaya.plainText：去标签解实体，宿主 intro 只渲染纯文本，必须用它
  function plainText(s) {
    s = s || '';
    s = String(s)
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/"/gi, '"')
      .replace(/&#39;/gi, "'")
      .trim();
    s = s.replace(/\s{2,}/g, ' ');
    // 截断过长简介（宿主弹窗显示有限，dex 侧有 128 上限）
    if (s.length > 200) s = s.substring(0, 200) + '…';
    return s;
  }
  function albumUrl(id) { return WEB + '/album/' + id; }
  function lastId(url) { // dex lastId：取最后一个 / 之后
    url = String(url || '');
    var i = url.lastIndexOf('/');
    return i >= 0 ? url.substring(i + 1) : '';
  }
  function firstId(url) { // dex XmHelper.firstId：首个 3+ 位数字
    var m = /(\d{3,})/.exec(String(url || ''));
    return m ? m[1] : '';
  }
  function statusOf(d) { // dex：完结/连载 · N集 [· 付费]
    var s = (String(d.isFinished) === '2') ? '完结' : '连载';
    s += ' · ' + int(d, 'trackCount') + ' 集';
    return s;
  }  registerSource({
    id: 'agg_ximalaya_fm', name: '喜马拉雅', url: WEB + '/',
    group: '小说类',
    description: '喜马拉雅已接入元域网关付费可播（dex 源 XimalayaFm/XmHelper/XmAudio 全量移植）',
    isDiscoverable: true, isSearchable: true,
    multipleEpisodePages: true,

    // dex XmHelper.search：front/v1 老搜索接口（带 rows=20 spellchecker）
    search: function (keywords, page) {
      var host = this.host, kw = String(keywords).trim();
      var r = webGet(host, 'https://search.ximalaya.com/front/v1?core=album&kw=' + encodeURIComponent(kw) +
        '&page=' + page + '&rows=20&spellchecker=true&condition=relation&device=android&version=9.0.75&paidFilter=false');
      var resp = r.response || r;
      var books = items(resp, 'docs').map(function (d) {
        var id = str(d, 'id') || str(d, 'albumId');
        if (!id) return null;
        var b = {
          bookUrl: albumUrl(id), title: str(d, 'title'),
          coverUrl: fixCover(str(d, 'cover_path') || str(d, 'coverPath')),
          artist: str(d, 'nickname'), intro: plainText(str(d, 'intro') || str(d, 'custom_title')),
          status: '共 ' + int(d, 'tracks') + ' 集'
        };
        return b;
      }).filter(Boolean);
      var totalPage = int(resp, 'totalPage', page);
      var numFound = int(resp, 'numFound', 0);
      if (numFound) totalPage = Math.max(page, Math.ceil(numFound / 20));
      return { books: books, totalPage: totalPage };
    },

    // dex getCategoryMenus：写死 8 组子 tab（有声书/广播剧/相声评书/儿童/历史/人文/戏曲/情感生活）
    categoryMenus: function () {
      return [
        { title: '有声书', tabs: [
          { title: '全部', url: 'xm-cat:youshengshu::1' },
          { title: '文学', url: 'xm-cat:youshengshu:wenxue:1' },
          { title: '历史', url: 'xm-cat:youshengshu:reci234:1' },
          { title: '都市', url: 'xm-cat:youshengshu:reci235:1' },
          { title: '言情', url: 'xm-cat:youshengshu:reci231:1' },
          { title: '悬疑', url: 'xm-cat:youshengshu:reci232:1' },
          { title: '武侠', url: 'xm-cat:youshengshu:reci238:1' },
          { title: '幻想', url: 'xm-cat:youshengshu:reci233:1' }
        ]},
        { title: '广播剧', tabs: [
          { title: '全部', url: 'xm-cat:guangbojv::1' },
          { title: '都市', url: 'xm-cat:guangbojv:dushi:1' },
          { title: '古风言情', url: 'xm-cat:guangbojv:reci52:1' },
          { title: '武侠', url: 'xm-cat:guangbojv:wuxia:1' },
          { title: '仙侠', url: 'xm-cat:guangbojv:xianxia:1' },
          { title: '玄幻', url: 'xm-cat:guangbojv:xuanhuan:1' },
          { title: '科幻', url: 'xm-cat:guangbojv:kehuan:1' },
          { title: '悬疑推理', url: 'xm-cat:guangbojv:xuanyi:1' }
        ]},
        { title: '相声评书', tabs: [
          { title: '全部', url: 'xm-cat:xiangsheng::1' },
          { title: '相声', url: 'xm-cat:xiangsheng:xiangsheng:1' },
          { title: '评书', url: 'xm-cat:xiangsheng:pingshu:1' },
          { title: '小品', url: 'xm-cat:xiangsheng:xiaopin:1' },
          { title: '郭德纲', url: 'xm-cat:xiangsheng:reci556:1' },
          { title: '德云社', url: 'xm-cat:xiangsheng:reci1087:1' },
          { title: '单田芳', url: 'xm-cat:xiangsheng:reci411:1' }
        ]},
        { title: '儿童', tabs: [
          { title: '全部', url: 'xm-cat:ertong::1' },
          { title: '儿童文学', url: 'xm-cat:ertong:ertongwenxue:1' },
          { title: '故事', url: 'xm-cat:ertong:reci155:1' },
          { title: '科普百科', url: 'xm-cat:ertong:kepubaike:1' },
          { title: '儿歌', url: 'xm-cat:ertong:reci337:1' },
          { title: '少儿英语', url: 'xm-cat:ertong:xueqianyingyu:1' },
          { title: '哄睡', url: 'xm-cat:ertong:reci555:1' }
        ]},
        { title: '历史', tabs: [
          { title: '全部', url: 'xm-cat:lishi::1' },
          { title: '正史', url: 'xm-cat:lishi:zhengshi:1' },
          { title: '野史', url: 'xm-cat:lishi:yeshi:1' },
          { title: '军事', url: 'xm-cat:lishi:junshi:1' },
          { title: '战争', url: 'xm-cat:lishi:zhanzheng:1' },
          { title: '名人', url: 'xm-cat:lishi:mingren:1' },
          { title: '三国', url: 'xm-cat:lishi:reci270:1' }
        ]},
        { title: '人文', tabs: [
          { title: '全部', url: 'xm-cat:renwen::1' },
          { title: '国学', url: 'xm-cat:renwen:guoxue:1' },
          { title: '文学', url: 'xm-cat:renwen:wenxue:1' },
          { title: '名著', url: 'xm-cat:renwen:mingzhu:1' },
          { title: '哲学', url: 'xm-cat:renwen:zhexue:1' },
          { title: '传记', url: 'xm-cat:renwen:zhuanji:1' },
          { title: '诗词国学', url: 'xm-cat:renwen:reci430:1' }
        ]},
        { title: '戏曲', tabs: [
          { title: '全部', url: 'xm-cat:xiqu::1' },
          { title: '京剧', url: 'xm-cat:xiqu:jingju:1' },
          { title: '黄梅戏', url: 'xm-cat:xiqu:huangmeixi:1' },
          { title: '越剧', url: 'xm-cat:xiqu:yueju:1' },
          { title: '昆曲', url: 'xm-cat:xiqu:kunqu:1' },
          { title: '粤剧', url: 'xm-cat:xiqu:yuju:1' }
        ]},
        { title: '情感生活', tabs: [
          { title: '全部', url: 'xm-cat:qinggan::1' },
          { title: '情感', url: 'xm-cat:qinggan:qinggan:1' },
          { title: '故事', url: 'xm-cat:qinggan:gushi:1' },
          { title: '美文', url: 'xm-cat:qinggan:meiwen:1' },
          { title: '女性', url: 'xm-cat:qinggan:nvxing:1' },
          { title: '夜话', url: 'xm-cat:qinggan:yehua:1' },
          { title: '睡前', url: 'xm-cat:qinggan:reci46:1' }
        ]}
      ];
    },

    // dex getCategoryList：queryCategoryPageAlbums（perPage=30，total 上限 min(50, ceil(total/30))）
    categoryPage: function (url) {
      var m = /^xm-cat:([^:]*):([^:]*):(\d+)$/.exec(url);
      if (!m) return { books: [], totalPage: 0 };
      var page = parseInt(m[3], 10) || 1, perPage = 30;
      var data = webGet(this.host, WEB + '/revision/category/queryCategoryPageAlbums?category=' + m[1] +
        '&subcategory=' + m[2] + '&meta=&sort=0&page=' + page + '&perPage=' + perPage).data || {};
      var books = items(data, 'albums').map(function (a) {
        return {
          bookUrl: albumUrl(str(a, 'albumId')), title: str(a, 'title'),
          coverUrl: fixCover(str(a, 'coverPath') || str(a, 'cover')),
          artist: str(a, 'anchorName'), status: statusOf(a)
        };
      }).filter(function (b) { return b.title; });
      var totalPage = Math.min(50, Math.ceil(int(data, 'total') / perPage));
      return {
        books: books, currentPage: page, totalPage: Math.max(totalPage, page),
        nextUrl: books.length > 0 && page < totalPage ? 'xm-cat:' + m[1] + ':' + m[2] + ':' + (page + 1) : null
      };
    },

    // dex getBookDetailInfo + XmHelper.detail：revision/album 取 meta，双章节接口翻页
    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host, id = firstId(bookUrl);
      var detail = { episodes: [] };
      try {
        var json = webGet(host, WEB + '/revision/album?albumId=' + id);
        var main = at(json, 'data.mainInfo') || {};
        detail.title = str(main, 'albumTitle');
        detail.coverUrl = fixCover(str(main, 'cover'));
        detail.artist = str(at(json, 'data.anchorInfo'), 'anchorName');
        detail.intro = plainText(
          str(main, 'detailRichIntro') || str(main, 'richIntro') || str(main, 'shortIntro'));
      } catch (e) { if (e.cancelled) throw e; host.log('取专辑信息失败：' + e.message); }
      if (!loadEpisodes) return detail;

      var useBackup = false, seen = {};
      function trackPage(page) {
        if (!useBackup) {
          var json = host.getJson(MOB + '/mobile/v1/album/track?albumId=' + id +
            '&pageId=' + page + '&pageSize=200&isAsc=true&device=android', xmHeaders(host));
          if (int(json, 'ret') === 0 && json.data) return json.data;
          if (page > 1) return null;
          host.log('章节接口：' + str(json, 'msg') + '（ret=' + str(json, 'ret') + '），换备用接口');
          useBackup = true;
        }
        var backup = host.getJson(MOB + '/mobile/others/ca/album/track/' + id + '/true/' + page + '/200', xmHeaders(host));
        if (int(backup, 'ret') !== 0 || !(backup.tracks && backup.tracks.list)) {
          if (page > 1) return null;
          throw new Error('喜马拉雅：获取章节失败（' + str(backup, 'ret') + '）');
        }
        return backup.tracks;
      }
      try {
        for (var page = 1; page <= 500; page++) {
          var data = trackPage(page);
          if (!data) break;
          var max = int(data, 'maxPageId', 1); if (max <= 1) { var tc = int(data, 'totalTrackCount', 0) || int(data, 'total', 0); if (tc > 200) max = Math.ceil(tc / 200); } // Bug5: totalCount 双保险防 maxPageId 解析异常截断
          items(data, 'list').forEach(function (t) {
            var tid = str(t, 'trackId') || str(t, 'id');
            if (!tid || seen[tid]) return;
            seen[tid] = true;
                        detail.episodes.push({ title: str(t, 'title') || ('第' + detail.episodes.length + '集'), url: 'xm:' + tid, isFree: true });
          });
          if (page >= max) break; // 始终拉全部分页(对齐dex, 2813集不再截断到200)
          host.progress((page + 1) + ' / ' + max);
          host.sleep(150 + Math.random() * 250);
        }
      } finally { host.progress(null); }
      return detail;
    },

    // dex XmAudio.extract：三端点 + 正则抠 playUrl64/32/playUrl + 解转义 + follow 直连 +
    // 失败 fallback fetchVip（redirect/free/play/{tid}/1）
    audio: function (url) {
      var host = this.host;
      var u = String(url);
      var id = u.indexOf('xm:') === 0 ? u.substring(3).trim() : u;
      // 5.6.30 网关优先（纯JS P-256 ECDSA，付费集不依赖原jar）
      var gwU='';
      if (/^\d+$/.test(id)) { try { gwU=gwResolve(host, id); } catch (e) {} }
      if (gwU && gwU.indexOf('http') === 0) { host.log('[DIAG] GW_HIT tid=' + id); return { url: gwU, headers: xmPlayerHeaders(host) }; }
      host.log('[DIAG] GW_MISS tid=' + id + ' -> fallback 三级cookie/mobileAPI/free/官方AES');
      // 多 cookie 探测：VIP_COOKIE > 宿主live > BUILTIN，逐个打 API，哪份放出 playUrl 就用哪份
      // dex getText() 行为: API 请求完全匿名(不带 Cookie), 带任意cookie反而触发已登录非VIP拒绝分支
      // 只有 VIP_COOKIE(手动喂的全量session)才加入请求; 播放器跟302时用 xmPlayerHeaders 带cookie
      var _dw='', _dm='';
      if (typeof host.cookies==='function'){_dw=String(host.cookies('https://www.ximalaya.com')||'');_dm=String(host.cookies('https://mobile.ximalaya.com/')||'');}
      var anonOpts=[];
      if (VIP_COOKIE) anonOpts.push({desktop:false,headers:{'User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36','Accept':'application/json, text/plain, */*','Referer':WEB+'/','Cookie':VIP_COOKIE}});
      if (_dw||_dm) anonOpts.push({desktop:false,headers:{'User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36','Accept':'application/json, text/plain, */*','Referer':WEB+'/','Cookie':(_dw||_dm)}}); // live cookie, VIP免费期集靠它解锁
      anonOpts.push({desktop:false,headers:{'User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36','Accept':'application/json, text/plain, */*','Referer':WEB+'/','Cookie':BUILTIN}});
      host.log('[DIAG] www_cookie='+(_dw?('len='+_dw.length+' hasToken='+(_dw.indexOf('1&_token=')>=0)):'EMPTY')+' | anonMode='+(anonOpts.length>1?'ANON+VIP_COOKIE':'PURE_ANON'));
      var apis=[MOB+'/mobile/track/'+id,WS+'/mobile/track/baseInfo?trackId='+id,MOB+'/mobile/v1/track/baseInfo?trackId='+id];
      var raw='';
      outer:for(var oi=0;oi<anonOpts.length;oi++){
        var ao=anonOpts[oi];
        for(var i=0;i<apis.length;i++){
          try{
            var json=host.getJson(apis[i],ao);
            var txt=JSON.stringify(json).replace(/\\\//g,'/');
            var m64=/"playUrl64"\s*:\s*"([^"]+)"/.exec(txt);
            var m32=/"playUrl32"\s*:\s*"([^"]+)"/.exec(txt);
            var m0=/"playUrl"\s*:\s*"([^"]+)"/.exec(txt);
            if(m64){raw=m64[1];break outer;}else if(m32){raw=m32[1];break outer;}else if(m0){raw=m0[1];break outer;}
          }catch(e){if(e.cancelled)throw e;}
          if(i<apis.length-1 && !raw) host.sleep(300);
        }
        if(raw) break;
      }
      if (raw) {
        if (raw.indexOf('http') === 0) return { url: raw, headers: xmPlayerHeaders(host) };
        if (typeof host.aesEcbDecrypt === 'function') {
          var dec = host.aesEcbDecrypt(raw, KEY);
          if (dec && dec.indexOf('http') === 0) return { url: dec, headers: xmPlayerHeaders(host) };
          if (dec && dec.indexOf('/') === 0) return { url: MOB + dec, headers: xmPlayerHeaders(host) };
        }
        throw new Error('喜马拉雅播放地址解密失败');
      }
      // dex fetchVip：免费直链兜底
      var _fbOpt = { desktop: false, headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', 'Accept': 'application/json, text/plain, */*', 'Referer': WEB + '/', 'Cookie': BUILTIN } };
      var free = 'http://' + MOB.replace('https://', '') + '/mobile/redirect/free/play/' + id + '/1';
      try {
        var f = host.getJson(free, _fbOpt);
        var fu = str(f, 'url') || (f.data && f.data.url) || '';
        if (fu && fu.indexOf('http') === 0) return { url: fu, headers: xmPlayerHeaders(host) };
      } catch (e) { /* 兜底失败走报错 */ }
            // 官方 AES 兜底（经验包 officialFallback）: mobile-playpage/track/v3/baseInfo -> playUrlList -> aesEcbDecrypt
      try {
        var ourl = WEB + '/mobile-playpage/track/v3/baseInfo/' + Math.floor(Date.now() / 1000) + '?device=web&trackId=' + id + '&trackQualityLevel=1';
        var oj = host.getJson(ourl, _fbOpt);
        var tin = (oj.data && oj.data.trackInfo) || oj.trackInfo || {};
        var plist = tin.playUrlList || tin.urlList || [];
        var pick = '';
        var prio = ['M4A_64', 'MP3_64', 'M4A_24', 'MP3_32'];
        for (var q = 0; q < prio.length && !pick; q++) {
          for (var pi = 0; pi < plist.length; pi++) {
            var it = plist[pi] || {};
            if (str(it, 'format') === prio[q] || str(it, 'quality') === prio[q]) { pick = str(it, 'url'); break; }
          }
        }
        if (!pick && plist.length) pick = str(plist[0], 'url');
        if (pick && typeof host.aesEcbDecrypt === 'function') {
          var odec = host.aesEcbDecrypt(pick, KEY);
          if (odec && odec.indexOf('https://') === 0) { host.log('[DIAG] AES_HIT tid=' + id); return { url: odec, headers: xmPlayerHeaders(host) }; }
        }
      } catch (e) { /* 官方AES兜底失败走报错 */ }
host.log('喜马拉雅取音频失败 tid=' + id + '（网关+cookie三端点+free兜底+官方AES均无地址）');
      throw new Error('喜马拉雅：未取得播放地址（track ' + id + '）。若为付费集请确认已登录/内置 token 有效');
    },
    audioHeaders: function (audioUrl) { return xmPlayerHeaders(this.host); }
  });
})();