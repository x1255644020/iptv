// ============================================================================
// 懒人听书（移植自 sources_by_luoshu.jar 的 ShengYueSource，sourceId: lrts_shengyue2）
// 来源：com.github.eprendre.sources_by_luoshu.ShengYueSource
// 依赖：宿主注入的全局函数 registerSource / str / int / items
//       以及 host.getJson / host.progress
// 导入：把本文件加入 manifest.json 的 scripts 即可（顺序不限）
// 说明：分类与书籍详情走 m.lrts.me 官方 AJAX 接口；搜索与播放地址走
//       www.tingshu8.top 的公开代理（原作者源即如此，代理无响应时播放会失败）。
// ============================================================================
(function () {
  var MARK = 'sy-lrts:';
  var PAGE_SIZE = 60;
  var UA = 'Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36';
  var PROXY = 'http://www.tingshu8.top/yuan1/lrts.php';

  var lrtsOpts = { headers: { 'User-Agent': UA, 'Accept': 'application/json, */*', 'Referer': 'https://m.lrts.me/' } };
  var proxyOpts = { headers: { 'User-Agent': UA, 'Accept': 'application/json, */*' } };

  // 从 bookUrl（shengyue:<数字>）里抽出数字 id
  function digits(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      if (c >= '0' && c <= '9') out += c;
    }
    return out;
  }

  function getJson(host, url, opts) {
    return host.getJson(url, opts) || {};
  }

  function fetchMenuPage(host, bookId, page, cover, sArr) {
    var list = [];
    try {
      var json = getJson(host, 'https://m.lrts.me/ajax/getBookMenu?bookId=' + bookId + '&pageNum=' + page + '&pageSize=60&sortType=0', lrtsOpts);
      if (sArr && json.sections) sArr[0] = int(json, 'sections');
      var arr = json.list || [];
      for (var i = 0; i < arr.length; i++) {
        var it = arr[i];
        var sec = int(it, 'section');
        if (sec <= 0) continue;
        list.push({
          title: str(it, 'name'),
          url: MARK + bookId + '*' + sec,
          coverUrl: cover,
          free: int(it, 'payType') === 0
        });
      }
    } catch (e) { /* 单页失败不阻断整体 */ }
    return list;
  }

  registerSource({
    id: 'lrts_shengyue2', name: '懒人听书', url: 'https://m.lrts.me/',
    description: '懒人听书（LRTS）：有声小说、评书、戏曲、儿童、文学、名著等。搜索与播放地址依赖公开代理，代理不稳时可能搜不到或播不出。',
    multipleEpisodePages: true,

    search: function (keywords, page) {
      var books = [];
      try {
        var json = getJson(this.host, PROXY + '?name=' + encodeURIComponent(keywords) + '&page=' + page, proxyOpts);
        var arr = (json.data || {}).list || [];
        for (var i = 0; i < arr.length; i++) {
          var item = arr[i];
          var albumId = str(item, 'albumId');
          if (!albumId) continue;
          var sec = int(item, 'sections');
          var label = str(item, 'payLabel');
          books.push({
            coverUrl: str(item, 'cover'),
            bookUrl: 'shengyue:' + albumId,
            title: str(item, 'title'),
            artist: str(item, 'author'),
            status: (label ? label + ' · ' : '') + '共 ' + sec + ' 集',
            intro: str(item, 'intro')
          });
        }
      } catch (e) { /* 代理失败返回空结果 */ }
      return { books: books, totalPage: page };
    },

    categoryMenus: function () {
      function cat(name, id) { return { title: name, url: 'sy-cat:' + id }; }
      return [
        { title: '小说', tabs: [
          cat('全部', '1'), cat('玄幻奇幻', '11'), cat('古代言情', '10'), cat('武侠仙侠', '14'),
          cat('都市传说', '8'), cat('现代言情', '3020'), cat('科幻空间', '3021'), cat('历史幻想', '12'),
          cat('青春校园', '3106'), cat('穿越架空', '3109'), cat('网游竞技', '9042'), cat('次元专区', '9287')
        ] },
        { title: '评书', tabs: [cat('评书', '3')] },
        { title: '戏曲', tabs: [cat('戏曲', '4')] },
        { title: '儿童', tabs: [cat('儿童', '6')] },
        { title: '文学', tabs: [cat('文学', '13')] },
        { title: '名著', tabs: [cat('名著', '78')] }
      ];
    },

    categoryPage: function (url) {
      var m = /sy-cat:(\d+)(?:#(\d+))?/.exec(url);
      var cid = m ? m[1] : '1';
      var page = m && m[2] ? parseInt(m[2], 10) : 1;
      var books = [], totalPage = page;
      try {
        var json = getJson(this.host, 'https://m.lrts.me/ajax/getResourceList?dsize=1000&entityId=' + cid + '&entityType=1&pageNum=' + page + '&showFilters=1', lrtsOpts);
        var arr = json.books || json.albums || [];
        for (var i = 0; i < arr.length; i++) {
          var item = arr[i];
          var id = str(item, 'id');
          if (!id) id = str(item, 'baseEntityId');
          if (!id || id === '0') continue;
          var score = item.score || 0;
          books.push({
            coverUrl: str(item, 'cover'),
            bookUrl: 'shengyue:' + id,
            title: str(item, 'name'),
            artist: str(item, 'author'),
            status: score > 0 ? '评分 ' + score : '',
            intro: str(item, 'desc')
          });
        }
        var total = int(json, 'totalCount');
        totalPage = Math.max(1, Math.ceil(total / 1000));
      } catch (e) { /* 出错返回已拿到内容 */ }
      var nextUrl = page < totalPage ? ('sy-cat:' + cid + '#' + (page + 1)) : null;
      return { books: books, currentPage: page, totalPage: totalPage, nextUrl: nextUrl };
    },

    bookDetail: function (url, loadEpisodes, loadFullPages) {
      var episodes = [];
      if (!loadEpisodes) return { episodes: episodes };
      var host = this.host;
      var id = digits(url);
      if (!id) return { episodes: episodes };
      var cover = '', estimated = 0;
      try {
        var info = getJson(host, 'https://m.lrts.me/ajax/getBookInfo?id=' + id, lrtsOpts);
        cover = str(info, 'bestCover') || str(info, 'cover');
        estimated = int(info, 'estimatedSections');
      } catch (e) { /* 详情拿不到也继续取目录 */ }

      var sections = [0];
      episodes = episodes.concat(fetchMenuPage(host, id, 1, cover, sections));
      if (sections[0] > 0) estimated = sections[0];

      // 章节很多时按 60 一页继续往后取（最多 200 页）
      if (loadFullPages && episodes.length >= PAGE_SIZE && estimated > PAGE_SIZE) {
        var pages = Math.min(Math.ceil(estimated / 60), 200);
        for (var p = 2; p <= pages; p++) {
          episodes = episodes.concat(fetchMenuPage(host, id, p, cover, null));
          if (p % 5 === 0) host.progress('已加载 ' + episodes.length + ' 集');
        }
        host.progress(null);
      }
      return { episodes: episodes };
    },

    audio: function (url) {
      if (url.indexOf(MARK) !== 0) return url;
      var sub = url.slice(8); // 去掉 "sy-lrts:" 前缀 -> bookId*section
      var lastErr = null;
      for (var i = 0; i < 3; i++) {
        try {
          var json = getJson(this.host, PROXY + '?id=' + sub, proxyOpts);
          var u = str(json.data || {}, 'url');
          if (u) return u;
        } catch (e) { lastErr = e; }
      }
      throw new Error('懒人听书：获取播放地址失败（代理无响应）' + (lastErr ? '：' + lastErr.message : ''));
    }
  });
})();
