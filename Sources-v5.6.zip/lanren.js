// ================= 懒人听书（爱听api 版） =================
// 来源：XmlLrtSource.zip / xml_lrt.js，仅抽取其中的「懒人听书(爱听api)」源，
//       替换掉原 5.6 包里的 lanren.js（luoshu.jar 移植版，lrts_shengyue2）。
// 已适配 ShunSources 5.6 宿主契约（ES5 / Rhino，host.fetch 返回 {status,body}）。
//
// 接口（2026-11-08 实测全部可用）：
//   searchBook      GET https://m.lrts.me/ajax/searchBook?keyWord=&pageNum=&pageSize=20
//                       需登录 Cookie（内置，实测 apiStatus:0 / count:8785）；不带会 485 需登录
//   getCategory     GET https://m.lrts.me/ajax/getCategory        公开，data.bookTypeList 分类树
//   getBookTypePage GET https://m.lrts.me/ajax/getBookTypePage?typeId=  公开，data.recommendList 约12本
//   getBookMenu     GET https://m.lrts.me/ajax/getBookMenu?bookId=&pageNum=&pageSize=50
//                       公开，顶层 list[]（sectionId / section / name，name 可能带 BOM）
//   lrts.audio      GET https://fm.12311111.xyz/api/lrts/index.php?act=audio&bookId=&section=&opType=1
//                       -> data.url 带签名 m4a 直链（audio/mp4，24h 有效，必须带 Referer）
//
// 音频代理有 IP 限频（30 秒 1 次）：直链缓存 24h；播放命中缓存时顺手预取下一集，连播更顺。
// 默认不批量预取（prefetch=0），避免 5.6 同步宿主在详情里 sleep 卡住转圈。
// 若内置 Cookie 过期导致搜索提示「需要登录」，直接改本文件的 LRTS_COOKIE 常量即可。

(function () {
  'use strict';

  var UA = 'Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
  var HDR = { 'User-Agent': UA, Accept: 'application/json' };
  var BOM = '\ufeff';
  var TTL = 86400000; // 直链有效期 24h

  // 内置登录 Cookie（用户提供）：解锁官方 searchBook 搜索。
  var LRTS_COOKIE = 'TDC_itoken=1627976464%3A1792036655; token=36eb1f70d6572c3b15751b84b9fa4a546e7086ed2f2aa43e6bbdb8842602a7ae46310d47fa7dca4c5484e6d9afb6333822e0a32f636264a0169ff14cb01f3a3e59dcee28084bfe9eee55cb1fcc6fae4779cfd25199fbad00a13f3f89613eaad2; token.sig=BlGGr04fz3UVSevAfmxsIBUMOac';

  function fixCover(p) {
    if (!p) return '';
    if (p.indexOf('//') === 0) return 'https:' + p;
    return p;
  }

  function cleanName(s) {
    s = s || '';
    if (s.charAt(0) === BOM) s = s.slice(1);
    return s;
  }

  // 5.6 的 host.fetch 返回 { status, body }；body 统一转字符串再 parseJson。
  function getJsonOrThrow(host, url, headers) {
    var resp = host.fetch(url, { headers: headers || HDR });
    if (resp.status < 200 || resp.status >= 300) throw new Error('HTTP ' + resp.status);
    return parseJson(String(resp.body || ''));
  }

  function lrtsHeaders(host) {
    var h = { 'User-Agent': UA, Accept: 'application/json' };
    var ck = host.getPref('lrts_cookie', '') || LRTS_COOKIE;
    if (ck) h['Cookie'] = ck;
    return h;
  }

  function lrtsFetchRaw(host, url, headers) {
    var resp = host.fetch(url, { headers: headers || HDR });
    if (resp.status < 200 || resp.status >= 300) throw new Error('HTTP ' + resp.status);
    return String(resp.body || '');
  }

  function cacheGet(host, key) {
    var v = host.readCache(key);
    if (!v) return null;
    var age = host.cacheAge(key);
    if (age < 0 || age > TTL) return null;
    return v;
  }

  // 官方接口 apiStatus/status 非 0 表示异常（如 485 需登录），明确抛错而非静默返回 0 本。
  function lrtsCheck(json) {
    if (!json) return;
    var st = json.apiStatus != null ? json.apiStatus : json.status;
    if (st != null && st !== 0) throw new Error('懒人听书接口: ' + (json.msg || ('状态码 ' + st)));
  }

  function proxyCheck(json, actName) {
    actName = actName || '代理';
    if (!json || json.code == null) throw new Error(actName + '失败：未识别的返回');
    if (json.code !== 200) throw new Error(actName + '失败：' + (json.msg || ('code ' + json.code)));
    var d = json.data || {};
    if (d.error) throw new Error(actName + '：' + d.error);
    return d;
  }

  function lrtsBook(it) {
    return {
      bookUrl: 'lrts:' + it.id,
      title: it.name || '',
      author: it.author || '',
      artist: it.announcer || '',
      coverUrl: fixCover(it.cover),
      intro: it.desc || '',
      status: it.state === 2 ? '完结' : '连载'
    };
  }

  // 兜底：抓官网首页在架书单（服务端渲染，稳定可用），缓存复用。
  function lrtsHomeBooks(host) {
    var cacheKey = 'lrts_home_books';
    var c = cacheGet(host, cacheKey);
    if (c) {
      try { var arr = parseJson(c); if (arr && arr.length) return arr; } catch (e) { /* 缓存损坏则重抓 */ }
    }
    var html = '';
    try {
      var resp = host.fetch('https://m.lrts.me/', { headers: lrtsHeaders(host) });
      html = String(resp.body || '');
    } catch (e) { html = ''; }
    var books = [];
    if (!html) return books;
    var re = /<a href="\/book\/(\d+)" class="lr-item-row book"[^>]*>[\s\S]*?<div class="name lr-line-clamp-2"[^>]*>\s*([^<]+)/g;
    var mm;
    while ((mm = re.exec(html)) !== null) {
      var name = mm[2].replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
      if (!name) continue;
      books.push({ id: mm[1], name: name, author: '', announcer: '', cover: '', desc: '', state: 0 });
    }
    if (books.length) host.writeCache(cacheKey, JSON.stringify(books));
    return books;
  }

  // 容错提取 bookId：lrts:30011 / 网页 player?id=30011 / 裸数字 id 都能用。
  function lrtsBookId(input) {
    if (!input) return '';
    var m = /^lrts:(\d+)/.exec(input);
    if (m) return m[1];
    m = /[?&]id=(\d+)/.exec(input);
    if (m) return m[1];
    m = /(\d{4,})/.exec(input);
    if (m) return m[1];
    return input;
  }

  // 分类树：官方 getCategory（公开），只展示「有声小说」区；失效时兜底到「全部」入口。
  function lrtsCategoryTree(host) {
    var fallback = [{ title: '有声小说', tabs: [{ title: '全部', url: 'lrtsc:1:有声小说' }] }];
    var cacheKey = 'lrts_cat_raw';
    var raw = host.readCache(cacheKey);
    if (!raw || host.cacheAge(cacheKey) > 3600000) {
      try {
        raw = lrtsFetchRaw(host, 'https://m.lrts.me/ajax/getCategory', lrtsHeaders(host));
        host.writeCache(cacheKey, raw);
      } catch (e) { raw = ''; }
    }
    var json = raw ? parseJson(raw) : null;
    if (!json || (json.apiStatus != null && json.apiStatus !== 0)) return fallback;
    var topList = (json.data && json.data.bookTypeList) || [];
    var novelTop = null;
    for (var ti = 0; ti < topList.length; ti++) {
      var t = topList[ti];
      if (t && (t.id === 1 || t.name === '有声小说')) { novelTop = t; break; }
    }
    if (!novelTop) return fallback;
    var tabs = [{ title: '全部', url: 'lrtsc:' + novelTop.id + ':' + novelTop.name }];
    var subs = novelTop.subList || [];
    for (var ts = 0; ts < subs.length; ts++) {
      if (!subs[ts] || !subs[ts].id) continue;
      tabs.push({ title: subs[ts].name, url: 'lrtsc:' + subs[ts].id + ':' + subs[ts].name });
    }
    return [{ title: '有声小说', tabs: tabs }];
  }

  function lrtsSearch(host, kw, page) {
    var json = getJsonOrThrow(host, 'https://m.lrts.me/ajax/searchBook?keyWord=' +
      encodeURIComponent(kw) + '&pageNum=' + (page || 1) + '&pageSize=20', lrtsHeaders(host));
    lrtsCheck(json);
    var list = at(json, 'data.list') || at(json, 'list') || [];
    var books = [];
    for (var i = 0; i < list.length; i++) {
      if (!list[i].id) continue;
      books.push(lrtsBook(list[i]));
    }
    return { books: books, hasNext: !!json.hasNext || list.length >= 20 };
  }

  function lrtsFetchAudio(host, bookId, section) {
    var json = getJsonOrThrow(host, 'https://fm.12311111.xyz/api/lrts/index.php?act=audio&bookId=' +
      encodeURIComponent(bookId) + '&section=' + encodeURIComponent(section) + '&opType=1');
    var d = proxyCheck(json, '音频');
    return str(d, 'url') || str(json, 'data.url');
  }

  registerSource({
    id: '8a7f6e5d4c3b2a109876543210fedcba',
    name: '懒人听书(爱听api)',
    url: 'https://m.lrts.me',
    description: '懒人听书（爱听api 版）：搜索走官方 searchBook（内置登录 Cookie），分类取官方「有声小说」分类树，章节直连官方 getBookMenu，音频走代理（直链缓存 24h）。\n' +
      '默认不批量预取，进详情不卡顿；播放时会顺手缓存下一集，连播更顺。\n' +
      '若搜索提示「需要登录」，说明内置 Cookie 过期，改 lanren.js 里的 LRTS_COOKIE 常量即可。',
    group: '听书',
    multipleEpisodePages: true,
    config: [
      { type: 'select', key: 'prefetch', label: '预取集数(连播缓存，调大时详情会等待)', default: '0', options: ['0', '1', '2', '3', '5', '10', '20'] }
    ],

    search: function (keywords, page) {
      var r = lrtsSearch(this.host, keywords, page);
      return { books: r.books, totalPage: r.hasNext ? page + 1 : page };
    },

    categoryMenus: function () {
      return lrtsCategoryTree(this.host);
    },

    // lrtsc:<id>:<name> -> 官方分类书单；lrtshome: -> 官网首页在架书单（兜底）
    categoryPage: function (url) {
      var host = this.host;
      if (/^lrtshome:/.test(url)) {
        var hb = lrtsHomeBooks(host), hbooks = [];
        for (var h = 0; h < hb.length; h++) hbooks.push(lrtsBook(hb[h]));
        return { books: hbooks, currentPage: 1, totalPage: 1, nextUrl: '' };
      }
      var m = /^lrtsc:(\d+)/.exec(url);
      var typeId = m ? m[1] : '1';
      var json = getJsonOrThrow(host, 'https://m.lrts.me/ajax/getBookTypePage?typeId=' + typeId, lrtsHeaders(host));
      lrtsCheck(json);
      var rl = (json.data && json.data.recommendList) || [];
      var books = [];
      for (var i = 0; i < rl.length; i++) {
        var b = rl[i];
        if (!b.id) continue;
        books.push({
          bookUrl: 'lrts:' + b.id,
          title: b.name || '',
          author: b.author || '',
          artist: b.announcer || b.nickName || '',
          coverUrl: fixCover(b.cover) || fixCover(b.originCover),
          intro: b.desc || '',
          status: ''
        });
      }
      if (books.length === 0) {
        var fb = lrtsHomeBooks(host);
        for (var j = 0; j < fb.length; j++) books.push(lrtsBook(fb[j]));
      }
      return { books: books, currentPage: 1, totalPage: 1, nextUrl: '' };
    },

    // 章节直连官方 getBookMenu（公开可用）；开关 prefetch 时才批量预取（默认 0，不阻塞）。
    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host;
      var bookId = lrtsBookId(bookUrl);
      var out = [];
      var seen = {};        // 防接口异常时重复返回同一页，导致无限翻页卡死
      var total = 0;        // 接口给出的总集数（sections），作为硬上限
      var page = 1;
      while (true) {
        var json = getJsonOrThrow(host, 'https://m.lrts.me/ajax/getBookMenu?bookId=' + bookId +
          '&pageNum=' + page + '&pageSize=50');
        lrtsCheck(json);
        if (!total && json.sections) total = parseInt(json.sections, 10) || 0;
        var list = at(json, 'list');
        if (!list || !list.length) break;
        var dup = false;
        for (var i = 0; i < list.length; i++) {
          var it = list[i];
          if (!it.sectionId) continue;
          var sid = String(it.sectionId);
          if (seen[sid]) { dup = true; break; }
          seen[sid] = 1;
          out.push({
            title: cleanName(it.name),
            url: 'lrts:' + bookId + ':' + it.sectionId + ':' + (it.section || (page - 1) * 50 + i + 1),
            isFree: it.payType === 0,
            free: it.payType === 0
          });
        }
        if (dup) break;
        if (list.length < 50) break;
        if (total > 0 && out.length >= total) break;
        page++;
        if (page > 300) break;
      }
      if (loadFullPages && out.length > 0) {
        var pf = parseInt(host.getPref('prefetch', '0'), 10) || 0;
        if (pf > 0) {
          var firstSection = parseInt(out[0].url.split(':')[3], 10);
          for (var pi = 0; pi < pf && pi < out.length; pi++) {
            var seq = firstSection + pi;
            var key = 'lra_' + bookId + '_' + seq;
            if (cacheGet(host, key)) continue;
            try {
              var u = lrtsFetchAudio(host, bookId, seq);
              if (u) host.writeCache(key, u);
            } catch (e) { break; }
            if (pi < pf - 1) host.sleep(30000);
          }
        }
      }
      return { episodes: out };
    },

    audio: function (episodeUrl) {
      var host = this.host;
      var parts = episodeUrl.split(':');
      if (parts.length < 4) throw new Error('章节地址格式错误');
      var bookId = lrtsBookId(episodeUrl), section = parts[3];
      var cached = cacheGet(host, 'lra_' + bookId + '_' + section);
      if (cached) {
        // 命中缓存：顺手预取下一集（失败不阻塞，代理限频时会自动放弃）
        try {
          var next = parseInt(section, 10) + 1;
          if (!cacheGet(host, 'lra_' + bookId + '_' + next)) {
            var u = lrtsFetchAudio(host, bookId, next);
            if (u) host.writeCache('lra_' + bookId + '_' + next, u);
          }
        } catch (e) { /* 忽略预取失败 */ }
        return { url: cached, headers: { Referer: 'https://m.lrts.me/' } };
      }
      var url = lrtsFetchAudio(host, bookId, section);
      if (!url) {
        var json = getJsonOrThrow(host, 'https://fm.12311111.xyz/api/lrts/index.php?act=audio&bookId=' +
          encodeURIComponent(bookId) + '&section=' + encodeURIComponent(section) + '&opType=1');
        var msg = str(json, 'msg');
        throw new Error(msg ? ('音频接口: ' + msg) : '音频接口未返回地址');
      }
      host.writeCache('lra_' + bookId + '_' + section, url);
      return { url: url, headers: { Referer: 'https://m.lrts.me/' } };
    }
  });
})();
