// ============================================================================
// QQ 音乐 —— 独立源文件（搜索 + 榜单 + 播放）
//
// 运行依赖（宿主注入）：registerSource / str / int / items / at，以及
//   host.getJson / cookies / progress / sleep / log
// 另依赖同包内的 qq-sign.js（必须排在前面加载），它暴露
//   getSecuritySign(dataString)  —— QQ 音乐 Web 端 musicu.fcg 的签名函数
//
// 说明：QQ 音乐免费歌曲的播放地址需要向 musicu.fcg 的 vkey 接口动态换取，
// 该接口要求携带 sign（由 qq-sign.js 计算）。若某天播放全部失败，
// 通常是 QQ 轮换了签名密钥，只需更新 qq-sign.js 一个文件即可，本文件无需改动。
// 若有登录 Cookie（在插件页“登录” QQ 音乐后留下），会带上以拿到更高权限的地址。
// ============================================================================
(function () {
  var SITE = 'https://y.qq.com/';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
  var SEARCH_PER_PAGE = 20;
  var MAX_RANK_PAGES = 5;

  // 取签名函数（qq-sign.js 暴露的全局）
  function signFn() {
    return (typeof getSecuritySign === 'function') ? getSecuritySign : getSign;
  }
  // 一次性生成 guid（vkey 接口需要）
  function guid() {
    var s = '';
    for (var i = 0; i < 10; i++) s += Math.floor(Math.random() * 10);
    return s;
  }
  var GUID = guid();

  function options(host) {
    var headers = { Referer: SITE, 'User-Agent': UA };
    var cookie = (typeof host.cookies === 'function') ? String(host.cookies(SITE) || '') : '';
    if (cookie) headers['Cookie'] = cookie;
    return { desktop: true, headers: headers };
  }

  // 从 Cookie 里算 g_tk（QQ 音乐接口需要）
  function cookieValue(text, name) {
    var m = new RegExp('(?:^|;\\s*)' + name + '=([^;]*)').exec(text || '');
    return m ? m[1] : '';
  }
  function g_tk(p_skey) {
    var hash = 5381;
    for (var i = 0; i < p_skey.length; i++) hash += (hash << 5) + p_skey.charCodeAt(i);
    return hash & 0x7fffffff;
  }
  function loginInfo(host) {
    var cookie = (typeof host.cookies === 'function') ? String(host.cookies(SITE) || '') : '';
    var p_skey = cookieValue(cookie, 'p_skey') || cookieValue(cookie, 'skey');
    var uin = cookieValue(cookie, 'uin') || '0';
    return { cookie: cookie, gtk: p_skey ? g_tk(p_skey) : 5381, uin: uin, loginflag: p_skey ? 1 : 0 };
  }

  // ---------------- 搜索（已验证可用） ----------------
  function searchUrl(word, page) {
    return 'https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w=' +
      encodeURIComponent(word) + '&n=' + SEARCH_PER_PAGE + '&p=' + page +
      '&format=json&inCharset=utf-8&outCharset=utf-8';
  }
  function songBook(s, prefix) {
    var singers = (s.singer || []).map(function (x) { return x.name; }).join('/');
    var mid = s.songmid;
    var dur = int(s, 'interval');
    var mm = Math.floor(dur / 60), ss = dur % 60;
    var time = (mm < 10 ? '0' : '') + mm + ':' + (ss < 10 ? '0' : '') + ss;
    var vip = int(at(s, 'pay'), 'payplay') > 0 || int(at(s, 'pay'), 'payalbum') > 0;
    return {
      bookUrl: 'qq:song:' + mid,
      title: s.songname,
      artist: singers,
      intro: s.albumname || '',
      status: (vip ? 'VIP · ' : '') + time,
      coverUrl: mid ? ('https://y.gtimg.cn/music/photo_new/T002R300x300M000' + (s.albummid || '') + '.jpg') : ''
    };
  }
  function searchSongs(host, word, page) {
    var json = host.getJson(searchUrl(word, page), options(host));
    var list = items(at(json, 'data.song'), 'list') || [];
    return list.map(function (s) { return songBook(s); });
  }

  // ---------------- 榜单（巅峰榜，使用免签名接口，最稳定） ----------------
  // topId 取自 QQ 音乐官方榜单（通过 toplist GetAll 核对，避免使用已失效的 ID）
  var RANKS = [
    ['飙升榜', '62'], ['热歌榜', '26'], ['新歌榜', '27'], ['流行指数榜', '4'],
    ['欧美榜', '3'], ['韩国榜', '16'], ['日本榜', '17'], ['影视金曲榜', '29'],
    ['网络歌曲榜', '28'], ['抖音热歌榜', '60'], ['说唱榜', '58'], ['国风热歌榜', '65']
  ];

  // 精选播放列表：按风格/心情聚合的歌单（复用搜索能力，关键词驱动，返回真实歌曲、可连续播放）
  var PLAYLISTS = [
    ['怀旧金曲', '经典老歌怀旧'],
    ['轻音乐', '轻音乐 纯音乐'],
    ['伤感情歌', '伤感情歌'],
    ['粤语经典', '粤语经典'],
    ['华语流行', '华语流行金曲'],
    ['古风', '古风歌曲']
  ];
  function rankName(id) {
    for (var i = 0; i < RANKS.length; i++) if (RANKS[i][1] === id) return RANKS[i][0];
    return '排行榜';
  }
  function rankBooks() {
    return RANKS.map(function (r) {
      return { bookUrl: 'qq:rank:' + r[1] + '#1', title: r[0], artist: 'QQ 音乐', intro: '巅峰榜：' + r[0], status: '' };
    });
  }
  // 取某个榜单的歌曲（使用免签名的 fcg_v8_toplist_cp 接口，无需 sign，最稳定）
  function rankSongs(host, topId, page) {
    var num = SEARCH_PER_PAGE, begin = (page - 1) * num;
    var url = 'https://c.y.qq.com/v8/fcg-bin/fcg_v8_toplist_cp.fcg?tpl=3&page=detail' +
      '&topid=' + encodeURIComponent(topId) +
      '&type=top&song_begin=' + begin + '&song_num=' + num +
      '&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8' +
      '&notice=0&platform=yqq.json&needNewCode=0';
    var json = host.getJson(url, options(host));
    var list = json.songlist || [];
    // 每条元素是 { Franking_value, data:{ songmid, songname, singer[], albummid, interval, pay } }
    return list.map(function (item) {
      var d = item.data || item;
      return songBook({
        songname: d.songmid ? d.songname : (d.songname || d.title),
        singer: (d.singer || []).map(function (x) { return { name: x.name }; }),
        albumname: d.albumname,
        songmid: d.songmid || d.mid,
        interval: d.interval,
        albummid: d.albummid,
        pay: d.pay
      });
    });
  }

  // ---------------- 播放地址（vkey，依赖签名接口） ----------------
  function audioUrl(host, songmid) {
    var li = loginInfo(host);
    var data = {
      req_0: {
        module: 'vkey.GetVkeyServer', method: 'CgiGetVkey',
        param: { guid: GUID, songmid: [songmid], songtype: [0], uin: li.uin, loginflag: li.loginflag, platform: '20' }
      }
    };
    var dataStr = JSON.stringify(data);
    var sign = signFn()(dataStr);
    var url = 'https://u.y.qq.com/cgi-bin/musicu.fcg?-=getVkey&g_tk=' + li.gtk +
      '&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0' +
      '&platform=yqq.json&needNewCode=0&uin=0&data=' + encodeURIComponent(dataStr) +
      '&sign=' + encodeURIComponent(sign);
    var json = host.getJson(url, options(host));
    var info = at(json, 'req_0.data.midurlinfo.0');
    var purl = str(info, 'purl');
    var sip = items(at(json, 'req_0.data'), 'sip') || [];
    if (!purl) {
      var result = int(info, 'result');
      throw new Error(result === 104003
        ? '这首歌需要登录或会员，请先在插件页“登录” QQ 音乐'
        : '没有取到播放地址（QQ 音乐接口返回异常，可能密钥已更新）');
    }
    return { url: sip[0] + purl, headers: { Referer: SITE } };
  }

  registerSource({
    id: '2b3c4d5e6f708192a3b4c5d6e7f80912', name: 'QQ音乐', url: SITE, group: '音乐',
    description: '推荐指数:4星 ⭐⭐⭐⭐\n搜索歌曲、听巅峰榜，直接播 QQ 音乐音源。\n' +
      '搜索与榜单已可直接使用（榜单走免签名接口，最稳定）；仅播放依赖 musicu.fcg 的签名接口，若某天播放全部失败，多半是 QQ 轮换了签名密钥，更新 qq-sign.js 即可，本文件无需改动。\n' +
      '在插件页“登录” QQ 音乐后，可播放需要登录/会员的歌曲。',
    multipleEpisodePages: true,

    // ---------------- 登录（在插件页点“登录”打开网页登录，登录态以 Cookie 为准） ----------------
    loginUrl: SITE,
    loginDesktop: true,
    checkLogin: function () {
      var host = this.host;
      var cookie = String(host.cookies(SITE) || '');
      var uin = cookieValue(cookie, 'uin');
      // 以下任意一组登录态存在，即视为已登录（QQ 网页登录写 p_skey/skey，QQ 音乐 OAuth 写 qqmusic_key/psrf_*）
      var skey = cookieValue(cookie, 'p_skey') || cookieValue(cookie, 'skey') ||
        cookieValue(cookie, 'qqmusic_key') || cookieValue(cookie, 'psrf_qqaccess_token') || cookieValue(cookie, 'psrf_musickey');
      if (!uin || !skey) throw new Error('还没有登录 QQ 音乐，请在插件页点“登录”');
      // 尽量取昵称；接口取不到（或未登录态）就回退到 QQ 号
      try {
        var json = host.getJson(
          'https://c.y.qq.com/rsc/fcgi-bin/fcg_get_profile_homepage.fcg?cid=0&reqfrom=1&g_tk=' +
          g_tk(skey),
          { desktop: true, headers: { Referer: SITE, 'User-Agent': UA } }
        );
        var nick = str(json, 'data.nickname') || str(json, 'nickname') || str(json, 'data.name');
        if (nick) return nick;
      } catch (e) { /* 昵称接口失败不影响登录判定 */ }
      return uin.replace(/^o/, '');
    },

    // 经典老歌：复用搜索能力，用关键词直接拉出 80/90 年代金曲（已验证返回的都是真老歌，免签名）
    categoryMenus: function () {
      return [{
        title: 'QQ 音乐',
        tabs: [{ title: '搜索', url: 'qq:search:' }, { title: '巅峰榜', url: 'qq:ranks' }]
          .concat(RANKS.map(function (r) { return { title: r[0], url: 'qq:rank:' + r[1] + '#1' }; }))
      }, {
        title: '经典老歌',
        tabs: [
          { title: '80年代经典', url: 'qq:search:' + encodeURIComponent('80年代经典老歌') },
          { title: '90年代经典', url: 'qq:search:' + encodeURIComponent('90年代经典老歌') }
        ]
      }, {
        title: '播放列表',
        tabs: PLAYLISTS.map(function (p) {
          return { title: p[0], url: 'qq:search:' + encodeURIComponent(p[1]) };
        })
      }];
    },

    categoryPage: function (url) {
      var host = this.host, key = String(url);
      if (key === 'qq:ranks') {
        return { books: rankBooks(), currentPage: 1, totalPage: 1, nextUrl: null };
      }
      var m = /^qq:(rank|search):([^#]*)(?:#(\d+))?$/.exec(key);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var type = m[1], arg = m[2], page = parseInt(m[3] || '1', 10) || 1;
      var books, more;
      if (type === 'rank') {
        books = rankSongs(host, arg, page);
        more = books.length >= SEARCH_PER_PAGE;
      } else if (arg) {
        books = searchSongs(host, decodeURIComponent(arg), page);
        more = books.length >= SEARCH_PER_PAGE;
      } else {
        return { books: [], totalPage: 1 };
      }
      return {
        books: books, currentPage: page, totalPage: more ? page + 1 : page,
        nextUrl: more ? 'qq:' + type + ':' + arg + '#' + (page + 1) : null
      };
    },

    search: function (keywords, page) {
      var word = String(keywords || '').trim();
      if (!word) return { books: [], totalPage: 1 };
      var books = searchSongs(this.host, word, page);
      var more = books.length >= SEARCH_PER_PAGE;
      return { books: books, totalPage: more ? page + 1 : page };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host, url = String(bookUrl);

      // 单曲
      if (url.indexOf('qq:song:') === 0) {
        var mid = url.substring('qq:song:'.length);
        // 详情没有额外信息，直接用搜索条目即可；这里只保证有标题与一集
        return {
          title: 'QQ 音乐', artist: '', status: '',
          episodes: [{ title: '播放', url: url }]
        };
      }

      // 榜单
      var m = /^qq:rank:(\d+)(?:#(\d+))?$/.exec(url);
      if (!m) throw new Error('不认识的书籍地址：' + url);
      var topId = m[1], detail = {
        title: rankName(topId), artist: 'QQ 音乐', intro: '巅峰榜：' + rankName(topId),
        coverUrl: '', episodes: []
      };
      if (!loadEpisodes) return detail;
      var pages = loadFullPages ? MAX_RANK_PAGES : 1;
      for (var p = 1; p <= pages; p++) {
        var songs = rankSongs(host, topId, p);
        if (!songs.length) break;
        songs.forEach(function (b) {
          detail.episodes.push({ title: b.title + (b.artist ? ' - ' + b.artist : ''), url: b.bookUrl });
        });
        if (songs.length < SEARCH_PER_PAGE) break;
        if (!loadFullPages) break;
        host.progress((p + 1) + ' 页');
      }
      host.progress(null);
      detail.status = detail.episodes.length + ' 首';
      return detail;
    },

    audio: function (episodeUrl) {
      var url = String(episodeUrl).replace(/^qq:song:/, '');
      if (url.indexOf('qq:song:') === 0 || !url) throw new Error('不认识的章节地址，请刷新列表');
      return audioUrl(this.host, url);
    },

    audioHeaders: function () { return { Referer: SITE }; },
    coverHeaders: function () { return { Referer: SITE }; }
  });
})();
