// ============================================================================
// 酷我音乐（多个音乐榜单 + 8090经典老歌整张连播歌单 + 按歌名搜歌）—— 移植版 JS 源
//
// 来源：sources_by_eprendre.jar（eprendre 的 Java 插件）反编译出的
//       com.github.eprendre.my_sound_01.HiGeQu
// 原 Java 源 id：d1e7b4c82f5a46139c8d0e27b5a3f164（本文件沿用，书架可互通）
// 说明：ShunSources v5.6 里只有「酷我畅听」（听书频道），没有这个音乐榜单源，
//       所以按 v5.6 的 registerSource 契约重新实现，可直接放进 manifest.json。
//
// 依赖：宿主注入的 registerSource / str / int，以及
//       host.getHtml / getString / getStrings / parseHtml / readCache /
//       writeCache / cacheAge / progress / sleep / log
//       不依赖 common.js（Shun），也不依赖 host.base64Decode（自带纯 JS 解码）
//
// 站点结构：
//   榜单页   https://higequ.com/{榜单代码}/?page=N
//   搜索页   https://higequ.com/s/{关键词}/{页码}
//   播放页   https://higequ.com/player/{rid}/?name=..&artist=..
//           页面把音频直链 Base64 编码后放在脚本变量里（新版 const encodedUrl，旧版 let code），解码后即 mp3 地址
//   列表项   .result-item[data-rid] 内的 .result-title / .result-artist /
//            .result-album / .rank-badge
// ============================================================================
(function () {
  var SITE = 'https://higequ.com/';
  var UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
  var PER_PAGE = 30;        // 榜单每页条数
  var SEARCH_PER_PAGE = 50; // 搜索每页条数
  var MAX_PAGES = 6;        // 一本「榜单」最多连着取几页
  var CACHE = 'higeq-charts.json';
  var CACHE_TTL = 10 * 60 * 1000;

  // 注意：higequ.com 已大改版，绝大多数榜单路由（抖音/影视/网红/儿歌/DJ/欧美/韩语/日语…
  // 等）已返回 404。下面只保留实测可用的榜单 code，避免点开就「这个分类下没有内容」。
  var CHARTS = [
    ['飙升榜', 'biaosheng'], ['新歌榜单', 'xinge'], ['热歌榜单', 'rege'], ['粤语榜', 'yueyu'],
    ['怀旧榜', 'jdhj'], ['80/90年代经典老歌', 'oldies']
  ];

  // 对齐 Java URLEncoder.encode(s, "UTF-8").replace("+", "%20")
  function enc(v) {
    return encodeURIComponent(String(v === undefined || v === null ? '' : v))
      .replace(/[!'()*]/g, function (c) { return '%' + c.charCodeAt(0).toString(16).toUpperCase(); });
  }
  function options() {
    return { desktop: false, headers: { Referer: SITE, 'User-Agent': UA } };
  }
  function doc(host, url) { return host.getHtml(url, options()); }
  function text(el, selector) {
    var e = el.first(selector);
    return e.exists() ? e.text().trim() : '';
  }
  function ogImage(document) {
    var found = '';
    document.select('meta').forEach(function (m) {
      if (!found && m.attr('property') === 'og:image') found = m.attr('content');
    });
    return found || '';
  }
  function chartUrl(code, page) { return SITE + code + '/?page=' + page; }
  function searchUrl(word, page) { return SITE + 's/' + enc(word) + '/' + page; }

  // 纯 JS Base64 解码：解码结果是 ASCII 的 http 地址，不必处理多字节字符
  function b64(s) {
    var CH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var out = [], buf = 0, bits = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      if (c === '=') break;
      var v = CH.indexOf(c);
      if (v < 0) continue;
      buf = (buf << 6) | v;
      bits += 6;
      if (bits >= 8) { bits -= 8; out.push(String.fromCharCode((buf >> bits) & 255)); }
    }
    return out.join('');
  }

  // 列表页 → 歌曲 Book[]（每首歌当成只有一集的书）
  function parseItems(document) {
    var books = [];
    document.select('.result-item').forEach(function (item) {
      var rid = item.attr('data-rid');
      if (!rid) return;
      var title = text(item, '.result-title'), artist = text(item, '.result-artist');
      var album = text(item, '.result-album'), rank = text(item, '.rank-badge');
      if (!title) return;
      var player = SITE + 'player/' + rid + '/?name=' + enc(title) + '&artist=' + enc(artist);
      books.push({
        bookUrl: 'higeq:song:' + player, title: title, artist: artist,
        intro: album, status: rank ? '第 ' + rank + ' 位' : album
      });
    });
    return books;
  }

  function songsOf(host, url) {
    try { return parseItems(doc(host, url)); } catch (e) { if (e.cancelled) throw e; return []; }
  }

  // 一本书（榜单）里的章节：把列表页的歌曲转成一集集
  function episodesOf(host, urls, loadFullPages) {
    var list = [];
    try {
      for (var i = 0; i < urls.length; i++) {
        if (i > 0) {
          if (!loadFullPages) break;
          host.progress((i + 1) + ' / ' + urls.length);
          host.sleep(150 + Math.random() * 250);
        }
        songsOf(host, urls[i]).forEach(function (b) {
          list.push({ title: b.title + (b.artist ? ' - ' + b.artist : ''), url: b.bookUrl });
        });
      }
    } finally { host.progress(null); }
    return list;
  }

  // 80/90 年代经典老歌：搜索两个关键词、跨页合并、按「歌名-歌手」去重，并剔除非 80/90 年代歌手
  // 结果缓存 10 分钟（与榜单封面同生命周期），避免每次进入都重抓几十页
  var OLDIES_WORDS = ['80年代歌曲', '90年代歌曲', '怀旧老歌', '经典老歌怀旧'];
  var OLDIES_CAP = 200;       // 目标不重复首数（命中即停）
  var OLDIES_PAGES = 8;       // 每个关键词最多抓的页数（每页约 10 首，4 词共最多 32 次请求，实测约 29 次可达 200 首）
  var OLDIES_TTL = 60 * 60 * 1000;  // 老歌歌单缓存 1 小时，避免频繁重抓几十页导致转圈
  var OLDIES_CACHE = 'higeq-oldies-v3.json';  // 换 key 清掉旧版坏缓存
  // 明显非 80/90 年代流行的歌手/团体（2000 年后才走红或网络神曲类），直接剔除，保证年代纯正
  var OLDIES_BLOCK = ['周杰伦', '林俊杰', '陶喆', '胡歌', 's.h.e.', 'she', '蔡依林', '五月天', '萧亚轩', '田馥甄',
    '邓紫棋', 'g.e.m.', '许嵩', '汪苏泷', '薛之谦', '张杰', 'tfboys', '李荣浩', '毛不易', '华晨宇', '周深', '陈奕迅',
    '王力宏', 'f4', '飞轮海', '凤凰传奇', '刀郎', '杨丞琳', '孙燕姿', '梁静茹', '张韶涵', '容祖儿', 'twins', '罗志祥',
    '潘玮柏', '吴克群', '王蓉', '庞龙', '香香', '网络歌手', 'dj', '王心凌', '后弦', '徐良', '回音哥', '本兮', '小沈阳',
    '慕容晓晓', '龚琳娜', '筷子兄弟', '庞麦郎', '大张伟', '曾轶可', '乌兰图雅', '云菲菲', '祁隆', '陈瑞', '花儿乐队', '南拳妈妈'];
  function isOldieArtist(a) {
    var first = String(a || '').split(/[&\/、，,\s]/)[0].trim().toLowerCase();
    for (var i = 0; i < OLDIES_BLOCK.length; i++) if (first === OLDIES_BLOCK[i]) return false;
    return true;
  }
  function oldiesSongs(host) {
    try {
      if (typeof host.cacheAge === 'function') {
        var age = host.cacheAge(OLDIES_CACHE);
        if (age >= 0 && age < OLDIES_TTL) {
          var c = JSON.parse(host.readCache(OLDIES_CACHE));
          if (c && c.length) return c;
        }
      }
    } catch (e) { }
    var seen = {}, out = [];
    for (var w = 0; w < OLDIES_WORDS.length && out.length < OLDIES_CAP; w++) {
      for (var p = 1; p <= OLDIES_PAGES && out.length < OLDIES_CAP; p++) {
        var books = songsOf(host, searchUrl(OLDIES_WORDS[w], p));
        if (!books.length) break;
        for (var i = 0; i < books.length; i++) {
          if (out.length >= OLDIES_CAP) break;
          var b = books[i];
          if (!isOldieArtist(b.artist)) continue;          // 跳过非 80/90 年代歌手
          var key = (b.title + ' - ' + b.artist).toLowerCase();
          if (seen[key]) continue;
          seen[key] = 1; out.push(b);
        }
        if (typeof host.sleep === 'function') host.sleep(80);
      }
    }
    try { if (typeof host.writeCache === 'function') host.writeCache(OLDIES_CACHE, JSON.stringify(out)); } catch (e) { }
    return out;
  }

  // 20 个榜单做成书，封面取各榜单首页的 og:image（并发抓，缓存 10 分钟）
  function chartBooks(host) {
    var age = typeof host.cacheAge === 'function' ? host.cacheAge(CACHE) : -1;
    if (age >= 0 && age < CACHE_TTL) {
      try {
        var cached = JSON.parse(host.readCache(CACHE));
        if (cached && cached.length === CHARTS.length) return cached;
      } catch (e) { }
    }
    var urls = CHARTS.map(function (c) { return chartUrl(c[1], 1); });
    var texts;
    try { texts = host.getStrings(urls, options(), 6); } catch (e) { if (e.cancelled) throw e; texts = []; }
    var books = CHARTS.map(function (c, i) {
      var cover = '';
      if (c[1] !== 'oldies' && texts[i]) {
        try { cover = ogImage(host.parseHtml(texts[i], urls[i])); } catch (e) { }
      }
      return {
        bookUrl: 'higeq:chart:' + c[1] + '#1', title: c[0], coverUrl: cover,
        artist: '酷我音乐', intro: '榜单：' + c[0], status: ''
      };
    });
    // 全部抓到才写缓存，避免把不完整的结果固化
    var complete = texts.length === CHARTS.length && texts.every(function (t) { return t !== null && t !== undefined; });
    if (complete && typeof host.writeCache === 'function') {
      try { host.writeCache(CACHE, JSON.stringify(books)); } catch (e) { }
    }
    return books;
  }

  function chartName(code) {
    for (var i = 0; i < CHARTS.length; i++) if (CHARTS[i][1] === code) return CHARTS[i][0];
    return code;
  }

  registerSource({
    id: 'd1e7b4c82f5a46139c8d0e27b5a3f164', name: '酷我音乐', url: SITE, group: '音乐',
    description: '推荐指数:4星 ⭐⭐⭐⭐\n多个音乐榜单 + 8090经典老歌整张连播歌单（约 200 首，去重、剔除非年代歌手）+ 按歌名搜歌。点进「8090经典老歌」就是一份完整播放列表，自动连播下一首。\n来源是酷我的音源，直接播 mp3。',
    multipleEpisodePages: true,

    categoryMenus: function () {
      return [{ title: '音乐榜单', tabs: [{ title: '全部榜单', url: 'higeq:charts' }].concat(
        CHARTS.map(function (c) { return { title: c[0], url: 'higeq:chart:' + c[1] + '#1' }; })
      ) }];
    },

    categoryPage: function (url) {
      var host = this.host, key = String(url);
      if (key === 'higeq:charts') {
        return { books: chartBooks(host), currentPage: 1, totalPage: 1, nextUrl: null };
      }
      var m = /^higeq:(chart|search):([^#]*)(?:#(\d+))?$/.exec(key);
      if (!m) throw new Error('不认识的分类地址：' + url);
      var type = m[1], arg = m[2], page = parseInt(m[3] || '1', 10) || 1;
      if (arg === 'oldies') {
        // 整个「80/90 经典老歌」做成【一本完整的播放列表】——全部老歌作为同一本书的
        // 多个「集」。点开后在播放器里会自动连播下一集（宿主对多集书籍的原生行为）。
        // 这里只返回这一本书，真正的抓取与去重在 bookDetail 里完成（带缓存，只抓一次）。
        return {
          books: [{
            bookUrl: 'higeq:chart:oldies#1',
            title: '80/90年代经典老歌',
            artist: '酷我音乐',
            intro: '80/90 年代流行金曲合集 · 点开自动连播全部歌曲',
            status: '精选歌单',
            coverUrl: ''
          }],
          currentPage: 1, totalPage: 1, nextUrl: null
        };
      }
      var listUrl = type === 'chart' ? chartUrl(arg, page) : searchUrl(decodeURIComponent(arg), page);
      var books = songsOf(host, listUrl);
      var per = type === 'chart' ? PER_PAGE : SEARCH_PER_PAGE;
      var more = books.length >= per;
      return {
        books: books, currentPage: page, totalPage: more ? page + 1 : page,
        nextUrl: more ? 'higeq:' + type + ':' + arg + '#' + (page + 1) : null
      };
    },

    search: function (keywords, page) {
      var word = String(keywords || '').trim();
      if (!word) return { books: [], totalPage: 1 };
      var books = songsOf(this.host, searchUrl(word, page));
      var more = books.length >= SEARCH_PER_PAGE;
      return { books: books, totalPage: more ? page + 1 : page };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host, url = String(bookUrl);

      // 单曲：只有它自己这一集
      if (url.indexOf('higeq:song:') === 0) {
        var player = url.substring('higeq:song:'.length);
        var nm = /[?&]name=([^&]*)/.exec(player), am = /[?&]artist=([^&]*)/.exec(player);
        var song = decodeURIComponent(nm ? nm[1] : '') || '音频';
        var artist = decodeURIComponent(am ? am[1] : '');
        return {
          title: song, artist: artist, status: '',
          episodes: [{ title: song + (artist ? ' - ' + artist : ''), url: url }]
        };
      }

      // 榜单：把若干页的歌曲串成章节，可连播
      var m = /^higeq:chart:([a-z0-9]+)(?:#(\d+))?$/.exec(url);
      if (!m) throw new Error('不认识的书籍地址：' + url);
      var code = m[1];
      // 80/90 经典老歌：搜索两关键词、合并去重到 200 首（一个完整播放列表）
      if (code === 'oldies') {
        var allSongs = oldiesSongs(host);
        var od = {
          title: '80/90年代经典老歌', artist: '酷我音乐',
          intro: '80/90 年代流行金曲合集（去重约 200 首，已剔除非年代歌手，点开自动连播）', coverUrl: '', episodes: []
        };
        if (!loadEpisodes) return od;
        allSongs.forEach(function (b) {
          od.episodes.push({ title: b.title + (b.artist ? ' - ' + b.artist : ''), url: b.bookUrl });
        });
        od.status = od.episodes.length + ' 首';
        return od;
      }
      var detail = {
        title: chartName(code), artist: '酷我音乐', intro: '榜单：' + chartName(code),
        coverUrl: '', episodes: []
      };
      if (!loadEpisodes) return detail;
      var pages = loadFullPages ? MAX_PAGES : 1;
      var urls = [];
      for (var p = 1; p <= pages; p++) urls.push(chartUrl(code, p));
      detail.episodes = episodesOf(host, urls, loadFullPages);
      detail.status = detail.episodes.length + ' 首';
      return detail;
    },

    // 播放页把音频直链做 Base64 编码放在脚本里：
    //   新版 const encodedUrl = "Base64(直链)"；旧版（早期移植参考）let code = "Base64(直链)"
    // 解码（atob → UTF-8）后即为 mp3 地址
    audio: function (episodeUrl) {
      var page = String(episodeUrl).replace(/^higeq:song:/, '');
      if (page.indexOf('http') !== 0) throw new Error('不认识的章节地址，请刷新列表');
      var html = this.host.getString(page, options());
      var m = /(?:const\s+encodedUrl|let\s+code)\s*=\s*"([A-Za-z0-9+/=]+)"/.exec(html);
      if (!m) {
        // 兜底：遍历页面里所有较长的 Base64 串，解码后挑出以 http 开头的直链
        var found = html.match(/"([A-Za-z0-9+\/]{40,}={0,2})"/g) || [];
        for (var i = 0; i < found.length && !m; i++) {
          var cand = found[i].slice(1, -1);
          if (b64(cand).indexOf('http') === 0) m = [null, cand];
        }
      }
      var audio = m ? b64(m[1]) : '';
      if (audio.indexOf('http') !== 0) throw new Error('没有取到这一首的播放地址（页面结构可能已变化）');
      return { url: audio, headers: { Referer: SITE } };
    },

    audioHeaders: function () { return { Referer: SITE }; },
    coverHeaders: function (coverUrl) { return coverUrl && coverUrl.indexOf('higequ.com') >= 0 ? { Referer: SITE } : null; }
  });
})();
