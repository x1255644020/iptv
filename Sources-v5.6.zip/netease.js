// ============================================================================
// 网易云播客 + 网易云音乐 —— 独立源文件（一个 IIFE 里注册两个源）
// 来源：ShunSources v5.6 / api.js 第 1461-1763 行
// 依赖：仅宿主注入的全局函数 registerSource / str / int / items / at
//       以及 host.getJson / host.progress / host.sleep / host.toast
//       完全不依赖 common.js / Shun
// 导入：把本文件加入 manifest.json 的 scripts 即可（顺序不限）
// 注意：两个源共用一次登录（App 内网页登录留下的 Cookie）；
//       会员/已购内容需登录；接口有 406 限流，源码内已做等待重试；
//       网易云播客按 500 期一页惰性加载，歌单按 300 首一批取详情
// ============================================================================
// ---------- 网易云音乐 music.163.com：分成“网易云播客”和“网易云音乐”两个源 ----------
// 用的是网页版的接口。
// 播客：每个“播客 / 电台”是一本书，里面的节目是章节；节目的声音是一首“歌”，播放时用歌的编号去要地址。
// 音乐：歌单、专辑、排行榜各是一本书，里面的歌是章节；搜到的单曲是只有一集的书。登录后能看到自己的歌单。
// 登录状态就是在 App 内网页里登录后留下的 Cookie（和普通请求共用），两个源登录一次就都有了；会员或已购买的内容登录后才能听。
(function () {
  var SITE = 'https://music.163.com';
  var API = SITE + '/api';
  var PAGE = 30;
  // 播客的分类（网站“播客”页上的那些），有声书相关的排在前面
  var CATEGORIES = [['有声书', 10001], ['广播剧', 3088097], ['相声曲艺', 3088098], ['故事', 3080097], ['人文历史', 3080098], ['文学出版', 3148096],
    ['知识', 11], ['情感', 3], ['脱口秀', 8], ['亲子', 13], ['生活', 6], ['资讯', 3087096], ['娱乐', 3083097], ['二次元', 3001],
    ['音乐播客', 2], ['创作翻唱', 2001], ['明星专区', 14], ['其他', 3081098]];

  // body 不为空时用 POST 提交（表单格式）
  function api(host, path, body) {
    var o = { desktop: true, headers: { Referer: SITE + '/' } };
    if (body) { o.method = 'POST'; o.body = body; }
    var json = host.getJson(API + path, o);
    var code = int(json, 'code', 200);
    if (code === 301) throw new Error('需要登录网易云音乐：到插件页点这个源的“登录”');
    if (code !== 200) {
      var err = new Error('网易云音乐：' + (str(json, 'message') || str(json, 'msg') || '接口返回错误 ' + code));
      err.code = code;
      throw err;
    }
    return json;
  }

  // 请求太快时网站返回 406“操作频繁，请稍候再试”，十几秒后恢复：等一会儿再试，最多试几次
  function apiPatient(host, path) {
    for (var attempt = 0; ; attempt++) {
      try { return api(host, path); } catch (e) {
        if (e.code !== 406 || attempt >= 4) {
          if (e.code === 406) e.rateLimited = true;
          throw e;
        }
        for (var s = 20; s > 0; s--) {
          host.progress('（网易云限制了访问频率，' + s + ' 秒后继续）');
          host.sleep(1000);
        }
      }
    }
  }

  function bookUrl(id) { return SITE + '/djradio?id=' + id; }
  function radioId(url) { return (/[?&]id=(\d+)/.exec(String(url)) || [])[1] || ''; }
  // 封面地址后面加上尺寸，网站会给缩小过的图
  function cover(url) { return url ? String(url).replace(/^http:/, 'https:') + '?param=300y300' : ''; }
  function paid(radio) { return int(radio, 'radioFeeType') !== 0 || int(radio, 'price') > 0; }

  var LOGIN = {
    // 手机上先给手机版的登录页（手机号 / 扫码）；右上角可以换成电脑版网页
    loginUrl: SITE + '/m/login', loginDesktop: false, loginAltUrl: SITE + '/#/login',
    // 已登录时返回昵称
    checkLogin: function () {
      var name = str(api(this.host, '/nuser/account/get'), 'profile.nickname');
      if (!name) throw new Error('还没有登录网易云音乐');
      return name;
    }
  };

  // 用歌的编号去要播放地址。地址有时效，所以每次播放时现取
  function songAudio(host, song) {
    var data = at(api(host, '/song/enhance/player/url/v1?ids=' + encodeURIComponent('[' + song + ']') + '&level=standard&encodeType=mp3'), 'data.0') || {};
    var audio = str(data, 'url');
    if (!audio) {
      // 没给地址：一般是要会员、要购买，没有版权，或者没有登录
      throw new Error(int(data, 'fee') > 0 || int(data, 'code') === 404 ? '这一首需要会员或购买后才能听（登录自己的账号后再试）' : '网易云音乐没有给出播放地址（可能没有版权）');
    }
    // 会员歌曲没开会员时，网站只给一小段试听
    if (data.freeTrialInfo) host.toast('这首歌只能试听一小段（需要会员）');
    return { url: audio.replace(/^http:/, 'https:'), headers: { Referer: SITE + '/' } };
  }

  function toBook(radio) {
    var count = int(radio, 'programCount');
    return {
      bookUrl: bookUrl(str(radio, 'id')), title: str(radio, 'name').trim(), artist: str(radio, 'dj.nickname'),
      coverUrl: cover(str(radio, 'picUrl')), intro: str(radio, 'desc').trim(),
      status: [str(radio, 'category'), count > 0 ? count + ' 期' : '', paid(radio) ? '付费' : ''].filter(function (x) { return x.length > 0; }).join(' · ')
    };
  }

  registerSource({
    id: '9d3c7a15e8b24f60a1c5d79e3b04f862', name: '网易云播客', url: SITE + '/',
    description: '网易云音乐的播客：有声书、广播剧、相声曲艺、故事、人文历史等。免费的节目不用登录；会员或购买过的内容，在插件页“登录”自己的账号后可以听。',
    multipleEpisodePages: true,
    loginUrl: LOGIN.loginUrl, loginDesktop: LOGIN.loginDesktop, loginAltUrl: LOGIN.loginAltUrl, checkLogin: LOGIN.checkLogin,

    categoryMenus: function () {
      return [{ title: '播客', tabs: [{ title: '热门', url: 'netease:hot' }].concat(CATEGORIES.map(function (c) { return { title: c[0], url: 'netease:cate:' + c[1] }; })) }];
    },

    categoryPage: function (url) {
      var parts = String(url).split('#'), page = parseInt(parts[1] || '1', 10) || 1, key = parts[0];
      var offset = (page - 1) * PAGE;
      var m = /^netease:cate:(\d+)$/.exec(key);
      var json = m ? api(this.host, '/djradio/hot?cateId=' + m[1] + '&limit=' + PAGE + '&offset=' + offset)
        : api(this.host, '/djradio/hot/v1?limit=' + PAGE + '&offset=' + offset);
      var books = items(json, 'djRadios').map(toBook);
      var more = json.hasMore === true && books.length > 0;
      return { books: books, currentPage: page, totalPage: more ? page + 1 : page, nextUrl: more ? key + '#' + (page + 1) : null };
    },

    search: function (keywords, page) {
      var json = api(this.host, '/search/get?s=' + encodeURIComponent(keywords) + '&type=1009&limit=' + PAGE + '&offset=' + (page - 1) * PAGE);
      var books = items(json, 'result.djRadios').map(toBook);
      var total = Math.ceil(int(json, 'result.djRadiosCount') / PAGE);
      return { books: books, totalPage: books.length === 0 ? page : Math.max(page, total) };
    },

    bookDetail: function (url, loadEpisodes, loadFullPages) {
      var host = this.host, id = radioId(url);
      var radio = at(api(host, '/djradio/get?id=' + id), 'djRadio') || {};
      var detail = {
        title: str(radio, 'name').trim(), artist: str(radio, 'dj.nickname'), intro: str(radio, 'desc').trim(),
        coverUrl: cover(str(radio, 'picUrl')), episodes: []
      };
      if (!loadEpisodes) return detail;
      // 节目按期数从前往后排，一页最多 500 期。网站限制访问频率：连着取五六次后要等十几秒才能再取（歇得再久也差不多），每页之间歇一下，被限制了就等一会儿接着取
      var size = 500;
      try {
        for (var offset = 0; offset < 50000; offset += size) {
          if (offset > 0) {
            host.progress(Math.min(offset + size, int(radio, 'programCount')) + ' / ' + int(radio, 'programCount'));
            host.sleep(2000);
          }
          var json = apiPatient(host, '/dj/program/byradio?radioId=' + id + '&limit=' + size + '&offset=' + offset + '&asc=true');
          var list = items(json, 'programs');
          list.forEach(function (p) {
            var song = str(p, 'mainSong.id') || str(p, 'mainTrackId');
            if (!song) return;
            detail.episodes.push({
              title: str(p, 'name').trim(), url: SITE + '/program?id=' + str(p, 'id') + '&song=' + song,
              // 收费的节目没买过就标成付费（能不能听以登录后的账号为准）
              isFree: int(p, 'programFeeType') === 0 || p.buyed === true
            });
          });
          if (!loadFullPages || json.more !== true || list.length === 0) break;
        }
      } catch (e) {
        // 一直被限制：先用已经取到的部分，下次打开这本书时会重新加载
        if (!e.rateLimited || detail.episodes.length === 0) throw e;
        host.toast('网易云限制了访问频率，先加载了 ' + detail.episodes.length + ' 期，过一会儿重新打开这本书可以加载全部');
      } finally {
        host.progress(null);
      }
      var count = int(radio, 'programCount');
      detail.status = [radio.finished === true ? '完结' : '', count > 0 ? count + ' 期' : '', paid(radio) ? '付费' : ''].filter(function (x) { return x.length > 0; }).join(' · ');
      return detail;
    },

    // 节目的声音是一首“歌”，用它的编号去要播放地址
    audio: function (url) {
      var song = (/[?&]song=(\d+)/.exec(String(url)) || [])[1];
      if (!song) throw new Error('不认识的章节地址：' + url);
      return songAudio(this.host, song);
    }
  });

  // ================= 音乐 =================
  var STYLES = ['华语', '流行', '摇滚', '民谣', '电子', '说唱', '轻音乐', '古风', '怀旧', '影视原声', 'ACG', '粤语', '欧美', '日语', '韩语', '古典', '爵士', '儿童'];
  var BATCH = 300; // 一次问多少首歌的信息

  function idOf(url) { return (/[?&]id=(\d+)/.exec(String(url)) || [])[1] || ''; }
  function names(list) { return (list || []).map(function (a) { return str(a, 'name'); }).filter(function (n) { return n.length > 0; }).join(' / '); }
  // fee：0 免费，8 免费（高音质要会员），1 会员才能听，4 要买专辑
  function songFree(fee) { return fee !== 1 && fee !== 4; }

  // 歌曲的两种写法都认：新接口是 ar / al，搜索接口是 artists / album
  function songEpisode(song, fee) {
    var who = names(song.ar || song.artists);
    return {
      title: str(song, 'name').trim() + (who ? ' - ' + who : ''), url: SITE + '/song?id=' + str(song, 'id'),
      isFree: songFree(fee === undefined ? int(song, 'fee') : fee)
    };
  }

  function playlistBook(p) {
    var count = int(p, 'trackCount');
    return {
      bookUrl: SITE + '/playlist?id=' + str(p, 'id'), title: str(p, 'name').trim(), artist: str(p, 'creator.nickname'),
      coverUrl: cover(str(p, 'coverImgUrl') || str(p, 'picUrl')), intro: (str(p, 'description') || str(p, 'copywriter')).trim(),
      status: [count > 0 ? count + ' 首' : '', str(p, 'updateFrequency')].filter(function (x) { return x.length > 0; }).join(' · ') || '歌单'
    };
  }

  // 按编号问一批歌的信息（歌名、歌手、是否收费）
  function songsByIds(host, ids) {
    var json = api(host, '/v3/song/detail', 'c=' + encodeURIComponent(JSON.stringify(ids.map(function (id) { return { id: id }; }))));
    var fees = {};
    items(json, 'privileges').forEach(function (p) { fees[str(p, 'id')] = int(p, 'fee'); });
    var byId = {};
    items(json, 'songs').forEach(function (song) { byId[str(song, 'id')] = song; });
    // 按歌单里的顺序排
    return ids.map(function (id) { return byId[String(id)]; }).filter(function (song) { return !!song; })
      .map(function (song) { return { song: song, fee: fees[str(song, 'id')] }; });
  }

  registerSource({
    id: '2f8b6d4a0c9e43f7b15a8e6d3c7f0a94', name: '网易云音乐', url: SITE + '/',
    description: '网易云音乐的歌单、排行榜和单曲。歌单、专辑是一本“书”，里面的歌是章节。在插件页“登录”自己的账号后，发现页的“我的歌单”里能看到自己创建和收藏的歌单；会员歌曲没开会员时只能试听一小段。',
    group: '音乐',
    multipleEpisodePages: true,
    loginUrl: LOGIN.loginUrl, loginDesktop: LOGIN.loginDesktop, loginAltUrl: LOGIN.loginAltUrl, checkLogin: LOGIN.checkLogin,

    categoryMenus: function () {
      return [
        { title: '推荐', tabs: [{ title: '推荐歌单', url: 'ncm:recommend' }, { title: '我的歌单', url: 'ncm:mine' }, { title: '排行榜', url: 'ncm:top' }] },
        { title: '歌单', tabs: [{ title: '全部', url: 'ncm:cat:全部' }].concat(STYLES.map(function (n) { return { title: n, url: 'ncm:cat:' + n }; })) }
      ];
    },

    categoryPage: function (url) {
      var host = this.host;
      var parts = String(url).split('#'), page = parseInt(parts[1] || '1', 10) || 1, key = parts[0];
      function one(list) { return { books: list.map(playlistBook), currentPage: 1, totalPage: 1 }; }
      if (key === 'ncm:mine') {
        var uid = str(api(host, '/nuser/account/get'), 'account.id');
        if (!uid) throw new Error('还没有登录网易云音乐：到“插件”页点开这个源，点“登录”');
        // 自己创建的在前（第一个是“我喜欢的音乐”），后面是收藏的
        return one(items(api(host, '/user/playlist?uid=' + uid + '&limit=300&offset=0'), 'playlist'));
      }
      if (key === 'ncm:recommend') return one(items(api(host, '/personalized/playlist?limit=30'), 'result'));
      if (key === 'ncm:top') return one(items(api(host, '/toplist'), 'list'));
      var cat = key.replace(/^ncm:cat:/, '');
      var json = api(host, '/playlist/list?cat=' + encodeURIComponent(cat) + '&order=hot&limit=' + PAGE + '&offset=' + (page - 1) * PAGE);
      var books = items(json, 'playlists').map(playlistBook);
      var more = json.more === true && books.length > 0;
      return { books: books, currentPage: page, totalPage: more ? page + 1 : page, nextUrl: more ? key + '#' + (page + 1) : null };
    },

    // 搜出来的主要是单曲（每首是只有一集的“书”）；第一页后面再跟几张专辑和几个歌单
    search: function (keywords, page) {
      var host = this.host, q = encodeURIComponent(keywords);
      var json = api(host, '/search/get?s=' + q + '&type=1&limit=' + PAGE + '&offset=' + (page - 1) * PAGE);
      var books = items(json, 'result.songs').map(function (song) {
        return {
          bookUrl: SITE + '/song?id=' + str(song, 'id'), title: str(song, 'name').trim(), artist: names(song.artists),
          coverUrl: cover(str(song, 'album.picUrl')), status: ['单曲', str(song, 'album.name')].filter(function (x) { return x.length > 0; }).join(' · ')
        };
      });
      var total = Math.max(page, Math.ceil(int(json, 'result.songCount') / PAGE));
      if (page === 1) {
        try {
          items(api(host, '/search/get?s=' + q + '&type=10&limit=5&offset=0'), 'result.albums').forEach(function (al) {
            books.push({
              bookUrl: SITE + '/album?id=' + str(al, 'id'), title: str(al, 'name').trim(), artist: str(al, 'artist.name'),
              coverUrl: cover(str(al, 'picUrl') || str(al, 'blurPicUrl')), status: '专辑' + (int(al, 'size') > 0 ? ' · ' + int(al, 'size') + ' 首' : '')
            });
          });
          items(api(host, '/search/get?s=' + q + '&type=1000&limit=8&offset=0'), 'result.playlists').forEach(function (p) { books.push(playlistBook(p)); });
        } catch (e) { if (e.cancelled) throw e; }
      }
      return { books: books, totalPage: books.length === 0 ? page : total };
    },

    bookDetail: function (url, loadEpisodes, loadFullPages) {
      var host = this.host, id = idOf(url), detail = { episodes: [] };
      if (/\/song\?/.test(url)) {
        // 单曲：只有它自己这一集
        var one = songsByIds(host, [id])[0];
        if (!one) throw new Error('没有找到这首歌');
        detail.title = str(one.song, 'name').trim(); detail.artist = names(one.song.ar);
        detail.coverUrl = cover(str(one.song, 'al.picUrl')); detail.status = ['单曲', str(one.song, 'al.name')].filter(function (x) { return x.length > 0; }).join(' · ');
        detail.episodes.push(songEpisode(one.song, one.fee));
        return detail;
      }
      if (/\/album\?/.test(url)) {
        var album = api(host, '/v1/album/' + id);
        detail.title = str(album, 'album.name').trim(); detail.artist = str(album, 'album.artist.name');
        detail.coverUrl = cover(str(album, 'album.picUrl')); detail.intro = str(album, 'album.description').trim();
        items(album, 'songs').forEach(function (song) { detail.episodes.push(songEpisode(song)); });
        detail.status = '专辑 · ' + detail.episodes.length + ' 首';
        return detail;
      }
      // 歌单：详情里只带着前几首歌的信息，但有全部歌的编号，按编号一批批去问
      var list = at(api(host, '/v6/playlist/detail?id=' + id + '&n=1000'), 'playlist') || {};
      detail.title = str(list, 'name').trim(); detail.artist = str(list, 'creator.nickname');
      detail.coverUrl = cover(str(list, 'coverImgUrl')); detail.intro = str(list, 'description').trim();
      var ids = items(list, 'trackIds').map(function (t) { return str(t, 'id'); }).filter(function (x) { return x.length > 0; });
      detail.status = ids.length + ' 首';
      if (!loadEpisodes) return detail;
      try {
        for (var i = 0; i < ids.length; i += BATCH) {
          if (i > 0) host.progress(Math.min(i + BATCH, ids.length) + ' / ' + ids.length);
          songsByIds(host, ids.slice(i, i + BATCH)).forEach(function (x) { detail.episodes.push(songEpisode(x.song, x.fee)); });
          if (!loadFullPages) break;
        }
      } finally {
        host.progress(null);
      }
      return detail;
    },

    audio: function (url) {
      var song = idOf(url);
      if (!song) throw new Error('不认识的章节地址：' + url);
      return songAudio(this.host, song);
    }
  });
})();
