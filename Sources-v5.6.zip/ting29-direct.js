// 29听书网（www.ting29.com）独立源 v2 · 固化型源骨架（ES5 / Rhino，自包含）
// v2 改动：① 目录翻页改并发批拉（每批5页 host.getStrings）解决"只有50集+慢"；
//          ② 429 限流等待 60s→30s、上限 3 轮；③ dirurl 选择器加正则兜底；④ audio() 修掉重复 getDir。
// 探测实测：搜索表单 POST searchword、书页 230 行 a.dirurl 藏 /bookdir/{混淆}/?page=N&sort=asc、
// 目录 #playlist 每页 50 集、播放页 jPlayer 混淆脚本只能嗅探、Cloudflare + pt_guid 令牌 + 移动端跳 m.
(function () {
  var SITE = 'https://www.ting29.com/';
  var COOKIE = 'pt_guid';
  var PAGE_SIZE = 50;
  var PARALLEL = 8;

  function enc(s) { return encodeURIComponent(s); }
  var none = {
    exists: function () { return false; }, text: function () { return ''; },
    ownText: function () { return ''; }, attr: function () { return ''; },
    absUrl: function () { return ''; }, first: function () { return none; },
    select: function () { return []; }
  };
  function nth(list, n) { return list && n < list.length ? list[n] : none; }
  function regexInt(s, re, dflt) { var m = re.exec(s || ''); return m ? parseInt(m[1], 10) : dflt; }

  function retry403(fn) {
    try { return fn(); } catch (e) {
      if (e.status !== 403) throw e;
      return fn();
    }
  }

  var dirToken = null, dirTokenExpires = 0;

  // reversed="base64(倒序)" → 解码 var token='...'，token 再 base64("IP|ID|过期|签名")
  function readToken(host, html) {
    var m = /reversed = "([^"]+)"/.exec(html);
    if (!m) return null;
    var code;
    try { code = host.base64Decode(m[1].split('').reverse().join('')); } catch (e) { return null; }
    var t = /var token = '([^']+)'/i.exec(code);
    if (!t) return null;
    var parts;
    try { parts = host.base64Decode(t[1]).split('|'); } catch (e) { parts = []; }
    var expires = parts.length > 2 ? parseInt(parts[2], 10) : NaN;
    return { token: t[1], expires: isNaN(expires) ? Date.now() / 1000 + 3600 : expires };
  }

  function curToken(host) {
    var t = Date.now() / 1000 < dirTokenExpires ? dirToken : null;
    return t ? { Cookie: COOKIE + '=' + enc(t) } : {};
  }

  function getDoc(host, url, referer) {
    return retry403(function () { return host.getHtml(url, { desktop: true, headers: referer ? { Referer: referer } : {} }); });
  }

  // 单页目录：reversed 令牌 + 429 限流(30s×3) + WebView 兜底
  function fetchDirPage(host, url) {
    for (var attempt = 0, limited = 0; attempt < 3; attempt++) {
      var html;
      try {
        html = retry403(function () { return host.getString(url, { desktop: true, headers: curToken(host) }); });
      } catch (e) {
        if (e.status !== 429) throw e;
        if (limited >= 3) throw new Error('29听书网限流过久');
        limited++;
        for (var s = 15; s > 0; s--) { host.progress('（限流，' + s + ' 秒后继续）'); host.sleep(1000); }
        attempt--; continue;
      }
      if (html.indexOf('reversed = "') < 0) return html;
      var t = readToken(host, html);
      if (!t) return html;
      dirToken = t.token; dirTokenExpires = t.expires - 300;
      // 拿到新令牌：本页立即带令牌重取（一次）
      html = retry403(function () { return host.getString(url, { desktop: true, headers: curToken(host) }); });
      if (html.indexOf('reversed = "') < 0) return html;
    }
    return null;
  }

  function getDir(host, url) {
    var html = fetchDirPage(host, url);
    if (html) return host.parseHtml(html, url);
    var rendered = host.render(url, { desktop: true, script: "(function(){return document.querySelector('#playlist li a')?document.documentElement.outerHTML:'';})();"});
    return host.parseHtml(rendered, url);
  }

  function parseBooks(doc) {
    var books = [];
    doc.select('ul.list-works > li').forEach(function (li) {
      var a = li.first('dt.list-book-dt > a');
      if (!a.exists()) return;
      var img = li.first('.list-imgbox img');
      var state = li.first('dt.list-book-dt > span').text();
      var latest = li.first('dt.list-book-dt > span > a').text();
      books.push({
        coverUrl: img.absUrl('data-original') || img.absUrl('src'),
        bookUrl: a.absUrl('href'),
        title: a.text(),
        author: '',
        artist: li.select('.book-author a').map(function (e) { return e.text(); }).join(' '),
        intro: li.first('dd.list-book-des').text(),
        status: [state, latest].filter(function (x) { return x.length > 0; }).join(' · ')
      });
    });
    return books;
  }

  function addEpisodes(doc, list) {
    doc.select('#playlist li a').forEach(function (a) {
      list.push({ title: a.text().replace(/[_\s]*催更.*$/, ''), url: a.absUrl('href') });
    });
  }

  function findDirUrl(doc, fallback) {
    var u = doc.first('a.dirurl').absUrl('href');
    if (u.length > 0) return u;
    doc.select('a').forEach(function (a) {
      var href = a.absUrl('href');
      if (/^https?:\/\/[^\/]+\/bookdir\/[a-zA-Z0-9]+\/[a-zA-Z0-9]+\.html/.test(href)) { u = href; }
    });
    return u || fallback;
  }

  function load(host, bookUrl, known, loadEpisodes, loadFullPages) {
    var list = [];
    var doc1 = getDoc(host, bookUrl, SITE);
    var artist = [];
    doc1.select('.book-info dd').forEach(function (d) {
      if (artist.length === 0 && d.text().indexOf('演播') === 0) artist = d.select('a').map(function (e) { return e.text(); });
    });
    var detail = {
      episodes: list,
      intro: doc1.first('.book-des').text(),
      coverUrl: doc1.first('.book-info').parent().first('img').absUrl('data-original'),
      artist: artist.join(' ')
    };
    if (!loadEpisodes) return detail;

    if (known && known.length > 0) {
      var latest = [];
      addEpisodes(doc1, latest); latest.reverse();
      var urls = {}; known.forEach(function (e) { urls[e.url] = true; });
      if (latest.length > 0 && urls[nth(latest, 0).url]) {
        known.forEach(function (e) { list.push(e); });
        latest.forEach(function (e) { if (!urls[e.url]) list.push(e); });
        return detail;
      }
    }

    var dirUrl = findDirUrl(doc1, '');
    var doc = dirUrl.length > 0 ? getDir(host, dirUrl) : doc1;
    var seen = {}, pages = [];
    doc.select('a').forEach(function (a) {
      var u = a.absUrl('href'); var p = regexInt(u, /[?&]page=(\d+)/, 0);
      if (p > 1 && !seen[p]) { seen[p] = true; pages.push({ url: u, page: p }); }
    });
    pages.sort(function (a, b) { return a.page - b.page; });

    var startPage = 1;
    if (known && known.length > PAGE_SIZE && pages.length > 0) {
      startPage = Math.min(Math.floor(known.length / PAGE_SIZE), pages.length) + 1;
      known.slice(0, (startPage - 1) * PAGE_SIZE).forEach(function (e) { list.push(e); });
    }
    if (startPage === 1) addEpisodes(doc, list);
    if (!loadFullPages) return detail;

    try {
      var total = pages.length + 1;
      for (var page = Math.max(2, startPage); page <= total; page += PARALLEL) {
        var batch = pages.slice(page - 2, page - 2 + PARALLEL);
        host.progress(Math.min(page + batch.length - 1, total) + ' / ' + total);
        var texts = host.getStrings(batch.map(function (b) { return b.url; }),
          { desktop: true, headers: curToken(host) }, PARALLEL);
        batch.forEach(function (b, k) {
          var ok = texts[k] !== null && texts[k] !== undefined && texts[k].indexOf('reversed = "') < 0;
          addEpisodes(ok ? host.parseHtml(texts[k], b.url) : getDir(host, b.url), list);
        });
      }
    } catch (e) {
      host.toast('29听书网限流，先加载了 ' + list.length + ' 集，下次打开会接着加载');
    } finally { host.progress(null); }
    return detail;
  }

  registerSource({
    id: 'b7c1f0a95e3d4862aa1f9e0c7d2b8451',
    name: '29听书网(直连)',
    url: SITE,
    group: '小说类',
    description: '有声小说、长篇评书、相声曲艺、儿童、国学等，分类细、更新快。独立直连版：搜索/分类/目录/播放全自动，目录并发批拉（每批5页）。章节很多时首次加载要一点时间。',
    multipleEpisodePages: true,
    loginUrl: SITE + 'user/public/login.html',
    loginDesktop: false,

    search: function (keywords, page) {
      var host = this.host;
      var doc = page > 1
        ? getDoc(host, SITE + 'search.html?searchtype=name&searchword=' + enc(keywords) + '&page=' + page, SITE + 'search.html')
        : retry403(function () {
            return host.getHtml(SITE + 'search.html', { desktop: true, method: 'POST', body: 'searchword=' + enc(keywords), headers: { Referer: SITE, Origin: SITE.replace(/\/$/, '') } });
          });
      var books = parseBooks(doc);
      var more = doc.select('a').some(function (a) { return a.text() === '下一页' || a.text() === '下页'; });
      return { books: books, totalPage: more && books.length > 0 ? page + 1 : page };
    },

    categoryMenus: function () {
      function tabs(list) { return list.map(function (p) { return { title: p[0], url: SITE + 'book/' + p[1] + '/lastupdate.html' }; }); }
      return [
        { title: '有声小说', tabs: tabs([['全部', 'all'], ['玄幻奇幻', 'xhqh'], ['武侠仙侠', 'wxxx'], ['穿越架空', 'cyjk'], ['悬疑推理', 'xytl'], ['科幻竞技', 'khjj'],
          ['历史军事', 'lsjs'], ['现代言情', 'xdyq'], ['古代言情', 'gdyq'], ['幻想言情', 'hxyq'], ['青春校园', 'qcxy'], ['影视原著', 'ysyz'], ['文学名著', 'wxmz'], ['乡村生活', 'xcsh']]) },
        { title: '评书人文', tabs: tabs([['长篇评书', 'pingshu'], ['相声曲艺', 'xsqy'], ['国学经典', 'gxjd'], ['名家传记', 'mjcj'], ['档案纪实', 'dajs'], ['博闻杂谈', 'bxzt'],
          ['儿童频道', 'ertong'], ['职场干货', 'zcgh'], ['自我提升', 'zwts'], ['明星电台', 'mxdt'], ['其他有声', 'qita']]) }
      ];
    },

    categoryPage: function (url) {
      var doc = getDoc(this.host, url, SITE);
      var current = regexInt(url, /\/(\d+)\.html$/);
      var total = current;
      doc.select('a').forEach(function (a) { total = Math.max(total, regexInt(a.absUrl('href'), /\/(\d+)\.html$/)); });
      return { books: parseBooks(doc), currentPage: current, totalPage: total, nextUrl: '' };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) { return load(this.host, bookUrl, null, loadEpisodes, loadFullPages); },
    updateEpisodes: function (bookUrl, known) { return load(this.host, bookUrl, known, true, true); },

    audio: function (url) {
      var host = this.host;
      try {
        var html = host.getString(url, { desktop: true, headers: { Referer: url } });
        var m = /iframe[^>]+src=["']([^"']*player\.html[^"']*)/i.exec(html) || /src=["']([^"']*player\.html[^"']*)/i.exec(html);
        if (m) {
          var player = m[1];
          if (player.indexOf('http') !== 0) player = url.replace(/\/tingshu\/.*/, '') + player;
          var ph = host.getString(player, { desktop: true, headers: { Referer: url } });
          var am = /(?:mp3|m4a|oga|wav)\s*:\s*'([^']*)'\s*\+\s*(\w+)/i.exec(ph);
          if (am) {
            var tail = new RegExp(am[2] + "\\s*=\\s*'([^']*)'").exec(ph);
            var audio = am[1] + (tail ? tail[1] : '');
            if (/^https?:\/\//.test(audio)) return audio;
          }
        }
      } catch (e) { if (e.cancelled) throw e; }
      return host.sniff(url, { desktop: true });
    }
  });
})();