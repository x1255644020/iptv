// ---------- 念音网、有听网：同一套网站程序（?s=ting-search-wd-… 搜索，音频存放在 guoguo.org.cn） ----------
function guoguoSource(def) {
  var site = def.site;
  // 站点关停/换域名后，书架、历史里保存的旧链接仍指向旧域名；请求前统一重写到当前站点，
  // 避免点开旧收藏时再次抛「HTTP 404」。def.legacy 为旧域名前缀列表。
  var legacy = def.legacy || [];
  // 首页临时打不开时的静态分类兜底，保证 categoryMenus 不会把整个源带崩。
  var fallbackTabs = def.fallbackTabs || null;

  function norm(url) {
    var u = String(url || '');
    for (var i = 0; i < legacy.length; i++) {
      if (u.indexOf(legacy[i]) === 0) return site + u.substring(legacy[i].length);
    }
    return u;
  }

  function get(host, url) { return Shun.getDoc(host, norm(url), true, site); }

  function parseBooks(doc, withStatus) {
    var books = [];
    doc.select('.category-list > ul li').forEach(function (li) {
      var a = li.first('.info > h4 > a');
      if (!a.exists()) return;
      var p = li.first('.info').select('p');
      books.push({
        coverUrl: li.first('.img > a > img').absUrl('src'), bookUrl: a.absUrl('href'), title: a.text(),
        author: Shun.stripLabel(Shun.nth(p, 1).text()), artist: Shun.stripLabel(Shun.nth(p, 2).text()),
        status: withStatus ? Shun.stripLabel(Shun.nth(p, 3).text()) : ''
      });
    });
    return books;
  }

  return registerSource({
    id: def.id, name: def.name, url: site, description: def.description,
    coverHeaders: Shun.coverReferer('guoguo.org', site),

    search: function (keywords, page) {
      var doc = get(this.host, site + '?s=ting-search-wd-' + Shun.enc(keywords) + '-p-' + page + '.html');
      var pager = doc.first('.category-list > .c-page');
      var current = regexInt(pager.first('.current').text(), /(\d+)/);
      var last = Shun.findByText(pager, 'a', '尾页');
      return { books: parseBooks(doc, false), totalPage: regexInt(last.absUrl('href'), /p-(\d+)\.html/, current) };
    },

    categoryMenus: function () {
      var tabs = [];
      try {
        tabs = Shun.getDoc(this.host, site, true).first('.nav').select('a')
          .filter(function (a) { return a.text() !== '首页'; })
          .map(function (a) { return { title: a.text(), url: a.absUrl('href') }; });
      } catch (e) { if (e.cancelled) throw e; }
      // 首页 404 / 改版取不到导航时，退回静态分类，避免「加载分类失败」
      if (!tabs.length && fallbackTabs) {
        tabs = fallbackTabs.map(function (t) { return { title: t[0], url: site + t[1] }; });
      }
      return [{ title: '分类', tabs: tabs }];
    },

    categoryPage: function (url) {
      var doc = get(this.host, url);
      var pager = doc.first('.category-list > .c-page');
      var current = regexInt(pager.first('.current').text(), /(\d+)/);
      var total = regexInt(Shun.findByText(pager, 'a', '尾页').absUrl('href'), /index(\d+)\.html/, current);
      return {
        books: parseBooks(doc, true), currentPage: current, totalPage: Math.max(total, current),
        nextUrl: Shun.findByText(pager, 'a', '下一页').absUrl('href')
      };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var doc = get(this.host, bookUrl);
      var episodes = loadEpisodes
        ? doc.select('.plist > ul li a').map(function (a) { return { title: a.text(), url: a.absUrl('href') }; })
        : [];
      return { episodes: episodes, intro: doc.first('.intro > p').text() };
    },

    // 播放：站点播放页由脚本 POST /?s=api-getneoplay 拿音频地址，再交给 jPlayer 渲染。
    // 优先直接用同步接口取直链（快、且不依赖 WebView 执行脚本 / 不被页面跳转干扰）；
    // 取不到时回退到原来的 WebView 渲染方案。
    audio: function (url) {
      var host = this.host, playUrl = norm(url);
      try {
        var html = host.getString(playUrl, { desktop: true, headers: { Referer: site } }) || '';
        var b = /<meta\s+name="_b"\s+content="([^"]*)"/i.exec(html);
        var cp = /<meta\s+name="_cp"\s+content="([^"]*)"/i.exec(html);
        var p = /<meta\s+name="_p"\s+content="([^"]*)"/i.exec(html);
        if (b && cp) {
          var body = 'bookId=' + encodeURIComponent(b[1]) +
            '&isPay=' + encodeURIComponent(p ? p[1] : '0') +
            '&page=' + encodeURIComponent(cp[1]);
          var txt = host.getString(site + '?s=api-getneoplay', {
            desktop: true, method: 'POST',
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            body: body,
            headers: {
              Referer: playUrl,
              Origin: site.replace(/\/$/, ''),
              'X-Requested-With': 'XMLHttpRequest'
            }
          });
          // 接口返回带 UTF-8 BOM，部分宿主的 parseJson 不容错：先去 BOM，解析失败再用正则兜底
          var raw = txt ? String(txt).replace(/^\uFEFF/, '').trim() : '';
          var j = null;
          try { j = raw ? parseJson(raw) : null; } catch (e2) { }
          var audioUrl = j ? (j.ourl || j.url || '') : '';
          if (!audioUrl && raw) {
            var um = /"(?:ourl|url)"\s*:\s*"((?:[^"\\]|\\.)*)"/.exec(raw);
            if (um) audioUrl = Shun.unescape(um[1]);
          }
          if (audioUrl && /^https?:\/\//.test(audioUrl)) {
            return { url: audioUrl, headers: audioUrl.indexOf('guoguo') >= 0 ? { Referer: site } : null };
          }
        }
      } catch (e) { if (e.cancelled) throw e; }
      // 回退：播放页脚本执行后读取 jPlayer 的 audio 元素
      return host.render(playUrl, {
        desktop: true,
        parse: function (rendered) {
          var src = host.parseHtml(rendered, site).first('#jp_audio_0').absUrl('src');
          return src.replace('https://cloud.guoguo.org.cn/nyts.php?uid=', 'https://oss-links.guoguo.org.cn/uploads/');
        }
      });
    },

    audioHeaders: function (audioUrl) { return audioUrl.indexOf('guoguo') >= 0 ? { Referer: site } : null; }
  });
}

// 两个站是同一套网站程序，静态分类完全一致，供首页取不到导航时兜底
var GUOGUO_TABS = [
  ['武侠玄幻', 'wuxiaxuanhuan/'], ['恐怖灵异', 'kongbulingyi/'], ['推理悬疑', 'tuilixuanyi/'],
  ['都市言情', 'dushiyanqing/'], ['家庭伦理', 'jiatinglunli/'], ['官场职场', 'wenxuemingzhu/'],
  ['经典评书', 'jingdianpingshu/'], ['曲艺戏曲', 'quyixiqu/'], ['相声小品', 'xiangshengxiaopin/'],
  ['助眠音频', 'yinyue/']
];

// 念音网原域名 www.nianyin.com 已整站 404（服务器在、网站内容已清空），且未找到新地址。
// 同一套程序的有听网 ting15.com 仍正常（导航/分类/翻页/播放结构完全一致），故接入该站；
// 书架、历史里保存的旧 nianyin.com 链接会自动重写到新站点，避免再次 404。
guoguoSource({
  id: 'd87f1316fa2e41a299074e2b0c086a17', name: '念音网', site: 'https://www.ting15.com/',
  legacy: [
    'https://www.nianyin.com/', 'http://www.nianyin.com/',
    'https://nianyin.com/', 'http://nianyin.com/'
  ],
  fallbackTabs: GUOGUO_TABS,
  description: '推荐指数:3星 ⭐⭐⭐\n原域名 www.nianyin.com 已关停（整站 404），现接入同一套网站程序的有听网 ting15.com，分类/搜索/播放均可用。\n注意：原站的 DJ 串烧内容已随站点消失；书架里的旧链接会自动跳转到新站点。\n不是所有都能听，有的可能要会员。'
});
guoguoSource({
  id: 'c3c5bdc9145c4200a38e9a3558861e98', name: '有听网', site: 'https://www.ting15.com/',
  fallbackTabs: GUOGUO_TABS,
  description: '推荐指数:4星 ⭐⭐⭐⭐\n不是所有都能听，有的可能要会员。'
});

// ---------- 乐听吧、米听书、囧贼听书网：同一套网站程序（.row3.row-b 列表 + .pagebar 分页，播放页 var now） ----------
function pageBarSource(def) {
  var site = def.site;

  function parseBooks(items) {
    var books = [];
    items.forEach(function (li) {
      var a = li.first('.style-img.clearfix > section > h2 > a');
      if (!a.exists()) return;
      books.push({
        coverUrl: li.first('.style-img.clearfix > .img-80.fl.mr15 > span > img').absUrl('src'),
        bookUrl: a.absUrl('href'), title: a.text(),
        author: li.first('.style-img.clearfix > section > h2 > span').text(),
        intro: li.first('.style-img.clearfix > section > .f-gray.mb10.f-12').text()
      });
    });
    return books;
  }

  var source = {
    id: def.id, name: def.name, url: site, description: def.description,
    coverHeaders: Shun.coverReferer(Shun.hostOf(site), site),

    // 搜索需要人机验证时，搜索页会显示“验证”按钮
    searchVerificationUrl: function (keywords) { return site + 'search.php?searchword=' + Shun.enc(keywords); },
    searchVerificationDesktop: true,
    searchDelaySeconds: 6, // 网站限制两次搜索的间隔

    // A positive result from the visible page avoids submitting a second rate-limited search.
    searchVerificationResult: function (html, url, keywords) {
      if (url.indexOf(site) !== 0) return null;
      var doc = this.host.parseHtml(html, url);
      var books = parseBooks(doc.first('.row3.row-b').select('li'));
      if (!books.length) return null;
      var last = Shun.findByText(doc.first('.pagebar.ta-c.mb15 > span'), 'a', '尾页');
      return { verified: true, books: books, totalPage: regexInt(last.absUrl('href'), /page=(\d+)/, 1) };
    },

    search: function (keywords, page) {
      var doc = Shun.getDoc(this.host, site + 'search.php?page=' + page + '&searchword=' + Shun.enc(keywords) + '&searchtype=', true);
      var last = Shun.findByText(doc.first('.pagebar.ta-c.mb15 > span'), 'a', '尾页');
      return { books: parseBooks(doc.first('.row3.row-b').select('li')), totalPage: regexInt(last.absUrl('href'), /page=(\d+)/, page) };
    },

    categoryMenus: function () {
      var tabs = Shun.getDoc(this.host, site, true).select('.nav.mb10 > ul li > a')
        .filter(function (a) { return a.text() !== '首页'; })
        .map(function (a) { return { title: a.text(), url: a.absUrl('href') }; });
      return [{ title: '分类', tabs: tabs }];
    },

    categoryPage: function (url) {
      var doc = Shun.getDoc(this.host, url, true);
      var bar = doc.first('.pagebar.ta-c.mb15 > span');
      var current = regexInt(bar.first('.page.now-page').text(), /(\d+)/);
      var total = regexInt(Shun.findByText(bar, 'a', '尾页').absUrl('href'), /-(\d+)/, current);
      return {
        books: parseBooks(doc.select('.row3.row-b > li')), currentPage: current, totalPage: Math.max(total, current),
        nextUrl: Shun.findByText(bar, 'a', '››').absUrl('href')
      };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var doc = Shun.getDoc(this.host, bookUrl, true);
      var episodes = loadEpisodes
        ? doc.select('.ul-36.clearfix li a').map(function (a) { return { title: a.text(), url: a.absUrl('href') }; })
        : [];
      return { episodes: episodes, intro: Shun.nth(doc.first('.style-img.clearfix.pd10 > section').select('p'), 4).text() };
    },

    audio: function (url) { return Shun.varNowAudio(this.host, url, true); }
  };
  if (def.categoryMenus) source.categoryMenus = def.categoryMenus;
  return registerSource(source);
}

pageBarSource({
  id: 'f04408546017411c890d4d72325a67ec', name: '乐听吧', site: 'https://www.leting8.com/',
  description: '推荐指数:3星 ⭐⭐⭐\n搜索可能需要验证：在搜索页点击该源旁的“验证”，输入验证码后返回即可。'
});

pageBarSource({
  id: '63a4f98615394edea416ba5fd15b569d', name: '米听书', site: 'https://www.ting78.com/',
  description: '搜索需要人机验证：在搜索页点击该源旁的“验证”，完成后会自动重新搜索。',
  categoryMenus: function () {
    var names = ['玄幻', '言情', '都市', '恐怖', '惊悚', '推理', '武侠', '历史', '军事', '穿越', '科幻', '网游', '评书', '戏曲', '笑话', '儿童', '财经', '诗歌', '文学', '粤语', '经典', '相声小品', '百家讲坛'];
    var ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 23, 24];
    return [{ title: '有声小说', tabs: names.map(function (n, i) { return { title: n, url: 'https://www.ting78.com/books/' + ids[i] + '.html' }; }) }];
  }
});

pageBarSource({
  id: 'c1bf15e52e0841a1bc621a0a18bdeaea', name: '囧贼听书网', site: 'https://jiongzei.com/',
  description: '言情、武侠、悬疑、评书、相声小品、百家讲坛等。搜索如需验证，点击搜索页该源旁的“验证”即可。'
});

// ---------- 一夜幻听 22ting.com ----------
registerSource({
  id: '488676f5ccf8455aa7770cbd197fd500', name: '一夜幻听', url: 'https://22ting.com/',
  description: '推荐指数:4星 ⭐⭐⭐⭐\n搜索可能需要验证：在搜索页点击该源旁的“验证”，输入验证码后返回即可。',
  coverHeaders: Shun.coverReferer('22ting.com/', 'https://22ting.com/'),

  searchVerificationUrl: function (keywords) { return 'https://22ting.com/search.php?searchword=' + Shun.enc(keywords); },
  searchVerificationDesktop: true,
  searchDelaySeconds: 6,

  search: function (keywords, page) {
    var doc = Shun.getDoc(this.host, 'https://22ting.com/search.php?page=' + page + '&searchword=' + Shun.enc(keywords) + '&searchtype=', true);
    var books = [];
    doc.select('.row-b > li').forEach(function (li) {
      var a = li.first('.clearfix > section > .mb5 > a');
      if (!a.exists()) return;
      books.push({
        coverUrl: li.first('.clearfix > a > span > img').absUrl('src'), bookUrl: a.absUrl('href'), title: a.text(),
        author: li.first('.clearfix > section > .mb5 > .f-gray').text(),
        intro: li.first('.clearfix > section > .mb5 > .f-12').text(),
        status: Shun.nth(li.first('.clearfix > section').select('p'), 1).text()
      });
    });
    var last = Shun.findByText(doc.first('.mb15 > span'), 'a', '尾页');
    return { books: books, totalPage: regexInt(last.absUrl('href'), /page=(\d+)/, page) };
  },

  searchVerificationResult: function (html, url, keywords) {
    if (url.indexOf('https://22ting.com/') !== 0) return null;
    var doc = this.host.parseHtml(html, url);
    var books = [];
    doc.select('.row-b > li').forEach(function (li) {
      var a = li.first('.clearfix > section > .mb5 > a');
      if (!a.exists()) return;
      books.push({
        coverUrl: li.first('.clearfix > a > span > img').absUrl('src'), bookUrl: a.absUrl('href'), title: a.text(),
        author: li.first('.clearfix > section > .mb5 > .f-gray').text(),
        intro: li.first('.clearfix > section > .mb5 > .f-12').text(),
        status: Shun.nth(li.first('.clearfix > section').select('p'), 1).text()
      });
    });
    if (!books.length) return null;
    var last = Shun.findByText(doc.first('.mb15 > span'), 'a', '尾页');
    return { verified: true, books: books, totalPage: regexInt(last.absUrl('href'), /page=(\d+)/, 1) };
  },

  categoryMenus: function () {
    var nav = Shun.nth(Shun.getDoc(this.host, this.url, true).select('.clearfix'), 1);
    var tabs = nav.select('li > a')
      .filter(function (a) { return a.text() !== '首页'; })
      .map(function (a) { return { title: a.text(), url: a.absUrl('href') }; });
    return [{ title: '分类', tabs: tabs }];
  },

  categoryPage: function (url) {
    var doc = Shun.getDoc(this.host, url, true);
    var bar = doc.first('.mb15 > span');
    var current = regexInt(doc.first('.mb15 > span > .now-page').text(), /(\d+)/);
    var total = regexInt(Shun.findByText(bar, 'a', '尾页').absUrl('href'), /page=(\d+)/, current);
    var next = Shun.findByText(bar, 'a', '››').absUrl('href');
    var books = [];
    doc.select('.row-b > li').forEach(function (li) {
      var a = li.first('.clearfix > section > .mb5 > a');
      if (!a.exists()) return;
      var ps = li.select('.clearfix > section > p');
      books.push({
        coverUrl: li.first('.clearfix > a > .img-box > img').absUrl('src'), bookUrl: a.absUrl('href'), title: a.text(),
        author: li.first('.clearfix > section > .mb5 > span').text(),
        intro: Shun.nth(ps, 0).text(), status: Shun.nth(ps, 1).first('a').text()
      });
    });
    return { books: books, currentPage: current, totalPage: Math.max(total, next ? current + 1 : current), nextUrl: next };
  },

  bookDetail: function (bookUrl, loadEpisodes) {
    var doc = Shun.getDoc(this.host, bookUrl, true);
    var episodes = loadEpisodes
      ? doc.select('#yuedu .clearfix > li a').map(function (a) { return { title: a.text(), url: a.absUrl('href') }; })
      : [];
    return { episodes: episodes, intro: Shun.nth(doc.first('.pd10 > section').select('p'), 4).text() };
  },

  audio: function (url) { return Shun.varNowAudio(this.host, url, true); }
});
