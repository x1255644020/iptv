// ============================================================================
// 酷我听书（移植自 sources_by_luoshu.jar 的 KuwoSource）
// 来源：com.github.eprendre.sources_by_luoshu.KuwoSource
// 依赖：宿主注入的全局函数 registerSource / str / int / items
//       以及 host.getJson / host.progress / host.sleep
// 导入：本文件已在 manifest.json 中（替换原“酷我畅听”），无需额外操作
// 说明：搜索 / 分类 / 榜单 / 章节 / 播放均走酷我直连接口，不依赖第三方代理；
//       部分付费内容只能试听或无法播放（audio 会报“没有获取到播放地址”）。
// ============================================================================
(function () {
  var ALBUM_INFO = 'https://search.kuwo.cn/r.s?stype=albuminfo&loginUid=0&loginSid=null&prod=kwplayer_ar_9.1.8.1&bkprod=kwbook_ar_9.1.8.1&source=kwplayer_ar_9.1.8.1_t87.apk&bksource=kwbook_ar_9.1.8.1_t87.apk&corp=kuwo&show_copyright_off=1&vipver=MUSIC_8.2.0.0_BCS17&mobi=1&sortby=3&iskwbook=1';
  var PLAY = 'https://mobi.kuwo.cn/mobi.s?f=web&user=0&source=kwplayercar_ar_6.0.0.9_B_jiakong_vh.apk&type=convert_url_with_sign&br=128kmp3&rid=';

  function albumBookUrl(albumId) {
    return ALBUM_INFO + '&albumid=' + albumId + '&pn=0&rn=200';
  }

  // 根据返回里的 total 字段估算总页数；没有 total 时按“本页是否满 20 条”猜测
  function pages(size, page, json, data) {
    var total = int(json, 'TOTAL');
    if (total < 0) total = int(json, 'total');
    if (total < 0) total = int(data, 'total');
    if (total > 0) return Math.max(page, Math.ceil(total / 20));
    return size >= 20 ? page + 1 : page;
  }

  // 分类标签：kwc:<classifyId>:<categoryId>:<sortType>&&<page>
  function ctab(name, classifyId, categoryId, sortType) {
    return { title: name, url: 'kwc:' + classifyId + ':' + (categoryId || '') + ':' + (sortType || 'pubDate') + '&&1' };
  }
  // 排行榜标签：kwr:<tabId>:<id>&&<page>
  function rtab(name, tabId, id) {
    return { title: name, url: 'kwr:' + tabId + ':' + id + '&&1' };
  }

  registerSource({
    id: '502efedf0613460a9967d9e86ce2b24c', name: '酷我听书', url: 'https://kuwo.cn/downtingshu',
    description: '酷我音乐的听书频道：有声小说、相声评书、热歌神曲、排行榜等。部分付费内容只能试听或无法播放。',
    multipleEpisodePages: true,

    search: function (keywords, page) {
      var data = this.host.getJson('http://tingshu.kuwo.cn/tingshu/api/search/Search?rn=10&type=album&version=8.5.6.1&wd=' + encodeURIComponent(keywords) + '&pn=' + page + '&kweexVersion=1.0.2').data || {};
      var arr = data.data || [];
      var books = arr.map(function (item) {
        var albumId = str(item, 'albumId');
        return {
          coverUrl: str(item, 'coverImg'), bookUrl: albumBookUrl(albumId), title: str(item, 'albumName'),
          artist: str(item, 'artistName'), status: '', intro: ''
        };
      });
      var total = int(data, 'total');
      return { books: books, totalPage: Math.max(page, Math.ceil(total / 10)) };
    },

    categoryMenus: function () {
      return [
        { title: '有声小说', tabs: [
          ctab('玄幻奇幻', '44'), ctab('武侠仙侠', '48'), ctab('穿越架空', '52'), ctab('都市传说', '42'),
          ctab('科幻竞技', '57'), ctab('幻想言情', '169'), ctab('独家定制', '170'), ctab('古代言情', '207'),
          ctab('影视原著', '213'), ctab('悬疑推理', '45'), ctab('历史军事', '56'), ctab('现代言情', '41'),
          ctab('青春校园', '55'), ctab('文学名著', '61')
        ] },
        { title: '热歌神曲', tabs: [
          ctab('全部分类', '0', '37', ''), ctab('抖音神曲', '253', '37', ''), ctab('怀旧老歌', '252', '37', ''),
          ctab('创作|翻唱', '248', '37', ''), ctab('催眠', '254', '37', ''), ctab('古风', '255', '37', ''),
          ctab('播客周刊', '1423', '37', ''), ctab('民谣', '1409', '37', ''), ctab('纯音乐', '1408', '37', ''),
          ctab('3D电子', '249', '37', ''), ctab('音乐课程', '251', '37', ''), ctab('音乐推荐', '246', '37', ''),
          ctab('音乐故事', '247', '37', ''), ctab('情感治愈', '250', '37', ''), ctab('儿童音乐', '1407', '37', '')
        ] },
        { title: '排行榜', tabs: [
          rtab('热播榜', '15', '123'), rtab('免费榜', '16', '123'), rtab('畅销榜', '2', '123'),
          rtab('男频VIP榜', '20', '123'), rtab('女频VIP榜', '21', '123'), rtab('新品榜', '8', '123'), rtab('精品榜', '23', '123'),
          rtab('分类·有声小说', '15', '123'), rtab('分类·相声评书', '15', '126'), rtab('分类·历史', '15', '140'),
          rtab('分类·影视原声', '15', '141'), rtab('分类·两性情感', '15', '129'), rtab('分类·人文', '15', '137'),
          rtab('分类·音乐调频', '15', '131'), rtab('分类·戏曲', '15', '139'), rtab('分类·国漫游戏', '15', '130'),
          rtab('分类·畅销书', '15', '127'), rtab('分类·脱口秀', '15', '785'), rtab('分类·娱乐段子', '15', '132'),
          rtab('分类·个人提升', '15', '133'), rtab('分类·儿童', '15', '125'), rtab('分类·学科教育', '15', '128'),
          rtab('分类·商业财经', '15', '134'), rtab('分类·外语', '15', '138')
        ] },
        { title: '相声评书', tabs: [
          ctab('全部分类', '0', '5', 'playCnt'), ctab('郭德纲', '84', '5', 'playCnt'), ctab('相声新人', '222', '5', 'playCnt'),
          ctab('张少佐', '313', '5', 'playCnt'), ctab('刘立福', '314', '5', 'playCnt'), ctab('评书大全', '220', '5', 'playCnt'),
          ctab('小品合辑', '221', '5', 'playCnt'), ctab('刘兰芳', '309', '5', 'playCnt'), ctab('连丽如', '311', '5', 'playCnt'),
          ctab('田占义', '317', '5', 'playCnt'), ctab('单口相声', '219', '5', 'playCnt'), ctab('袁阔成', '310', '5', 'playCnt'),
          ctab('孙一', '315', '5', 'playCnt'), ctab('王玥波', '316', '5', 'playCnt'), ctab('单田芳', '217', '5', 'playCnt'),
          ctab('热门相声', '218', '5', 'playCnt'), ctab('相声名家', '290', '5', 'playCnt'), ctab('粤语评书', '320', '5', 'playCnt'),
          ctab('关永超', '325', '5', 'playCnt'), ctab('马长辉', '326', '5', 'playCnt'), ctab('赵维莉', '327', '5', 'playCnt'),
          ctab('潮剧', '1718', '5', 'playCnt'), ctab('沪剧', '1719', '5', 'playCnt'), ctab('晋剧', '1720', '5', 'playCnt')
        ] },
        { title: '亲子儿童', tabs: [
          ctab('全部分类', '0', '1', 'playCnt'), ctab('益智故事', '209', '1', 'playCnt'), ctab('科普知识', '83', '1', 'playCnt'),
          ctab('国学经典', '2', '1', 'playCnt'), ctab('卡通动画', '282', '1', 'playCnt'), ctab('儿童教育', '4', '1', 'playCnt'),
          ctab('英语启蒙', '12', '1', 'playCnt'), ctab('早教启蒙', '385', '1', 'playCnt'), ctab('轻松哄睡', '210', '1', 'playCnt')
        ] }
      ];
    },

    categoryPage: function (url) {
      var parts = url.split('&&');
      var key = parts[0] || '';
      var page = parseInt(parts[1], 10) || 1;
      var apiUrl, arr, totalPage = page, books = [];
      if (key.indexOf('kwr:') === 0) {
        var f = key.slice(4).split(':');
        var tabId = f[0] || '15', idv = f[1] || '123';
        apiUrl = 'https://tingshu.kuwo.cn/v2/api/product/rank/dataList?tabId=' + tabId + '&id=' + idv + '&rn=20&pn=' + page;
      } else {
        var g = key.replace('kwc:', '').split(':');
        var classifyId = g[0] || '44', categoryId = g[1] || '', sortType = g[2] || '';
        apiUrl = 'https://tingshu.kuwo.cn/v2/api/search/filter/albums?classifyId=' + classifyId + '&rn=20&pn=' + page;
        if (sortType) apiUrl += '&sortType=' + sortType;
        if (categoryId && categoryId !== '0') apiUrl += '&categoryId=' + categoryId;
      }
      try {
        var json = this.host.getJson(apiUrl);
        var data = json.data || {};
        arr = data.data || data.rankDataList || [];
        for (var i = 0; i < arr.length; i++) {
          var it = arr[i];
          var albumId = str(it, 'albumId');
          if (!albumId) continue;
          var num = int(it, 'songNum');
          books.push({
            coverUrl: str(it, 'coverImg') || str(it, 'albumImg'),
            bookUrl: albumBookUrl(albumId),
            title: str(it, 'albumName'),
            artist: '',
            status: num > 0 ? '共 ' + num + ' 章' : '',
            intro: ''
          });
        }
        totalPage = pages(books.length, page, json, data);
      } catch (e) { /* 出错就返回已经拿到的内容 */ }
      var nextUrl = page < totalPage ? (key + '&&' + (page + 1)) : null;
      return { books: books, currentPage: page, totalPage: totalPage, nextUrl: nextUrl };
    },

    bookDetail: function (url, loadEpisodes, loadFullPages) {
      var list = [];
      if (!loadEpisodes) return { episodes: list };
      var host = this.host;
      var m = /albumid=(\d+)/.exec(url);
      var albumId = m ? m[1] : '';
      if (!albumId) return { episodes: list };
      try {
        for (var pn = 0; pn < 300; pn++) {
          var tracks = items(host.getJson(ALBUM_INFO + '&albumid=' + albumId + '&pn=' + pn + '&rn=200'), 'musiclist');
          if (!tracks || tracks.length === 0) break;
          for (var i = 0; i < tracks.length; i++) {
            var rid = str(tracks[i], 'musicrid');
            if (rid) list.push({ title: str(tracks[i], 'name'), url: 'kuwo:' + rid });
          }
          if (tracks.length < 200) break;
          if (!loadFullPages) break;
          host.progress('已加载 ' + list.length + ' 章');
          host.sleep(200 + Math.random() * 400);
        }
      } finally {
        host.progress(null);
      }
      return { episodes: list };
    },

    audio: function (url) {
      var rid = url.replace('kuwo:', '').replace('MUSIC_', '');
      var json = this.host.getJson(PLAY + rid, { desktop: true });
      var audio = str(json, 'data.url');
      if (!audio) throw new Error('没有获取到播放地址（可能是付费内容）');
      return audio;
    }
  });
})();
