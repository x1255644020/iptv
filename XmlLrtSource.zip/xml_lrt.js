// ================= 喜马拉雅 + 懒人听书 接口源（SSTS-Android 版） =================
// 契约（2026-10-15 实测）：
//   ximalaya.search   GET https://www.ximalaya.com/revision/search?core=album&kw=&page=
//                     -> data.result.response.docs[] = {id, title, cover_path(//开头需补https), intro, nickname, tracks}
//   ximalaya.chapters GET http://mobwsa.ximalaya.com/mobile/playlist/album/page?albumId=&pageId= 每页20
//                     -> list[] = {trackId, title, duration, isFree, isPaid}; maxPageId=总页数
//   ximalaya.audio    GET https://fm.12311111.xyz/api/ximalaya/index.php?act=audio&bookId=&chapterId=
//                     -> data.url（带签名 m4a 直链，有效期 24h）
//
//   lrts.search       GET https://m.lrts.me/ajax/searchBook?keyWord=&pageNum=&pageSize=20（内置登录 Cookie，无需配置即可搜索）
//                     -> list[]（顶层）/ count / hasNext（实测 apiStatus:0 count:82）
//   lrts.category     GET https://m.lrts.me/ajax/getCategory（公开，返回分类树 id/name/subList）
//                     GET https://m.lrts.me/ajax/getBookTypePage?typeId=<分类id>（公开，返回 recommendList 约12本，无需登录）
//   lrts.chapters     GET https://m.lrts.me/ajax/getBookMenu?bookId=&pageNum=&pageSize=50 每页50
//                     -> list[] = {sectionId, section(集序号), name(可能带BOM), length}; apiStatus==0 正常（公开可用）
//   lrts.audio        GET https://fm.12311111.xyz/api/lrts/index.php?act=audio&bookId=&section=<集序号>&opType=1
//                     -> data.url（带签名 m4a 直链，有效期 24h）
//
// 音频代理 fm.12311111.xyz 有 IP 限频（每 30 秒 1 次）。
// 连续播放方案（滚动预取）：
//   - bookDetail 进入详情时预取前 N 集（默认 5，可配置 0-20）写缓存
//   - audio() 命中缓存直接返回（不触发限频），并顺手尝试预取当前集之后的下一集
//   - 缓存 24h 有效（host.cacheAge 判断），带签名直链长期可用
// 注意：Rhino/ES5，只用 var/function，禁 class/async/展开运算符/可选链。
//       宿主对象通过 this.host 注入到源方法里，辅助函数一律用参数传入 host。

(function () {
  'use strict';

  var UA = 'Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
  var HDR = { 'User-Agent': UA, Accept: 'application/json' };
  var BOM = '\ufeff';
  var TTL = 86400000; // 直链有效期 24h

  // 懒人听书内置登录 Cookie（用户提供，实测可用：searchBook 返回 apiStatus:0 真实书单，无需配置即可解锁搜索/分类）
  var LRTS_COOKIE = 'TDC_itoken=1627976464%3A1792036655; token=36eb1f70d6572c3b15751b84b9fa4a546e7086ed2f2aa43e6bbdb8842602a7ae46310d47fa7dca4c5484e6d9afb6333822e0a32f636264a0169ff14cb01f3a3e59dcee28084bfe9eee55cb1fcc6fae4779cfd25199fbad00a13f3f89613eaad2; token.sig=BlGGr04fz3UVSevAfmxsIBUMOac';

  var XM_CATS = [
    ['玄幻', '玄幻'], ['仙侠', '仙侠'], ['都市', '都市'], ['历史', '历史'],
    ['悬疑', '悬疑'], ['科幻', '科幻'], ['言情', '言情'], ['评书', '评书'],
    ['相声', '相声'], ['鬼故事', '鬼故事'], ['儿童', '儿童'], ['英语', '英语']
  ];
  var LRTS_CATS = [
    ['玄幻', '玄幻'], ['仙侠', '仙侠'], ['都市', '都市'], ['历史', '历史'],
    ['悬疑', '悬疑'], ['科幻', '科幻'], ['言情', '言情'], ['评书', '评书'],
    ['相声', '相声'], ['鬼故事', '鬼故事'], ['儿童', '儿童'], ['英语', '英语']
  ];

  function fixCover(p) {
    if (!p) return '';
    if (p.indexOf('//') === 0) return 'https:' + p;
    return p;
  }

  function cleanName(s) {
    s = s || '';
    if (s.charAt(0) === BOM) s = s.slice(1);
    return s;
  }

  // getJsonOrThrow 支持自定义请求头（如登录态 Cookie）
  function getJsonOrThrow(host, url, headers) {
    var resp = host.fetch(url, { headers: headers || HDR });
    if (resp.status < 200 || resp.status >= 300) throw new Error('HTTP ' + resp.status);
    return parseJson(resp.body);
  }

  // 懒人听书请求头：若配置了登录 Cookie 则带上（解锁官方 searchBook 搜索/分类）
  function lrtsHeaders(host) {
    var h = { 'User-Agent': UA, Accept: 'application/json' };
    // 优先用配置里的 Cookie（可覆盖），否则用内置 Cookie
    var ck = host.getPref('lrts_cookie', '') || LRTS_COOKIE;
    if (ck) h['Cookie'] = ck;
    return h;
  }

  // 取原始响应体（字符串），用于缓存官方 getCategory 等 JSON
  function lrtsFetchRaw(host, url, headers) {
    var resp = host.fetch(url, { headers: headers || HDR });
    if (resp.status < 200 || resp.status >= 300) throw new Error('HTTP ' + resp.status);
    return resp.body || '';
  }

  function cacheGet(host, key) {
    var v = host.readCache(key);
    if (!v) return null;
    var age = host.cacheAge(key);
    if (age < 0 || age > TTL) return null;
    return v;
  }

  // 懒人听书官方接口状态校验：apiStatus/status 非 0 表示异常（如 485 需登录）
  // 之前未校验，导致登录墙(485)被当成"无结果"，搜索/分类静默返回 0 本。
  function lrtsCheck(json) {
    if (!json) return;
    var st = json.apiStatus != null ? json.apiStatus : json.status;
    if (st != null && st !== 0) {
      throw new Error('懒人听书接口: ' + (json.msg || ('状态码 ' + st)));
    }
  }

  // fm.12311111.xyz 代理统一返回 {code,msg,data}；data.error 为上游失败信息（如"上游无返回"）
  function proxyCheck(json, actName) {
    actName = actName || '代理';
    if (!json || json.code == null) throw new Error(actName + '失败：未识别的返回');
    if (json.code !== 200) throw new Error(actName + '失败：' + (json.msg || ('code ' + json.code)));
    var d = json.data || {};
    if (d.error) throw new Error(actName + '：' + d.error);
    return d;
  }

  // 预取一集（限频：内部 sleep 30 秒后取下一集；失败就停）
  // fetchOne(host, bookId, seq) -> url 或 null
  function prefetchOne(host, cachePrefix, bookId, seq, fetchOne) {
    var key = cachePrefix + bookId + '_' + seq;
    if (cacheGet(host, key)) return true; // 已有缓存
    var url = null;
    try { url = fetchOne(host, bookId, seq); } catch (e) { return false; }
    if (!url) return false;
    host.writeCache(key, url);
    return true;
  }

  // 滚动预取：从 start 开始连续取 n 集（每 30 秒 1 次）
  function prefetchRange(host, cachePrefix, bookId, start, n, fetchOne) {
    for (var i = 0; i < n; i++) {
      var seq = start + i;
      if (cacheGet(host, cachePrefix + bookId + '_' + seq)) continue;
      if (!prefetchOne(host, cachePrefix, bookId, seq, fetchOne)) return;
      if (i < n - 1) host.sleep(30000);
    }
  }

  // ==================== 喜马拉雅 ====================
  function xmBook(it) {
    return {
      bookUrl: 'xm:' + it.id,
      title: it.title || '',
      author: it.nickname || '',
      artist: '',
      coverUrl: fixCover(it.cover_path),
      intro: it.intro || '',
      status: it.is_finished === 2 ? '完结' : '连载'
    };
  }

  function xmFetchAudio(host, bookId, chapterId) {
    var json = getJsonOrThrow(host, 'https://fm.12311111.xyz/api/ximalaya/index.php?act=audio&bookId=' +
      encodeURIComponent(bookId) + '&chapterId=' + encodeURIComponent(chapterId));
    return str(json, 'data.url');
  }

  registerSource({
    id: 'f3f1c2e5a9b847d1a6c4d8e2b7f0a5c9',
    name: '喜马拉雅(爱听api)',
    url: 'https://www.ximalaya.com',
    description: '搜索/章节直连官方接口，音频走 fm.12311111.xyz 代理（30秒限1次，滚动预取缓存）',
    group: '听书',
    multipleEpisodePages: true,
    config: [
      { type: 'select', key: 'prefetch', label: '预取集数(连播缓存)', default: '5', options: ['0', '1', '2', '3', '5', '10', '20'] }
    ],

    search: function (keywords, page) {
      var host = this.host;
      var json = getJsonOrThrow(host, 'https://www.ximalaya.com/revision/search?core=album&kw=' +
        encodeURIComponent(keywords) + '&page=' + (page || 1));
      var docs = at(json, 'data.result.response.docs');
      var books = [];
      if (docs) {
        for (var i = 0; i < docs.length; i++) {
          if (!docs[i].id) continue;
          books.push(xmBook(docs[i]));
        }
      }
      return { books: books, totalPage: page + 1 };
    },

    categoryMenus: function () {
      var tabs = [];
      for (var i = 0; i < XM_CATS.length; i++) tabs.push({ title: XM_CATS[i][0], url: 'xmc:' + XM_CATS[i][1] });
      return [{ title: '热门分类', tabs: tabs }];
    },

    categoryPage: function (url) {
      var host = this.host;
      var page = regexInt(url, /&p=(\d+)/, 1);
      var m = /^xmc:([^&]+)/.exec(url);
      var kw = m ? m[1] : '玄幻';
      var json = getJsonOrThrow(host, 'https://www.ximalaya.com/revision/search?core=album&kw=' +
        encodeURIComponent(kw) + '&page=' + page);
      var docs = at(json, 'data.result.response.docs');
      var books = [];
      if (docs) {
        for (var i = 0; i < docs.length; i++) {
          if (!docs[i].id) continue;
          books.push(xmBook(docs[i]));
        }
      }
      var next = '';
      if (books.length > 0) {
        var base = url.indexOf('&p=') < 0 ? url : url.replace(/&p=\d+/, '');
        next = base + '&p=' + (page + 1);
      }
      return { books: books, currentPage: page, totalPage: page + 1, nextUrl: next };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host;
      var albumId = bookUrl.split(':')[1];
      var out = [];
      var page = 1;
      while (true) {
        var json = getJsonOrThrow(host, 'http://mobwsa.ximalaya.com/mobile/playlist/album/page?albumId=' +
          albumId + '&pageId=' + page);
        var list = at(json, 'list');
        if (!list || !list.length) break;
        for (var i = 0; i < list.length; i++) {
          var it = list[i];
          if (!it.trackId) continue;
          out.push({
            title: it.title || '',
            url: 'xm:' + albumId + ':' + it.trackId,
            isFree: !!it.isFree
          });
        }
        if (list.length < 20) break;
        page++;
        if (page > 300) break;
      }
      // 缓存章节 trackId 序列（供滚动预取按真实顺序找下一集）
      if (out.length > 0) {
        var eps = [];
        for (var ei = 0; ei < out.length; ei++) eps.push(out[ei].url.split(':')[2]);
        host.writeCache('xm_eps_' + albumId, eps.join(','));
      }
      // 后台加载全部章节时，按章节列表顺序预取前 N 集（trackId 不连续，不能用 +1）
      if (loadFullPages && out.length > 0) {
        var pf = parseInt(host.getPref('prefetch', '5'), 10) || 0;
        var list = out;
        for (var pi = 0; pi < pf && pi < list.length; pi++) {
          var t = list[pi].url.split(':')[2];
          prefetchOne(host, 'xma_', albumId, t, function (h, bId, seq) {
            return xmFetchAudio(h, bId, seq);
          });
          if (pi < pf - 1 && pi < list.length - 1) host.sleep(30000);
        }
      }
      return { episodes: out };
    },

    audio: function (episodeUrl) {
      var host = this.host;
      var parts = episodeUrl.split(':');
      if (parts.length < 3) throw new Error('章节地址格式错误');
      var bookId = parts[1], chapterId = parts[2];
      // 优先读缓存
      var cached = cacheGet(host, 'xma_' + bookId + '_' + chapterId);
      if (cached) {
        // 顺手预取下一集（滚动）：按缓存的章节列表找当前集的下一个 trackId
        try {
          var pf = parseInt(host.getPref('prefetch', '5'), 10) || 0;
          if (pf > 0) {
            var epsStr = host.readCache('xm_eps_' + bookId);
            var eps = epsStr ? epsStr.split(',') : [];
            for (var i = 0; i < eps.length; i++) {
              if (eps[i] === chapterId && i + 1 < eps.length) {
                var nxt = eps[i + 1];
                if (!cacheGet(host, 'xma_' + bookId + '_' + nxt)) {
                  var u = xmFetchAudio(host, bookId, nxt);
                  if (u) host.writeCache('xma_' + bookId + '_' + nxt, u);
                }
                break;
              }
            }
          }
        } catch (e) { /* 忽略预取失败 */ }
        return { url: cached, headers: { Referer: 'https://www.ximalaya.com/' } };
      }
      // 未命中才现取（绝不重试）
      var url = xmFetchAudio(host, bookId, chapterId);
      if (!url) {
        var json = getJsonOrThrow(host, 'https://fm.12311111.xyz/api/ximalaya/index.php?act=audio&bookId=' +
          encodeURIComponent(bookId) + '&chapterId=' + encodeURIComponent(chapterId));
        var msg = str(json, 'msg');
        throw new Error(msg ? ('音频接口: ' + msg) : '音频接口未返回地址');
      }
      host.writeCache('xma_' + bookId + '_' + chapterId, url);
      return { url: url, headers: { Referer: 'https://www.ximalaya.com/' } };
    }
  });

  // ==================== 懒人听书 ====================
  function lrtsBook(it) {
    return {
      bookUrl: 'lrts:' + it.id,
      title: it.name || '',
      author: it.author || '',
      artist: it.announcer || '',
      coverUrl: it.cover || '',
      intro: it.desc || '',
      status: it.state === 2 ? '完结' : '连载'
    };
  }

  // 未登录兜底：抓取官网首页在架书单（/book/{id} + 标题），缓存复用。
  // 首页为服务端渲染，稳定可用；登录后分类改用 searchBook(题材) 精确返回。
  function lrtsHomeBooks(host) {
    var cacheKey = 'lrts_home_books';
    var c = cacheGet(host, cacheKey);
    if (c) return c;
    var html = '';
    try {
      var resp = host.fetch('https://m.lrts.me/', { headers: lrtsHeaders(host) });
      html = resp.body || '';
    } catch (e) { html = ''; }
    var books = [];
    if (!html) return books;
    var re = /<a href="\/book\/(\d+)" class="lr-item-row book"[^>]*>[\s\S]*?<div class="name lr-line-clamp-2"[^>]*>\s*([^<]+)/g;
    var mm;
    while ((mm = re.exec(html)) !== null) {
      var name = mm[2].replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
      if (!name) continue;
      books.push({ id: mm[1], name: name, author: '', announcer: '', cover: '', desc: '', state: 0 });
    }
    if (books.length) host.writeCache(cacheKey, books);
    return books;
  }

  // 从各种输入中提取懒人听书 bookId：
  //   lrts:30011:...        -> 标准 bookUrl
  //   https://m.lrts.me/player?id=30011  -> 网页播放/详情链接
  //   30011                 -> 直接粘贴的数字 id
  // 搜索接口已登录墙，此容错让用户可绕过搜索、直接用网页链接/bookId 听书。
  function lrtsBookId(input) {
    if (!input) return '';
    var m = /^lrts:(\d+)/.exec(input);
    if (m) return m[1];
    m = /[?&]id=(\d+)/.exec(input);
    if (m) return m[1];
    m = /(\d{4,})/.exec(input);
    if (m) return m[1];
    return input;
  }

  // 懒人听书分类树：运行时拉取官方 getCategory（公开接口，无需登录），但只展示「有声小说」区。
  // 每个子分类带唯一 id，categoryPage 用它调用 getBookTypePage?typeId=<id> 取真实书单。
  // getCategory 失效时兜底到"有声小说·全部"入口，保证分类页始终有数据。
  function lrtsCategoryTree(host) {
    var fallback = [{ title: '有声小说', tabs: [{ title: '全部', url: 'lrtsc:1:有声小说' }] }];
    var cacheKey = 'lrts_cat_raw';
    var raw = host.readCache(cacheKey);
    if (!raw || host.cacheAge(cacheKey) > 3600000) {
      try {
        raw = lrtsFetchRaw(host, 'https://m.lrts.me/ajax/getCategory', lrtsHeaders(host));
        host.writeCache(cacheKey, raw);
      } catch (e) { raw = ''; }
    }
    var json = raw ? parseJson(raw) : null;
    if (!json || (json.apiStatus != null && json.apiStatus !== 0)) return fallback;
    var data = json.data || {};
    var topList = data.bookTypeList || [];
    // 只保留"有声小说"区（顶层 id=1 或 name=有声小说）
    var novelTop = null;
    for (var ti = 0; ti < topList.length; ti++) {
      var t = topList[ti];
      if (t && (t.id === 1 || t.name === '有声小说')) { novelTop = t; break; }
    }
    if (!novelTop) return fallback;
    var tabs = [{ title: '全部', url: 'lrtsc:' + novelTop.id + ':' + novelTop.name }];
    var subs = novelTop.subList || [];
    for (var ts = 0; ts < subs.length; ts++) {
      if (!subs[ts] || !subs[ts].id) continue;
      tabs.push({ title: subs[ts].name, url: 'lrtsc:' + subs[ts].id + ':' + subs[ts].name });
    }
    return [{ title: '有声小说', tabs: tabs }];
  }

  // 搜索：内置登录 Cookie 已解锁官方 searchBook（按关键词/题材返回真实书单）。
  // 实测返回顶层 list[] / count / hasNext（亦兼容 data.list 兼容写法）。
  function lrtsSearch(host, kw, page) {
    var json = getJsonOrThrow(host, 'https://m.lrts.me/ajax/searchBook?keyWord=' +
      encodeURIComponent(kw) + '&pageNum=' + (page || 1) + '&pageSize=20', lrtsHeaders(host));
    lrtsCheck(json);
    var list = at(json, 'data.list') || at(json, 'list') || [];
    var books = [];
    for (var i = 0; i < list.length; i++) {
      if (!list[i].id) continue;
      books.push(lrtsBook(list[i]));
    }
    var hasNext = !!json.hasNext || list.length >= 20;
    return { books: books, hasNext: hasNext };
  }

  function lrtsFetchAudio(host, bookId, section) {
    var json = getJsonOrThrow(host, 'https://fm.12311111.xyz/api/lrts/index.php?act=audio&bookId=' +
      encodeURIComponent(bookId) + '&section=' + encodeURIComponent(section) + '&opType=1');
    var d = proxyCheck(json, '音频');
    return str(d, 'url') || str(json, 'data.url');
  }

  registerSource({
    id: '8a7f6e5d4c3b2a109876543210fedcba',
    name: '懒人听书(爱听api)',
    url: 'https://m.lrts.me',
    description: '搜索内置Cookie直连官方searchBook；分类仅取「有声小说」区(公开getBookTypePage)；章节直连官方getBookMenu；音频走代理（30秒限1次，滚动预取缓存）',
    group: '听书',
    multipleEpisodePages: true,
    config: [
      { type: 'select', key: 'prefetch', label: '预取集数(连播缓存)', default: '5', options: ['0', '1', '2', '3', '5', '10', '20'] },
      { type: 'text', key: 'lrts_cookie', label: 'Cookie覆盖(可选，留空用内置)', default: '' }
    ],

    // 登录入口：Cookie 已内置，说明默认即可用；内置过期可在配置项覆盖。
    login: function () {
      return '【懒人听书】\n' +
        '登录 Cookie 已内置，搜索与分类默认即可使用（无需任何配置）。\n' +
        '分类仅展示「有声小说」区（含其 11 个子分类）。\n' +
        '若内置 Cookie 过期，可在「配置」里粘贴新 Cookie 到“Cookie覆盖”覆盖之。';
    },

    search: function (keywords, page) {
      var host = this.host;
      var r = lrtsSearch(host, keywords, page);
      return { books: r.books, totalPage: r.hasNext ? page + 1 : page };
    },

    categoryMenus: function () {
      return lrtsCategoryTree(this.host);
    },

    // 分类页：用官方公开接口 getBookTypePage?typeId=<分类id> 取真实书单（无需登录）。
    //   lrtsc:<id>:<name>  -> 顶层/子分类（如 lrtsc:1:有声小说、lrtsc:11:玄幻奇幻）
    //   lrtshome:          -> 兜底：官网首页在架书单
    categoryPage: function (url) {
      var host = this.host;
      if (/^lrtshome:/.test(url)) {
        var hb = lrtsHomeBooks(host);
        var hbooks = [];
        for (var h = 0; h < hb.length; h++) hbooks.push(lrtsBook(hb[h]));
        return { books: hbooks, currentPage: 1, totalPage: 1, nextUrl: '' };
      }
      var m = /^lrtsc:(\d+)/.exec(url);
      var typeId = m ? m[1] : '1';
      // getBookTypePage 单次返回该分类的推荐书单（约 12 本，官方分类页即如此，无分页参数）
      var json = getJsonOrThrow(host, 'https://m.lrts.me/ajax/getBookTypePage?typeId=' + typeId, lrtsHeaders(host));
      lrtsCheck(json);
      var rl = (json.data && json.data.recommendList) || [];
      var books = [];
      for (var i = 0; i < rl.length; i++) {
        var b = rl[i];
        if (!b.id) continue;
        books.push({
          bookUrl: 'lrts:' + b.id,
          title: b.name || '',
          author: b.author || '',
          artist: b.announcer || b.nickName || '',
          coverUrl: fixCover(b.cover) || fixCover(b.originCover),
          intro: b.desc || '',
          status: ''
        });
      }
      if (books.length === 0) {
        // 兜底：拿首页在架书单，保证分类页不空白
        var fb = lrtsHomeBooks(host);
        for (var j = 0; j < fb.length; j++) books.push(lrtsBook(fb[j]));
      }
      return { books: books, currentPage: 1, totalPage: 1, nextUrl: '' };
    },

    // 章节：直连官方 getBookMenu（实测公开可用 apiStatus:0），不再依赖已死的代理 chapters
    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host;
      var bookId = lrtsBookId(bookUrl); // 容错：支持 lrts:ID / 网页链接 / 裸ID
      var out = [];
      var page = 1;
      while (true) {
        var json = getJsonOrThrow(host, 'https://m.lrts.me/ajax/getBookMenu?bookId=' + bookId +
          '&pageNum=' + page + '&pageSize=50');
        lrtsCheck(json); // 公开可用，但异常（如需登录）时明确抛错而非静默 0 集
        var list = at(json, 'list');
        if (!list || !list.length) break;
        for (var i = 0; i < list.length; i++) {
          var it = list[i];
          if (!it.sectionId) continue;
          out.push({
            title: cleanName(it.name),
            url: 'lrts:' + bookId + ':' + it.sectionId + ':' + (it.section || (page - 1) * 50 + i + 1),
            isFree: true
          });
        }
        if (list.length < 50) break;
        page++;
        if (page > 300) break;
      }
      // 后台加载全部章节时，预取前 N 集
      if (loadFullPages && out.length > 0) {
        var pf = parseInt(host.getPref('prefetch', '5'), 10) || 0;
        var firstSection = parseInt(out[0].url.split(':')[3], 10);
        prefetchRange(host, 'lra_', bookId, firstSection, pf, function (h, bId, seq) {
          return lrtsFetchAudio(h, bId, seq);
        });
      }
      return { episodes: out };
    },

    audio: function (episodeUrl) {
      var host = this.host;
      var parts = episodeUrl.split(':');
      if (parts.length < 4) throw new Error('章节地址格式错误');
      var bookId = lrtsBookId(episodeUrl), chapterId = parts[2], section = parts[3];
      // 优先读缓存
      var cached = cacheGet(host, 'lra_' + bookId + '_' + section);
      if (cached) {
        // 顺手预取下一集（滚动），失败不阻塞
        try {
          var pf = parseInt(host.getPref('prefetch', '5'), 10) || 0;
          if (pf > 0) {
            var next = parseInt(section, 10) + 1;
            if (!cacheGet(host, 'lra_' + bookId + '_' + next)) {
              var u = lrtsFetchAudio(host, bookId, next);
              if (u) host.writeCache('lra_' + bookId + '_' + next, u);
            }
          }
        } catch (e) { /* 忽略预取失败 */ }
        return { url: cached, headers: { Referer: 'https://m.lrts.me/' } };
      }
      // 未命中才现取（绝不重试）
      var url = lrtsFetchAudio(host, bookId, section);
      if (!url) {
        var json = getJsonOrThrow(host, 'https://fm.12311111.xyz/api/lrts/index.php?act=audio&bookId=' +
          encodeURIComponent(bookId) + '&section=' + encodeURIComponent(section) + '&opType=1');
        var msg = str(json, 'msg');
        throw new Error(msg ? ('音频接口: ' + msg) : '音频接口未返回地址');
      }
      host.writeCache('lra_' + bookId + '_' + section, url);
      return { url: url, headers: { Referer: 'https://m.lrts.me/' } };
    }
  });
})();
